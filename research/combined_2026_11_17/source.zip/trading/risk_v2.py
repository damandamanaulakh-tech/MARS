"""Pre-entry risk controls — the 5 critical fixes every reviewer flagged.

This module is purely additive. It does NOT modify existing risk.py logic.
The engine calls these as additional gates BEFORE the existing can_open().

Critical fixes:
  1. Graduated drawdown governor — 5 levels (-5/-8/-10/-15/-20)
  2. Pre-entry correlation gate — reject if any open position correlates > 0.7
  3. Vol-adjusted position sizing — ATR-based 3-tier (low/mid/high vol)
  4. Hard liquidity filters — ADV, mcap, spread
  5. Consecutive loss halt — 2 losing trades same day -> halt entries
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Optional

import numpy as np
import pandas as pd
from . import decision_evidence as de

log = logging.getLogger(__name__)


# ============================================================================
# 1. GRADUATED DRAWDOWN GOVERNOR
# ============================================================================

DRAWDOWN_LEVELS = [
    # (threshold_pct_from_peak, level_name, sizing_multiplier, action_desc)
    (-0.05, "watchful",     0.75, "Reduce new position size to 75%"),
    (-0.08, "stop_adding",  0.0,  "No new positions; existing trail"),
    (-0.10, "cut_half",     0.0,  "Cut total exposure 50%"),
    (-0.15, "mostly_cash",  0.0,  "Move to mostly cash; minimal positions"),
    (-0.20, "full_halt",    0.0,  "Full strategy halt; close everything"),
]


@dataclass
class DrawdownGovernor:
    """Tracks peak equity and current drawdown; returns the active level."""
    peak_equity: float = 0.0
    last_equity: float = 0.0
    active_level: str = "normal"
    sizing_multiplier: float = 1.0
    halt_new_entries: bool = False
    forced_cut: float = 0.0   # fraction of exposure to liquidate now (0..1)
    reason: str = ""

    def update(self, current_equity: float) -> None:
        """Call on every refresh. Mutates state with new readings."""
        self.last_equity = current_equity
        if current_equity > self.peak_equity:
            self.peak_equity = current_equity
        if self.peak_equity <= 0:
            self.active_level = "normal"
            self.sizing_multiplier = 1.0
            self.halt_new_entries = False
            self.forced_cut = 0.0
            self.reason = "no peak yet"
            return
        dd = (current_equity - self.peak_equity) / self.peak_equity
        # Walk thresholds from least to most severe
        level_name = "normal"
        sizing_mult = 1.0
        halt_new = False
        forced_cut = 0.0
        reason = f"DD {dd*100:+.2f}% from peak ₹{self.peak_equity:,.0f}"
        for threshold, name, mult, _ in DRAWDOWN_LEVELS:
            if dd <= threshold:
                level_name = name
                sizing_mult = mult
                if name in {"stop_adding", "cut_half", "mostly_cash", "full_halt"}:
                    halt_new = True
                if name == "cut_half":
                    forced_cut = 0.50
                elif name == "mostly_cash":
                    forced_cut = 0.80
                elif name == "full_halt":
                    forced_cut = 1.0
        self.active_level = level_name
        self.sizing_multiplier = sizing_mult
        self.halt_new_entries = halt_new
        self.forced_cut = forced_cut
        self.reason = reason

    def snapshot(self) -> dict:
        return {
            "level": self.active_level,
            "peak": self.peak_equity,
            "current": self.last_equity,
            "drawdown_pct": (
                (self.last_equity - self.peak_equity) / self.peak_equity * 100
                if self.peak_equity > 0 else 0.0
            ),
            "sizing_multiplier": self.sizing_multiplier,
            "halt_new_entries": self.halt_new_entries,
            "forced_cut": self.forced_cut,
            "reason": self.reason,
        }


# ============================================================================
# 2. CORRELATION GATE
# ============================================================================

def daily_returns(close: pd.Series, n: int = 60) -> Optional[pd.Series]:
    if close is None or len(close.dropna()) < n + 1:
        return None
    return close.dropna().iloc[-(n + 1):].pct_change().dropna()


def correlation(a: pd.Series, b: pd.Series) -> Optional[float]:
    if a is None or b is None or a.empty or b.empty:
        return None
    df = pd.concat([a, b], axis=1, keys=["a", "b"]).dropna()
    if len(df) < 20:
        return None
    return float(df["a"].corr(df["b"]))


def correlation_gate_blocks(
    candidate_returns: Optional[pd.Series],
    open_position_returns: dict[str, pd.Series],
    threshold: float = 0.70,
) -> Optional[tuple[str, float]]:
    """Returns (existing_ticker, corr) if candidate correlates > threshold
    with ANY open position. Returns None if safe to add.
    """
    if candidate_returns is None or candidate_returns.empty:
        de.record("correlation", threshold=threshold, state="unavailable", reason="Candidate return history unavailable; existing policy allows")
        return None
    measured = {}
    for ticker, ret in open_position_returns.items():
        c = correlation(candidate_returns, ret)
        if c is not None and math.isfinite(c):
            measured[ticker] = c
        if c is not None and c > threshold:
            de.record("correlation", {"blocker": ticker, "correlation": c, "pairs_checked": len(measured)}, threshold, passed=False)
            return (ticker, c)
    de.record("correlation", {"max": max(measured.values()) if measured else None, "pairs_checked": len(measured), "held_pairs": len(open_position_returns)}, threshold,
              state=("skipped" if not open_position_returns else "unavailable" if not measured else None), passed=True,
              reason="No held comparison" if not open_position_returns else "Only comparable histories checked")
    return None


# ============================================================================
# 3. VOL-ADJUSTED POSITION SIZING (3 TIERS) — DELETED 2026-08-30
# ============================================================================
#
# This section used to define TIER_THRESHOLDS (18% / 12% / 6% of equity by
# annualised volatility band) plus annualised_vol_pct, vol_tier and
# vol_adjusted_qty. It was NEVER wired: engine.py imported vol_adjusted_qty
# and never called it, and that import was removed in the 2026-08-09 audit.
# The code stayed behind, documented like a live control, with tests
# exercising it — which is exactly how an external reviewer read it as an
# active sizing scheme (F-009, 2026-08-29 review; the owner ordered it
# fixed).
#
# It is gone rather than commented out because the live sizing rule is not
# in dispute: a new Everest trade is a fixed Rs 1,25,000 (owner order
# 2026-07-30) and an Ocean trade half that (owner approval 2026-08-26),
# both through trading/sizing.position_notional_for. A second, contradictory
# sizing scheme sitting in the risk module can only mislead.
#
# The REST of this module is live and must not be confused with it:
# DrawdownGovernor, ConsecutiveLossTracker, dynamic_cash_reserve_pct,
# correlation_gate_blocks and passes_liquidity all run in the money path.
# A guard test asserts the vol-tier names never come back.


# ============================================================================
# 4. HARD LIQUIDITY FILTERS
# ============================================================================

@dataclass
class LiquidityRules:
    # NO share-count floor. Until 2026-09-08 this gate also demanded 200,000
    # shares a day, which a high-priced stock never reaches however liquid it
    # is: THERMAX (~136k shares but Rs 48 Cr a day) and GODFRYPHLP (~191k,
    # Rs 31 Cr) were blocked from entry while penny names sailed through —
    # the share-count trap the weekly universe batch already avoids by
    # ranking on rupee turnover (trading/universe_select.py). The owner
    # ordered it fixed ("fix both faults"); liquidity is measured in rupees
    # here, exactly as it is there. A guard test keeps the old field out.
    min_rupee_volume_5d_cr: float = 5.0              # min ₹5 Cr daily rupee turnover (avg over 5d)
    max_spread_pct: float = 0.001                    # 0.1% bid-ask (Upstox-derived; soft when no live quote)
    min_market_cap_cr: float = 5_000.0               # min ₹5,000 Cr free-float mcap
    require_no_circuit: bool = True                  # skip if at upper/lower circuit today


def passes_liquidity(
    close: pd.Series,
    volume: pd.Series,
    last_high: Optional[float] = None,
    last_low: Optional[float] = None,
    last_open: Optional[float] = None,
    last_close: Optional[float] = None,
    market_cap_cr: Optional[float] = None,
    spread_pct: Optional[float] = None,
    rules: Optional[LiquidityRules] = None,
) -> tuple[bool, str]:
    """Returns (passes, reason). reason is empty on pass.

    market_cap_cr and spread_pct are checked when provided (caller pulls them
    from Upstox quote / yfinance fast_info). When None, the corresponding
    check is skipped — keeps the gate from blocking on missing reference data.
    """
    rules = rules or LiquidityRules()

    have = close is not None and volume is not None and len(close.dropna()) >= 20
    de.record("liquidity_history", len(close.dropna()) if close is not None else None, 20,
              state="passed" if have else "unavailable")
    if close is None or volume is None or len(close.dropna()) < 20:
        return False, "insufficient_history"

    # Rupee volume (price * vol, avg of 5 days, in Crores) — the ONE liquidity
    # measure (see LiquidityRules for why the share count was removed)
    rupee_vol = (close.iloc[-5:] * volume.iloc[-5:]).dropna().mean()
    rupee_vol_cr = float(rupee_vol) / 1e7
    de.record("turnover", rupee_vol_cr, rules.min_rupee_volume_5d_cr,
              passed=rupee_vol_cr >= rules.min_rupee_volume_5d_cr,
              state=None if math.isfinite(rupee_vol_cr) else "unavailable", reason="5-bar average INR crore")
    if rupee_vol_cr < rules.min_rupee_volume_5d_cr:
        return False, f"rupee_vol {rupee_vol_cr:.2f}Cr < {rules.min_rupee_volume_5d_cr}Cr"

    # Market cap hard floor (only when provided)
    de.record("market_cap", market_cap_cr, rules.min_market_cap_cr,
              state="skipped" if market_cap_cr is None else None,
              passed=market_cap_cr is not None and market_cap_cr >= rules.min_market_cap_cr,
              reason="Not requested by current scan" if market_cap_cr is None else "INR crore")
    if market_cap_cr is not None and market_cap_cr < rules.min_market_cap_cr:
        return False, f"mcap {market_cap_cr:.0f}Cr < {rules.min_market_cap_cr:.0f}Cr"

    # Spread hard ceiling (only when provided — live quote required)
    de.record("spread", spread_pct, rules.max_spread_pct,
              state="unavailable" if spread_pct is None else None,
              passed=spread_pct is not None and spread_pct <= rules.max_spread_pct,
              reason="No bid/ask; existing policy allows" if spread_pct is None else "Bid/ask fraction")
    if spread_pct is not None and spread_pct > rules.max_spread_pct:
        return False, f"spread {spread_pct*100:.3f}% > {rules.max_spread_pct*100:.2f}%"

    # Circuit-filter check: open == high == low == close means stuck at circuit
    known = None not in (last_open, last_high, last_low, last_close)
    de.record("circuit", [last_open, last_high, last_low, last_close], "OHLC must not all equal",
              state="skipped" if not rules.require_no_circuit else "unavailable" if not known else None,
              passed=not (last_open == last_high == last_low == last_close))
    if rules.require_no_circuit and None not in (last_open, last_high, last_low, last_close):
        if last_open == last_high == last_low == last_close:
            return False, "stuck_at_circuit"

    return True, ""


# ============================================================================
# 5a. DYNAMIC CASH RESERVE (regime-aware)
# ============================================================================

# P2/B2: bull/neutral deploy fully (user: 100% in good markets); genuine
# stress regimes force protective cash back in.
DYNAMIC_CASH_RESERVE = {
    "bull_extension": 0.00,
    "neutral":        0.00,
    "correction":     0.20,
    "panic":          0.40,
}


def dynamic_cash_reserve_pct(regime_name: Optional[str], floor: float = 0.20) -> float:
    """Returns the cash reserve fraction (0..1) for the given regime.

    Defaults to `floor` when regime is unknown — protects against under-
    reserving when the classifier hasn't run yet.
    """
    if not regime_name:
        return floor
    return DYNAMIC_CASH_RESERVE.get(regime_name, floor)


# ============================================================================
# 6. CONSECUTIVE LOSS HALT
# ============================================================================

# AUDIT F-10 (owner: "go for next", 2026-10-02). Two losing closes in one
# day halted ALL entries whatever the book size — on a 222-position ceiling,
# two ordinary -5% stops on a 100-name book stopped the whole engine for the
# day — and it counted closes that are no verdict on the strategy at all
# (owner sells, kill switch, drawdown ladder, retag, square-off).
#
# Now: only strategy exits count (the SAME classification the measured-Kelly
# estimator uses, trading/measured_kelly.classify — one definition, not two;
# an unrecognised reason still counts, the conservative side), and the limit
# grows with the book: max(2, ceil(10% of the day's book)).
#
# OWNER ORDER 2026-10-21 ("Halt only the category that lost"): each losing
# close is recorded with its category (momentum / intraday / short / swing /
# positional / ocean, category_budget.category_of at close) and the
# halt is judged PER CATEGORY — losing exits today in that category >=
# max(2, ceil(10% x (open positions in that category + its losing exits
# today))). Two losing momentum exits halt momentum for the day; the other
# four keep buying. cfg.loss_halt_scope = "book" keeps the old book-wide
# rule (the backtest never ran this halt at all).
# LOSS_HALT_BOOK_FRACTION is ASSUMED — no study in this repo measured it; 2
# stays the floor so a small book behaves exactly as before.
LOSS_HALT_BOOK_FRACTION = 0.10


def counts_toward_loss_halt(reason: Optional[str]) -> bool:
    """True when a losing close should count toward the daily halt."""
    if reason is None:
        return True
    from .measured_kelly import classify
    return classify(reason) != "excluded"


LOSS_HALT_SCOPES = ("category", "book")
# Historical 2026-10-21 owner counters remain ungated until normal rollover.
# Since 2026-11-03 new owner-added positions close under their stored strategy.
# Manual entry paths still do not invoke this automatic-scan halt.
LOSS_HALT_UNGATED = ("owner",)


@dataclass
class ConsecutiveLossTracker:
    today: Optional[date] = None
    losses_today: int = 0
    max_consecutive: int = 2  # the floor: halt at 2 losers on a small book
    book_size: int = 0        # open positions + today's counted losers
    # Owner order 2026-10-21: losing exits today PER CATEGORY, and the last
    # open-position count read for each (for the per-category 10% rule).
    by_category: dict = field(default_factory=dict)
    open_by_category: dict = field(default_factory=dict)

    def limit(self, book_size: Optional[int] = None) -> int:
        n = self.book_size if book_size is None else int(book_size)
        return max(int(self.max_consecutive),
                   int(math.ceil(LOSS_HALT_BOOK_FRACTION * max(0, n))))

    def losses_in(self, category: Optional[str]) -> int:
        return int(self.by_category.get(category, 0) or 0) if category else 0

    def category_limit(self, category: str,
                       open_in_category: Optional[int] = None) -> int:
        """max(2, ceil(10% x (open in the category + its losers today))."""
        if open_in_category is not None:
            self.open_by_category[category] = int(open_in_category)
        n = int(self.open_by_category.get(category, 0) or 0)
        return self.limit(n + self.losses_in(category))

    def record_close(self, exit_date: date, net_pnl: float,
                     reason: Optional[str] = None,
                     category: Optional[str] = None) -> None:
        """Call when a position closes. Resets count on a new day.
        `category` = the closed position's category (category_budget.
        category_of); None keeps the book-wide count only."""
        if self.today != exit_date:
            self.today = exit_date
            self.losses_today = 0
            self.by_category = {}
        if net_pnl < 0 and counts_toward_loss_halt(reason):
            self.losses_today += 1
            if category:
                self.by_category[category] = self.losses_in(category) + 1

    def halted(self, today: Optional[date] = None,
               open_positions: Optional[int] = None,
               category: Optional[str] = None,
               open_in_category: Optional[int] = None,
               scope: str = "book") -> bool:
        """scope "book" (the pre-2026-10-21 rule, the default here so old
        callers keep their meaning) judges the whole book; "category" judges
        ONLY `category`'s own losers against its own 10% rule."""
        if open_positions is not None:
            # the book the day started with: still open + already lost
            self.book_size = int(open_positions) + int(self.losses_today)
        today = today or self.today
        if today != self.today:
            return False
        if scope == "category" and category:
            if (self.losses_in(category)
                    >= self.category_limit(category, open_in_category)):
                return True
            # Losers saved by the code before this order carry no category
            # (the deploy itself is a restart). Until today's record is
            # fully categorised the whole-book rule stands, so a restart
            # never forgets a halt that was already on.
            return bool(self.uncategorised()) and self.losses_today >= self.limit()
        return self.losses_today >= self.limit()

    def uncategorised(self) -> int:
        """Today's losers recorded with no category (a book saved before
        2026-10-21); 0 once every loser carries one."""
        return max(0, int(self.losses_today)
                   - sum(int(v or 0) for v in self.by_category.values()))

    def _live(self, today: Optional[date]) -> bool:
        """Are the counts today's? None = trust the tracker's own day."""
        return today is None or today == self.today

    def category_rows(self, open_by_category: Optional[dict] = None,
                      today: Optional[date] = None) -> list:
        """One row per category seen today or holding positions: losses,
        open, max_allowed, gated, halted (the per-category rule)."""
        if open_by_category is not None:
            # the caller's map is the whole book: replace, never merge, or a
            # category whose positions all closed keeps its old count
            self.open_by_category = {str(k): int(v)
                                     for k, v in open_by_category.items()}
        live = self._live(today)
        lost_map = dict(self.by_category) if live else {}
        cats = sorted(set(lost_map) | set(self.open_by_category))
        rows = []
        for c in cats:
            lost = int(lost_map.get(c, 0) or 0)
            n = int(self.open_by_category.get(c, 0) or 0)
            lim = self.limit(n + lost)
            gated = c not in LOSS_HALT_UNGATED
            rows.append({"category": c, "losses": lost, "open": n,
                         "max_allowed": lim, "gated": gated,
                         "halted": gated and lost >= lim})
        return rows

    def snapshot(self, open_positions: Optional[int] = None,
                 open_by_category: Optional[dict] = None,
                 scope: str = "book",
                 today: Optional[date] = None) -> dict:
        """`today` = the engine's date. Counts from an earlier day read 0:
        the gate halts nothing on a new day and the counts reset at its
        first close, so the screen must not print yesterday's halt."""
        if open_positions is not None:
            self.book_size = int(open_positions) + int(self.losses_today)
        live = self._live(today)
        rows = self.category_rows(open_by_category, today=today)
        losses = int(self.losses_today) if live else 0
        if open_positions is not None:
            max_allowed = self.limit(int(open_positions) + losses)
        else:
            max_allowed = self.limit()
        book_halted = live and losses >= max_allowed
        uncat = self.uncategorised() if live else 0
        halted_cats = [r["category"] for r in rows if r["halted"]]
        return {
            "today": self.today.isoformat() if self.today else None,
            "losses_today": losses,
            "max_allowed": max_allowed,
            "scope": scope,
            "categories": rows,
            "halted_categories": halted_cats,
            "book_halted": book_halted,
            # losers saved before per-category counting: the book rule stands
            "uncategorised": uncat,
            # what is halted NOW under the live scope
            "halted": (book_halted if scope != "category"
                       else bool(halted_cats) or (bool(uncat) and book_halted)),
        }
