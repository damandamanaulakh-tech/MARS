"""The thing that actually runs.

scan() -> rank universe by AM 07 score, optionally enter top picks
refresh() -> mark positions to latest prices, fire exits
A typical day:
  1. user opens dashboard -> engine.refresh() updates everything
  2. user clicks "run scan" (or it auto-runs once before market open)
  3. engine.scan() returns ranked picks and opens those that pass timing + risk
  4. through the session, engine.refresh() exits anything that hits a rule
"""

from __future__ import annotations

import copy
import logging
import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, List, Optional

import pandas as pd

log = logging.getLogger(__name__)

# Owner order 2026-10-21 (the BLSE split): one ex-date adjustment at a time
# (the scheduler thread and a web refresh must never both double a position),
# and the names adjusted since the scheduler last re-fetched their history.
import threading as _threading
_CA_LOCK = _threading.Lock()
CA_REFETCH_DUE: set = set()

from .config import Config, STUB_COMPONENTS
from .costs import slippage_price
from . import fees
from .data import fetch_daily
from .quote_router import fetch_quotes as routed_fetch_quotes
from .exits import check_exit
from .paper import ClosedTrade, PaperPosition, Portfolio
from . import portfolio_marks as pm
from . import intraday_recovery as ir
from . import decision_evidence as de
from . import quote_evidence as qe
from . import intraday_bars as ib, intraday_data as idata, intraday_scoring as isc
from . import context_inputs as ci
from .calendars import is_market_open, market_state
from .candles import candle_assessment
from .risk import RiskState, can_open
from .scoring import (
    MOMENTUM_MODE, compute_hot_sectors, compute_score, reasoning_text,
    score_for_mode, set_scoring_context, weights_for,
)
from .timing import timing_ok


@dataclass
class ScanResult:
    ts: datetime
    ranked: List[dict]            # all symbols with their scores (for debugging)
    picks: List[dict]             # subset that pass min_score + timing
    opened: List[str]             # actually opened (passed risk gates too)
    skipped: List[dict]           # for the picks we couldn't open, why


def _level(price: float, pct: float) -> str:
    """A held position's stop/target for the journal: its own stored price
    when it has one, else the category percentage."""
    if price and price > 0:
        return f"₹{float(price):,.2f}"
    return f"{float(pct) * 100:+.0f}%"


class TradingEngine:
    def __init__(self, cfg: Config, portfolio: Portfolio):
        self.cfg = cfg
        self.portfolio = portfolio
        self.risk = RiskState(cfg=cfg, starting_capital=cfg.starting_capital)
        # Optional broker client for real-time quotes. Set via .attach_broker()
        # so the engine module stays free of web/auth deps.
        self.broker = None  # UpstoxClient | None
        # v5: graduated drawdown + consecutive-loss controls (stateful, persist
        # across scans within a session)
        from .risk_v2 import ConsecutiveLossTracker, DrawdownGovernor
        self.drawdown_gov = DrawdownGovernor()
        self.loss_tracker = ConsecutiveLossTracker()
        # AUDIT FIX C11: hydrate the 2-loss daily halt from the portfolio —
        # it was memory-only, so a mid-day restart forgot the halt on
        # exactly the kind of day it exists for.
        try:
            from datetime import date as _date
            if getattr(portfolio, "loss_day", None):
                self.loss_tracker.today = _date.fromisoformat(portfolio.loss_day)
                self.loss_tracker.losses_today = int(portfolio.loss_count or 0)
                # owner order 2026-10-21: the per-category counts too
                self.loss_tracker.by_category = {
                    str(k): int(v) for k, v in
                    (getattr(portfolio, "loss_by_category", None) or {}).items()}
        except (ValueError, TypeError, AttributeError):
            pass

    def attach_broker(self, broker_client) -> None:
        """Plug in a broker client (e.g. UpstoxClient) for real-time quotes.

        When attached, refresh() routes quote lookups through the broker first
        and falls back to yfinance for any unknown instruments. Passing None
        reverts to pure yfinance behaviour.
        """
        self.broker = broker_client

    # ---------- public API ----------

    def scan_universe(self, history_period: str = "6mo") -> tuple:
        """Which tickers today's scan reads, and how much history.

        Extracted from scan() 2026-08-20 (unchanged logic + one new branch)
        so the selection is testable on its own. Priority in momentum mode:
          1. cfg.custom_universe — OWNER ORDER 2026-08-20 ("reduce the
             universe to 50 share only but all fresh"): the exact list, no
             rotation, scanned in full every day. Held names always ride
             along so exits/correlation keep their history.
          2. the rotating full-NSE bucket (P1, evidence-earned breadth).
          3. Nifty 200 when full_universe_scan is off.
        The owner blocklist applies to EVERY branch — a banned name cannot
        enter via the custom list either.
        """
        cfg = self.cfg
        held = list(self.portfolio.positions.keys())
        custom = tuple(getattr(cfg, "custom_universe", ()) or ())
        # REVIEW FIX (PR #68): the custom list applies to EVERY mode,
        # not only momentum — the 09:20 rotation also runs short/swing/
        # positional, each of which can OPEN positions, so a momentum-only
        # restriction would have let the other three passes buy outside the
        # owner's 50 and overwrite /scan with off-list results. "Reduce the
        # universe to 50" means the app's universe, not one mode's.
        if custom and cfg.mode != "nifty200_momentum":
            universe = list(dict.fromkeys(held + list(custom)))
            try:
                from .universes import apply_blocklist, drop_fund_units
                universe = apply_blocklist(
                    universe, self.portfolio.positions.keys(),
                    getattr(cfg, "ticker_blocklist", ()))
                # 2026-10-16: fund units (INF ISIN) are not stocks — see
                # universes.drop_fund_units. Held ones stay for their exits.
                universe = drop_fund_units(universe,
                                           self.portfolio.positions.keys())
            except ImportError:
                pass
            return universe, history_period
        # v5: nifty200_momentum mode needs 2 years of history for the
        # momentum_score() to be valid.
        # P1 (search v2.1 evidence, user-approved 2026-07-19): momentum's
        # edge lives at BREADTH — scan the FULL 2,376 NSE universe via the
        # deterministic rotating bucket (~50 fresh names/day, complete
        # coverage each cycle) instead of only Nifty 200. Held tickers are
        # always included so exits/correlation keep their history. The live
        # liquidity + min-value gates do the tradability filtering the
        # close-only research panel could not.
        if cfg.mode == "nifty200_momentum":
            history_period = "2y"
            try:
                if custom:
                    universe = list(dict.fromkeys(held + list(custom)))
                elif getattr(cfg, "full_universe_scan", False):
                    from .universes import (NIFTY_200_TICKERS,
                                            load_full_universe,
                                            rotating_bucket)
                    full = load_full_universe()
                    if full:
                        bucket = rotating_bucket(
                            full, 50, datetime.utcnow().date().toordinal())
                    else:
                        bucket = NIFTY_200_TICKERS
                    universe = list(dict.fromkeys(held + bucket))
                else:
                    from .universes import NIFTY_200_TICKERS
                    universe = NIFTY_200_TICKERS
            except ImportError:
                universe = cfg.universe
        else:
            universe = cfg.universe
        # Owner blocklist (2026-07-21): banned names never enter any scan
        # path; held ones stay visible so exits keep working.
        try:
            from .universes import apply_blocklist, drop_fund_units
            universe = apply_blocklist(
                universe, self.portfolio.positions.keys(),
                getattr(cfg, "ticker_blocklist", ()))
            universe = drop_fund_units(universe,
                                       self.portfolio.positions.keys())
        except ImportError:
            pass
        return universe, history_period

    def scan(self, history_period: str = "6mo") -> ScanResult:
        self.square_off_intraday()  # overdue exits precede slow history/scoring
        cfg = self.cfg
        universe, history_period = self.scan_universe(history_period)
        history = fetch_daily(universe, period=history_period)
        # 2026-09-11: fetch_daily is store-first and BOUNDS its network
        # fallback, so a scan can legitimately cover fewer names than it
        # asked for while the store fills. Say so in the journal rather than
        # letting a 1,200-name universe read as fully scanned when 170 names
        # were seen — the lying-screen fault class. Captured before the
        # benchmark fetch below overwrites the stats.
        from .data import LAST_FETCH_STATS as _fs
        cover = dict(_fs)
        bench = fetch_daily([cfg.benchmark], period=history_period).get(cfg.benchmark)
        # Daily panels retain their daily purpose: liquidity, breadth, regime,
        # damage and risk sizing. Intraday signals have a separate validated path.
        signal_history, signal_bench = history, bench
        intraday_details = {}
        if cfg.mode == "intraday":
            from .data import MAX_NETWORK_FALLBACK
            offset = (self.portfolio.intraday_data_status or {}).get("next_offset", 0)
            signal_history, intraday_details = idata.fetch(
                [cfg.benchmark] + list(universe), cfg, self.broker, datetime.utcnow(),
                offset=offset, priority=[cfg.benchmark])
            signal_bench = signal_history.get(cfg.benchmark)
            signal_history = {t: f for t, f in signal_history.items() if t != cfg.benchmark}
            self.portfolio.intraday_data_status = {
                "at": intraday_details.get(cfg.benchmark, {}).get("asof", de.stamp()),
                "interval": "5m", "asked": len(universe),
                "ready": sum(t in signal_history for t in universe),
                "next_offset": (offset + max(0, MAX_NETWORK_FALLBACK - 1)) % max(1, len(universe)),
                "request_cap": MAX_NETWORK_FALLBACK, "deadline_seconds": idata.FETCH_BUDGET_SECONDS,
                "windows": ib.window_description(cfg),
                "benchmark": intraday_details.get(cfg.benchmark),
                "rows": {t: intraday_details[t] for t in universe}}
        decisions = {t: de.new(t, cfg.mode, "scan", datetime.utcnow(), signal_history.get(t))
                     for t in universe}
        context_inputs = ci.prepare(universe, cfg, datetime.utcnow(), client=self.broker)
        for t, d in decisions.items():
            d["market_context"] = ci.observation(context_inputs, t, signal_history.get(t), signal_bench, cfg, datetime.utcnow())
            h = signal_history.get(t)
            info = intraday_details.get(t)
            de.put(d, "history", len(h) if h is not None else None,
                   "completed current-session 5m bars with full lookback" if info else "usable daily history",
                   state="passed" if h is not None and not h.empty else "unavailable",
                   reason=info["reason"] if info else "Actual scan path uses daily bars")
            d["benchmark"] = {"ticker": cfg.benchmark, **(intraday_details.get(cfg.benchmark) or de.bar_context(signal_bench))}
            if info:
                d["bar"] = de.clean(info)
                d["daily_context"] = de.bar_context(history.get(t))
                d["windows"] = ib.window_description(cfg)
                de.put(d, "intraday_data", info, "completed, aligned, current session, contiguous required window",
                       state="passed" if info["status"] == "ready" else "unavailable", reason=info["reason"])
        if cover.get("asked") and cover.get("covered", 0) < cover["asked"]:
            self._journal_once_a_day("SCAN_COVERAGE_SHORT", datetime.utcnow(), {
                "asked": cover["asked"], "covered": cover["covered"],
                "from_store": cover.get("from_store"),
                "from_network": (cover.get("from_upstox", 0)
                                 + cover.get("from_yahoo", 0)),
                "not_fetched_cap": cover.get("not_fetched_cap"),
                "why": (f"Scanned {cover['covered']} of {cover['asked']} names "
                        f"({cover.get('from_store', 0)} from the stored "
                        f"history, "
                        f"{cover.get('from_upstox', 0) + cover.get('from_yahoo', 0)}"
                        f" fetched). "
                        + (f"{cover['not_fetched_cap']} were left for the "
                           f"off-hours top-up so the scan window could close."
                           if cover.get("not_fetched_cap") else
                           "The rest had no usable history.")),
            })

        # v4: regime-aware. If Ocean is the active engine (panic/correction),
        # Everest is dormant. Either way we score everything so the UI shows
        # full ranking; only the entry-filtering changes per engine.
        regime = None
        try:
            from .regime import fetch_regime
            # FIX (2026-07-12): wire real FII/DII net into the regime. Live NSE
            # feed 403s from cloud → committed data/fii_dii_cash.csv fallback.
            # classify() already treats FII net-selling < -1000 Cr as a
            # correction confirm; it was ALWAYS None before (never fed).
            fii_5d = None
            try:
                from .signals.flows import get_flows, fii_net_last_n_days
                fii_5d = fii_net_last_n_days(get_flows(), n=5)
            except Exception as e:
                log.debug("FII flow fetch failed: %s", e)
            regime = fetch_regime(fii_5d_net_override=fii_5d)
        except Exception as e:
            log.warning("Regime classification failed: %s", e)
            # AUDIT FIX C7 (2026-08-09): regime=None used to FAIL OPEN — the
            # `regime is None or everest_active` gate re-enabled full-size
            # buying with the correction brake silently gone, exactly when a
            # broken feed is most likely (a panic). The last KNOWN regime is
            # sticky instead: if we were in correction/panic yesterday, the
            # brake stays on until the feed answers again; journaled once/day.
            last_known = (self.portfolio.last_regime or "").lower()
            if last_known in ("correction", "panic"):
                today_key = datetime.utcnow().date().isoformat()
                already = any(
                    e2.get("action") == "REGIME_FEED_DOWN"
                    and str(e2.get("ts", "")).startswith(today_key)
                    for e2 in self.portfolio.decision_journal[-100:])
                if not already:
                    self.portfolio.decision_journal.append({
                        "ts": datetime.utcnow().isoformat(),
                        "action": "REGIME_FEED_DOWN",
                        "why": (f"Regime feed failed and the last known regime "
                                f"was {last_known.upper()} — the correction "
                                "brake STAYS ON until the feed answers."),
                    })
                regime_feed_down_brake = True
            else:
                regime_feed_down_brake = False
        else:
            regime_feed_down_brake = False

        # v5: detect regime switch + persist + notify
        if regime is not None and regime.regime != self.portfolio.last_regime:
            entry = {
                "ts": datetime.utcnow().isoformat(),
                "prev": self.portfolio.last_regime,
                "new": regime.regime,
                "reason": regime.reasoning,
            }
            self.portfolio.regime_history.append(entry)
            try:
                from .alerts import notify_regime_switch
                notify_regime_switch(
                    self.portfolio.last_regime or "unknown",
                    regime.regime, regime.reasoning,
                )
            except Exception:
                pass
            self.portfolio.last_regime = regime.regime

        # F2: festival/seasonal context — journaled so the ⚡card and the
        # journal show WHY seasonal names may be moving. Flag only, no alpha.
        # FIX (2026-07-12): `now` was referenced here but only defined ~150
        # lines later, so this block silently NameError'd every scan (festival
        # journaling never fired). Define it up front.
        now = datetime.utcnow()

        # Roll the daily loss-halt baseline at the day's FIRST engine action,
        # BEFORE _record_equity appends today's marks. Recheck fixes
        # (2026-07-27): rolling only inside refresh() meant (a) the 15:35 call
        # measured "daily" loss from today's own 14:30 mark — a one-hour
        # window — and (b) a kill-switch liquidation emptied the book, which
        # made refresh() early-return forever, so the tripped switch never
        # re-armed and all automatic buying stayed dead until a restart.
        # Roll after assembling the held-book marks below, before any new
        # equity point. Entry-only gaps cannot establish a new loss baseline.

        # AUDIT FIX A3 (2026-08-09): the -2% daily halt was EVALUATED only in
        # refresh() (15:35), so the 09:20 scan and the 14:30 top-up happily
        # bought on a day already past the halt — buy-at-2pm, force-sell-at-
        # 3:35 churn on exactly the worst days. Evaluate it here with live
        # marks on the held book; can_open then blocks every new entry with
        # "kill_switch_active". Retain earlier observed marks when a quote
        # is absent; never trip a halt on an entry-only valuation gap.
        # Owner order 2026-10-21 (BLSE): a held name's split must be absorbed
        # before the kill switch below marks the book on live quotes — a
        # halved quote on an unadjusted position reads as a crash.
        if self.portfolio.positions:
            self._absorb_corporate_actions("scan")
        held_now = list(self.portfolio.positions.keys())
        held_px: dict = {}
        if held_now:
            try:
                held_px = routed_fetch_quotes(held_now, upstox_client=self.broker)
            except Exception:
                held_px = {}
        held_px = {t: px for t, value in (held_px or {}).items()
                   if (px := pm.positive_price(value)) is not None}
        risk_marks = self._freshest_marks(held_px, history)
        marks_ready = self._risk_marks_ready(risk_marks, now)
        if (marks_ready or self.portfolio.equity_history
                or self.portfolio.risk_day == now.date().isoformat()):
            self._roll_risk_day(self.portfolio.equity(risk_marks), now)
        if held_now:
            if marks_ready and self.risk.check_kill_switch(self.portfolio.equity(risk_marks)):
                if not self.portfolio.risk_day_killed:
                    self.portfolio.decision_journal.append({
                        "ts": now.isoformat(), "action": "KILL_SWITCH_SCAN",
                        "why": (f"Daily loss past {self.cfg.daily_loss_halt_pct:.1%} "
                                "at scan time — new entries blocked for the day."),
                    })
                self.portfolio.risk_day_killed = True
        elif self.risk.check_kill_switch(self.portfolio.equity({})):
            # empty book = all cash, equity is exact without quotes
            self.portfolio.risk_day_killed = True

        try:
            from .calendars import festival_context
            fest = festival_context(days=5)
            if fest:
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(),
                    "action": "CONTEXT",
                    "festival": fest,
                    "why": f"Festival window active: {fest} — seasonal demand context.",
                })
        except Exception as e:
            log.debug("Festival context skipped: %s", e)

        # P2/B2: dynamic cash reserve — 0% in bull/neutral (deploy fully) but
        # correction/panic force protective cash back in.
        if regime is not None:
            try:
                from .risk_v2 import dynamic_cash_reserve_pct
                cfg.cash_reserve_pct = dynamic_cash_reserve_pct(
                    regime.regime, floor=0.0,
                )
            except Exception:
                pass

        # v5: alternative scoring path for nifty200_momentum mode
        n200_scorer = None
        if cfg.mode == "nifty200_momentum":
            try:
                from .strategies.nifty200_momentum import momentum_score as n200_scorer
            except ImportError:
                n200_scorer = None

        # v5: build shared scoring context (FII tide + hot sectors) once per scan
        fii_score = None
        try:
            from .signals.flows import (
                get_flows, fii_flow_score, fii_net_last_n_days,
            )
            flows = get_flows()   # live NSE -> committed CSV, staleness-guarded
            fii_5d = fii_net_last_n_days(flows, n=5)
            # pass how many days the sum really covers — the live endpoint
            # returns ONE day, so an un-normalised 5-day threshold would read a
            # strong single day as a weak week (fixed 2026-07-31)
            fii_score = fii_flow_score(fii_5d, days=min(len(flows or []), 5) or 5)
        except Exception as e:
            log.debug("FII scoring context skipped: %s", e)

        try:
            hot_sectors = compute_hot_sectors(
                {t: history[t] for t in universe if t in history},
                cfg.sector_map, cfg,
            )
        except Exception:
            hot_sectors = set()

        set_scoring_context(fii_score=fii_score, hot_sectors=hot_sectors)

        ranked: List[dict] = []
        for t in universe:
            if t not in signal_history or signal_history[t].empty:
                continue
            if cfg.mode == "intraday":
                score, components, intraday_diag = isc.compute(
                    t, signal_history[t], signal_bench, signal_history, cfg, datetime.utcnow())
                decisions[t]["intraday_score"] = intraday_diag
                if score is None:
                    de.put(decisions[t], "score", state="unavailable", reason=intraday_diag["reason"])
                    continue
                reasoning = reasoning_text(components, score, weights_for(cfg.mode))
                reasoning += " Completed 5m bars; rolling windows recorded in evidence."
            elif n200_scorer is not None:
                ms = n200_scorer(history[t]["Close"])
                if ms is None:
                    de.put(decisions[t], "score", threshold=cfg.min_score_to_enter,
                           state="unavailable", reason="Insufficient momentum history")
                    continue
                # C1: blend a value/quality tilt (low-vol + liquidity) into the
                # momentum rank so the book isn't 100% high-beta leaders.
                from .quality import quality_score, blend_scores
                q = quality_score(history[t]["Close"], history[t].get("Volume"))
                b = getattr(cfg, "quality_blend_pct", 0.0)
                score = blend_scores(ms, q, b)
                components = {"momentum": round(ms, 1), "quality": round(q, 1)}
                reasoning = (
                    f"MOM {ms:.0f} + QUALITY {q:.0f} (blend {int(b*100)}%) = {score:.0f}"
                )
            else:
                score, components = compute_score(t, history[t], bench, history,
                                                  cfg, mode=cfg.mode)
                from .scoring import weights_for as _wf
                reasoning = reasoning_text(components, score, _wf(cfg.mode))
            de.put(decisions[t], "score", score, cfg.min_score_to_enter,
                   passed=score >= cfg.min_score_to_enter)
            decisions[t]["components"] = de.clean(components)
            decisions[t]["multi_formula_interval"] = "1d"
            from .scoring import weights_for as evidence_weights
            decisions[t]["weights"] = de.clean({"momentum": 1-b, "quality": b} if n200_scorer is not None else evidence_weights(cfg.mode))
            with de.capture(decisions[t]):
                timing_pass, timing_diag = timing_ok(signal_history[t], cfg)
            # OWNER ORDER 2026-09-11 ("go with these formula" / "ash08 68"):
            # every scanned name carries the ASH08 and AshStocks verdicts
            # beside our own. Computed HERE, where the history is already in
            # hand, so the pages cost one dict lookup and no refetch. Pure
            # function; a failure costs the extra columns, never the scan.
            try:
                from .multi_formula import evaluate as _mf_evaluate
                multi = _mf_evaluate(history[t]["Close"], score,
                                     cfg.min_score_to_enter)
            except Exception:
                log.exception("multi-formula view failed for %s", t)
                multi = None
            ranked.append({
                "ticker": t,
                "decision": decisions[t],
                "score": score,
                "components": components,
                "timing_pass": timing_pass,
                "timing_diag": timing_diag,
                "reasoning": reasoning,
                "multi": multi,
                "last_close": float(signal_history[t]["Close"].iloc[-1]),
                # Carried so _target_for can read the name's own ATR without
                # a second fetch. Never serialised into the portfolio.
                "history": signal_history[t],
                "risk_history": history.get(t),
            })
        ranked.sort(key=lambda r: -r["score"])

        # Engine selection: which picks are eligible for entry today?
        everest_picks: List[dict] = []

        # P0/A2 — ABSOLUTE momentum filter (dual momentum): relative rank alone
        # buys the "least-bad faller" in a weak tape. In momentum mode a pick
        # must also have a positive 6-month return of its own.
        def _abs_mom_ok(t: str) -> bool:
            if cfg.mode != "nifty200_momentum":
                return True
            c = history[t]["Close"].dropna()
            return len(c) > 127 and float(c.iloc[-1]) > float(c.iloc[-127])

        # v4 correction playbook (user-approved 2026-07-21): in a correction
        # the brake holds UNTIL the VIX crushes to <=75% of its recent spike
        # peak — the tested V-recovery signal (docs/archive/PARAM_SEARCH_V4.md:
        # +24% COVID, +7.3% 2022, +2.0% current episode; never fires in
        # mild corrections, so cash remains the default stance).
        vix_reentry = False
        if (regime is not None and not regime.everest_active
                and getattr(cfg, "correction_vix_reentry", False)):
            episode_start = None
            try:
                from .regime import correction_episode_start, vix_crush_ok
                # The v4 study measured the VIX peak from the START of the
                # correction (Nifty's current run below its 200-DMA), not
                # over a fixed window (owner order 2026-10-02, audit item 4).
                nif = fetch_daily([cfg.benchmark], period="2y").get(cfg.benchmark)
                if nif is not None and not nif.empty:
                    episode_start = correction_episode_start(nif["Close"])
                vixd = fetch_daily(["^INDIAVIX"], period="2y").get("^INDIAVIX")
                if (episode_start is not None and vixd is not None
                        and not vixd.empty):
                    vix_reentry = vix_crush_ok(vixd["Close"],
                                               since=episode_start)
            except Exception as e:
                log.warning("VIX-crush check failed: %s", e)
            if vix_reentry:
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(), "action": "CORRECTION_VIX_REENTRY",
                    "episode_start": str(getattr(episode_start, "date",
                                                 lambda: episode_start)()),
                    "why": ("Correction regime, but India VIX has crushed to "
                            "<=75% of its peak since this correction began "
                            "— the v4-tested V-recovery signal. Momentum "
                            "entries re-enabled."),
                })

        # Everest: usual momentum + timing rules. Active in bull/neutral —
        # and in correction once the VIX-crush re-entry signal fires.
        # AUDIT FIX C7: with the feed down, the last known correction/panic
        # keeps the brake on (regime_feed_down_brake) instead of failing open.
        everest_ok = (regime.everest_active if regime is not None
                      else not regime_feed_down_brake)
        # OWNER ORDER 2026-08-09 ("take risk on 200 DMA" -> brake fully
        # off): with correction_brake_enabled False, the CORRECTION regime
        # alone no longer blocks entries. PANIC still does, and a dead
        # regime feed still brakes (C7) — this override needs a live
        # reading that says "correction", never a guess.
        brake_off = (regime is not None and regime.regime == "correction"
                     and not getattr(cfg, "correction_brake_enabled", True))
        if brake_off and not everest_ok:
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "CORRECTION_BRAKE_OFF",
                "why": ("Correction regime (Nifty < 200DMA) but the owner "
                        "has switched the brake off (2026-08-09 order) — "
                        "momentum entries proceed under all other gates."),
            })
        # OWNER-SWITCHED three-formula filter (2026-09-11). DEFAULT OFF: the
        # committed measurement (research/ash_formula_study/) says ASH08's
        # floor removes 3% of our candidates and AshStocks' live rule scored
        # negative in both halves, so the evidence sets the default and the
        # owner sets the switch. Fails open on unjudgeable names.
        def _multi_blocks(r: dict) -> Optional[str]:
            enabled = getattr(cfg, "multi_formula_gate", False)
            if not enabled:
                de.put(r["decision"], "multi_formula", state="skipped", reason="Owner switch off")
                return None
            from .multi_formula import gate_blocks
            blocked = gate_blocks(r.get("multi"))
            de.put(r["decision"], "multi_formula", r.get("multi"), "configured three-formula rules",
                   state="unavailable" if r.get("multi") is None else None,
                   passed=not blocked, reason=blocked or "Unknown inputs retain existing fail-open policy")
            return blocked

        # Collected here, reported below: `skipped` and `now` are not bound
        # until the entry section further down this method.
        multi_blocked: List[dict] = []
        for d in decisions.values():
            de.put(d, "regime", {"reading": regime.regime if regime else None,
                "last_known": self.portfolio.last_regime, "vix_reentry": vix_reentry,
                "brake_off": brake_off, "feed_down_brake": regime_feed_down_brake},
                "Everest active or approved override",
                state="unavailable" if regime is None else None,
                passed=everest_ok or vix_reentry or brake_off,
                reason="Existing last-known regime policy" if regime is None else "")
        if everest_ok or vix_reentry or brake_off:
            everest_picks = []
            for r in ranked:
                if not (r["score"] >= cfg.min_score_to_enter and r["timing_pass"]):
                    continue
                abs_ok = _abs_mom_ok(r["ticker"])
                daily = history.get(r["ticker"])
                close = daily["Close"].dropna() if daily is not None else None
                abs_value = float(close.iloc[-1] / close.iloc[-127] - 1) if close is not None and len(close) > 127 else None
                de.put(r["decision"], "absolute_momentum", abs_value, 0,
                       state="skipped" if cfg.mode != MOMENTUM_MODE else "unavailable" if abs_value is None else None,
                       passed=abs_ok, reason="126-session own return; positive required only in Momentum")
                if not abs_ok:
                    continue
                blocked = _multi_blocks(r)
                if blocked:
                    multi_blocked.append({
                        "ticker": r["ticker"], "reason": blocked,
                        "score": round(float(r["score"]), 1)})
                    continue
                everest_picks.append(r)

        # Node 9, moved up 2026-08-26: the canonical damage reading now
        # computes BEFORE pick assembly so Ocean's rail 2 reads TODAY'S
        # panel, not yesterday's. Same panel IFR reads, same store.
        canonical = None
        try:
            from .internals import damage_reading
            canonical = damage_reading(history)
            if canonical is not None:
                canonical["computed"] = now.isoformat()
                self.portfolio.damage_store = canonical
        except Exception:
            pass

        # Ocean (owner approval 2026-08-26: "Approve as specced") — runs in
        # PARALLEL with Everest in every regime. Its four crash-guard rails
        # replace the momentum gates for dip entries; see _ocean_picks().
        ocean_picks = self._ocean_picks(regime, history, universe, now)
        for pick in ocean_picks:
            d = pick.setdefault("decision", de.new(pick["ticker"], cfg.mode, "ocean", now, history.get(pick["ticker"])))
            d['market_context'] = ci.observation(context_inputs, pick['ticker'],
                signal_history.get(pick['ticker']), signal_bench, cfg, datetime.utcnow())
            decisions[pick["ticker"] + ":ocean"] = d

        picks = everest_picks

        # A3 breadth gate (owner-ordered wire, 2026-07-27; KEPT ON by owner
        # choice 2026-08-26): when half the panel is below its own 200DMA,
        # relative rank is picking least-bad fallers — block new MOMENTUM
        # entries this scan. Ocean picks are exempt BY DESIGN: a dip engine
        # exists exactly for fallen markets, where breadth is always low —
        # gating it here would mean Ocean could never buy at all; its own
        # four rails are its gate. Exits are never touched.
        entries_blocked = False
        breadth_trace = de.new("market", cfg.mode, "context", now)
        breadth_blocked = False
        if picks:
            with de.capture(breadth_trace):
                breadth_blocked = self._breadth_gate_blocks(history, now, n_picks=len(picks), bypass=vix_reentry)
            for pick in picks:
                gate = breadth_trace["gates"].get("breadth")
                if gate:
                    pick["decision"]["gates"]["breadth"] = copy.deepcopy(gate)
                else:
                    de.put(pick["decision"], "breadth", breadth_blocked, False,
                           state="unavailable", reason="Gate returned without input diagnostics")
        if picks and breadth_blocked:
            picks = []
            entries_blocked = True
        elif not picks:
            # S-8: no momentum pick today still owes the later passes a
            # reading (a failure here only costs the cache, never the scan).
            try:
                self._cache_breadth_today(history, now)
            except Exception as e:
                log.warning("breadth cache failed: %s", e)
        picks = picks + ocean_picks

        # v4: HALT NEW ENTRIES around known binary events (elections, RBI, Budget).
        binary_event = None
        binary_event_available = True
        try:
            from .calendars import is_system_event_within
            binary_event = is_system_event_within(days=3)
        except Exception:
            binary_event_available = False

        # v4: Sector blacklist — drop picks in sectors that bled us historically.
        blacklist = set(getattr(cfg, "blacklisted_sectors", []) or [])
        kept = []
        for pk in picks:
            pk.setdefault("decision", de.new(pk["ticker"], cfg.mode, "ocean" if pk.get("ocean") else "scan", now, history.get(pk["ticker"])))
            sec = cfg.sector_map.get(pk["ticker"], "Unknown")
            de.put(pk["decision"], "sector_blacklist", sec, sorted(blacklist),
                   state="skipped" if not blacklist else "unavailable" if sec == "Unknown" else None,
                   passed=sec not in blacklist, reason="Unmapped identity remains unknown")
            if sec not in blacklist:
                kept.append(pk)
        picks = kept

        # v4: Nifty trend gate — only enter if Nifty itself is trending (ADX > N).
        # Skips entries during chop where momentum strategies bleed.
        nifty_chop = False
        nifty_adx = None
        try:
            from .signals.technicals import adx as _adx
            if bench is not None and len(bench) > 30 and cfg.nifty_min_adx > 0:
                nifty_adx = _adx(bench["High"], bench["Low"], bench["Close"])
                if nifty_adx is not None and nifty_adx < cfg.nifty_min_adx:
                    nifty_chop = True
        except Exception:
            pass

        opened: List[str] = []
        skipped: List[dict] = [
            {"ticker": t, "reason": "intraday_data_" + info["reason"]}
            for t, info in intraday_details.items()
            if t in universe and info["status"] != "ready"]
        now = datetime.utcnow()
        prices = {r["ticker"]: r["last_close"] for r in ranked}
        # AUDIT S-9: the book's equity (drawdown governor, sizing, equity
        # curve) is marked at the freshest price per held name — the live
        # quotes fetched at the top of this scan, else the stored close —
        # not at yesterday's scan close or the entry price.
        # held_px was already recorded at receipt above. Reusing the batch
        # here must not move that observation's clock forward during a scan.
        marks = self._freshest_marks({}, history, fallback=prices)
        marks_ready = self._risk_marks_ready(marks, now)

        # The owner's three-formula filter, if they have switched it on: say
        # on the page AND in the journal which names it removed, and why. A
        # gate that silently shrinks the buy list is the lying-screen class.
        for b in multi_blocked:
            skipped.append({"ticker": b["ticker"], "reason": b["reason"]})
            self._journal_once_a_day(
                "MULTI_FORMULA_BLOCKED", now,
                {"ticker": b["ticker"],
                 "why": (f"{b['ticker']} cleared AM07 ({b['score']} >= "
                         f"{cfg.min_score_to_enter:g}) but the owner's "
                         f"three-formula filter is ON and {b['reason']}.")})

        # Node 9: `canonical` was computed earlier this scan (moved before
        # pick assembly 2026-08-26 so Ocean's rail 2 reads today's panel);
        # the IFR journal below still writes it beside IFR's own numbers.

        # v6/v7: IFR check — DAMAGE_CLUSTER + TAIL_DAMAGE_RATIO (Q2-validated)
        ifr_snapshot = None
        try:
            from .ifr import check_damage_cluster
            ifr_snapshot = check_damage_cluster(
                history, now=now,
                last_fire_date=self.portfolio.last_ifr_fire_date,
                ratio_last_fire_date=self.portfolio.last_ifr_ratio_fire_date,
            )
            self.portfolio.last_ifr_fire_date = ifr_snapshot.last_fire_date
            self.portfolio.last_ifr_ratio_fire_date = ifr_snapshot.ratio_last_fire_date
            if ifr_snapshot.fired_today:
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(),
                    "action": "IFR_SIGNAL_FIRED",
                    "which": list(ifr_snapshot.which_fired),
                    "cluster_fires_in_window": ifr_snapshot.fires_in_window,
                    "tail_down3_5d": ifr_snapshot.tail_down3_5d_today,
                    "cluster_threshold": ifr_snapshot.threshold_value,
                    "ratio_today": ifr_snapshot.ratio_today,
                    "ratio_threshold": ifr_snapshot.ratio_threshold,
                    "sizing_multiplier": ifr_snapshot.sizing_multiplier,
                    # Node 9 step 2: the canonical number beside IFR's own.
                    # IFR counts stocks with any single -3% DAY in 5 days;
                    # the owner's formula takes the worst 3-DAY return in
                    # 5 days. 60 days of these pairs decide step 3.
                    "canonical_tail_down3_5d": (
                        None if canonical is None else canonical["value"]),
                    "canonical_static_cluster": (
                        None if canonical is None
                        else canonical["static_cluster"]),
                    "canonical_q90_cluster": (
                        None if canonical is None
                        else canonical["q90_cluster"]),
                    "why": ifr_snapshot.reason,
                })
        except Exception:
            pass

        # v5: Update drawdown governor with current equity
        prev_dd_level = self.drawdown_gov.active_level
        # The scan reads the governor's halt/sizing; it never cuts (the cut
        # belongs to refresh). See _update_drawdown for the persisted peak.
        self._update_drawdown(prices, now, cut_allowed=False, marks=marks)
        # v5: notify on drawdown level escalation
        if self.drawdown_gov.active_level != prev_dd_level:
            try:
                from .alerts import notify_drawdown
                snap = self.drawdown_gov.snapshot()
                notify_drawdown(
                    snap["level"], snap["drawdown_pct"],
                    snap["peak"], snap["current"],
                )
            except Exception:
                pass

        # v5: Build correlation-gate state (returns of each open position)
        # AUDIT E (2026-08-09): vol_adjusted_qty was imported here and never
        # called — dead code that read as a live control. Deleted with the
        # rest of the never-wired vol-tier scheme.
        from .risk_v2 import (
            correlation_gate_blocks, daily_returns, passes_liquidity,
        )
        open_returns = {}
        for held in self.portfolio.positions:
            if held in history:
                r = daily_returns(history[held]["Close"])
                if r is not None:
                    open_returns[held] = r

        # v5: per-ticker earnings blackout — 3 days before a known event
        try:
            from .calendars import is_ticker_event_within
        except ImportError:
            is_ticker_event_within = None

        # AUDIT FIX A10 (2026-08-09): entries used to fill at YESTERDAY'S
        # close +5bps even with a live broker attached — every paper fill
        # ignored the overnight gap, so the 60-day verdict was measured on
        # fills nobody could get. One batched quote call for today's picks;
        # a pick with no live quote falls back to the prior close and the
        # BUY journal says which one was used (fill_source).
        live_fill_px: dict = {}
        if picks:
            try:
                live_fill_px = routed_fetch_quotes(
                    [pk["ticker"] for pk in picks], upstox_client=self.broker,
                )
                if live_fill_px is None:
                    live_fill_px = qe.QuoteBatch()
            except Exception as e:
                live_fill_px = qe.QuoteBatch()
                log.warning("fill quotes unavailable: %s", e)

        # OWNER ORDER 2026-09-10: "trade are prohibited from now after market
        # hours ... yes all block, but i can run the advisery to review buy,
        # watch and block list". Everything above this line is READ-ONLY —
        # scoring, gates, picks, the scan matrix, the journal — and still runs
        # at any hour so the owner can review. Nothing below it may trade.
        #
        # This closes the real hole: catchup_scan_if_missed gated on
        # is_trading_day(), the DAY and never the CLOCK, and fires ~2 minutes
        # after every boot — so a Render restart at 21:00 opened positions at
        # prices nobody could have traded at.
        if not self._trading_allowed(now):
            state = self._market_state(now)
            self.portfolio.last_scan = now.isoformat()
            self._journal_once_a_day("MARKET_CLOSED_NO_ENTRY", now, {
                "market_state": state,
                "picks_held_back": [pk["ticker"] for pk in picks],
                "why": (f"Market is {state.replace('_', ' ')} — {len(picks)} "
                        f"pick(s) scored and shown for review, none bought. "
                        f"Owner order 2026-09-10: no trades outside "
                        f"09:15-15:30 IST on a trading day."),
            })
            for pk in picks:
                de.put(pk["decision"], "market_session", state, "open", passed=False)
                skipped.append({"ticker": pk["ticker"], "reason": f"market_{state}"})
            picks = []

        # AUDIT S-4 (owner: "go for next", 2026-10-02): the entry gates run in
        # TWO passes. Pass 1 (below) applies every gate that can refuse a pick
        # — macro halt, earnings blackout, chop, drawdown and loss halts,
        # already held, stale data, liquidity and correlation. Rotation
        # then funds ONLY the picks that cleared all of them, and pass 2 sizes
        # and opens. Before this, rotation ran first and could sell a
        # near-target position for a pick a later gate refused (on an RBI or
        # Budget week every pick is refused).
        # AUDIT F-9 (owner: "F9- write it", 2026-10-02): the measured-Kelly
        # check runs. One reading per scan, from the book's OWN closed trades
        # (trading/measured_kelly.py). NO_POSITIVE_EDGE blocks every new scan
        # entry; ACTIVE caps each new entry's size; NO_SAMPLE does nothing.
        mk = self._measured_kelly(now) if picks else None
        cleared: list = []
        for pick in picks:
            with de.capture(pick["decision"]):
                d = pick["decision"]
                de.put(d, "market_session", self._market_state(now), "open", passed=True)
                entry_clock = datetime.utcnow()
                de.put(d, "intraday_deadline", de.stamp(entry_clock), "15:25 IST", passed=ir.entry_allowed(cfg.mode, entry_clock),
                       state="skipped" if cfg.mode != "intraday" else None)
                if not ir.entry_allowed(cfg.mode, entry_clock):
                    skipped.append({"ticker": pick["ticker"], "reason": "intraday_entry_deadline"})
                    continue
                de.put(d, "portfolio_marks", {k: v for k, v in self.portfolio.mark_snapshot.items() if k != "positions"}, "complete observed valuation", passed=marks_ready)
                if not marks_ready:
                    skipped.append({"ticker": pick["ticker"],
                                    "reason": "portfolio_marks_incomplete"})
                    continue
                # 2026-10-05 ("make it momentum only"): the reading is this
                # category's own record, so an Ocean pick (its own category, its
                # own exits) is not judged by it.
                de.put(d, "measured_kelly", de.clean(vars(mk)) if mk is not None else None, "positive measured edge when sufficient sample",
                       state="skipped" if pick.get("ocean") else "unavailable" if mk is None else None,
                       passed=not (mk is not None and mk.block_new_entries), reason="Ocean exempt" if pick.get("ocean") else "")
                if (mk is not None and mk.block_new_entries
                        and not pick.get("ocean")):
                    skipped.append({"ticker": pick["ticker"],
                                    "reason": "measured_kelly_no_edge"})
                    continue
                de.put(d, "system_event", {"event_type": binary_event.event_type, "event_date": str(binary_event.event_date)} if binary_event else None,
                       {"lookahead_days": 3}, passed=binary_event is None,
                       state=None if binary_event_available else "unavailable", reason="Known calendar only; no matching event" if binary_event is None else "Upcoming binary event")
                if binary_event is not None:
                    skipped.append({
                        "ticker": pick["ticker"],
                        "reason": f"halt_pre_{binary_event.event_type}_{binary_event.event_date}",
                    })
                    continue
                # v5: ticker-specific event blackout (earnings)
                if is_ticker_event_within is not None:
                    tic_event = is_ticker_event_within(pick["ticker"], days=3)
                    de.put(d, "ticker_event", {"event_type": tic_event.event_type, "event_date": str(tic_event.event_date)} if tic_event else None,
                           {"lookahead_days": 3}, passed=tic_event is None, reason="Known calendar only")
                    if tic_event is not None:
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"blackout_{tic_event.event_type}_{tic_event.event_date}",
                        })
                        continue
                if is_ticker_event_within is None:
                    de.put(d, "ticker_event", state="unavailable", reason="Calendar reader unavailable")
                de.put(d, "benchmark_trend", nifty_adx, cfg.nifty_min_adx, passed=not nifty_chop,
                       state="skipped" if cfg.nifty_min_adx <= 0 else "unavailable" if nifty_adx is None else None,
                       reason="Benchmark ADX; existing policy allows absent input")
                if nifty_chop:
                    skipped.append({
                        "ticker": pick["ticker"],
                        "reason": "nifty_chop_low_adx",
                    })
                    continue
                # v5: graduated drawdown halt
                de.put(d, "drawdown_halt", self.drawdown_gov.snapshot(), "halt_new_entries=False", passed=not self.drawdown_gov.halt_new_entries)
                if self.drawdown_gov.halt_new_entries:
                    skipped.append({
                        "ticker": pick["ticker"],
                        "reason": f"drawdown_{self.drawdown_gov.active_level}",
                    })
                    continue
                # v5: consecutive-loss halt. OWNER ORDER 2026-10-21 ("Halt only
                # the category that lost"): judged for THIS pick's category —
                # ocean for an Ocean pick, else the pass's mode — against that
                # category's own losers and open count. cfg.loss_halt_scope
                # "book" = the old book-wide rule.
                halt_cat = self._loss_halt_category(pick, cfg)
                halted = self.loss_tracker.halted(
                        today=now.date(),
                        open_positions=len(self.portfolio.positions),
                        category=halt_cat,
                        open_in_category=self._open_in_category(halt_cat),
                        scope=self._loss_halt_scope(cfg))
                de.put(d, "loss_halt", {"category": halt_cat, "losses": self.loss_tracker.by_category.get(halt_cat, 0),
                    "book_losses": self.loss_tracker.losses_today, "count_day": str(self.loss_tracker.today), "evaluated_day": str(now.date()), "counts_current": self.loss_tracker.today == now.date(), "open_in_category": self._open_in_category(halt_cat)},
                    {"scope": self._loss_halt_scope(cfg), "category_limit": self.loss_tracker.limit(self._open_in_category(halt_cat) + self.loss_tracker.losses_in(halt_cat)), "book_limit": self.loss_tracker.limit()}, passed=not halted)
                if halted:
                    skipped.append({
                        "ticker": pick["ticker"],
                        "reason": "consecutive_loss_halt",
                        "category": halt_cat,
                    })
                    continue
                de.put(d, "already_held", pick["ticker"] in self.portfolio.positions, False, passed=pick["ticker"] not in self.portfolio.positions)
                if pick["ticker"] in self.portfolio.positions:
                    skipped.append({"ticker": pick["ticker"], "reason": "already_held"})
                    continue
                # v5: liquidity hard floor
                if cfg.mode == "intraday":
                    ih = signal_history.get(pick["ticker"])
                    ih, info = ib.validate(ih, datetime.utcnow(), min_bars=ib.required_bars(cfg))
                    de.put(d, "intraday_data", info, "completed current-session 5m bars",
                           state="passed" if info["status"] == "ready" else "unavailable", reason=info["reason"])
                    if info["status"] != "ready":
                        skipped.append({"ticker": pick["ticker"], "reason": "intraday_data_" + info["reason"]})
                        continue
                    if pick.get("ocean"):
                        d["daily_selection_context"] = d.get("bar")
                    pick["history"] = ih
                    pick["risk_history"] = history.get(pick["ticker"])
                    d["bar"] = info
                tic_hist = history.get(pick["ticker"])
                if tic_hist is not None:
                    # P2: never buy on stale candles (dead feed / unnoticed holiday).
                    age_known = True
                    try:
                        stale = (now.date() - tic_hist.index[-1].date()).days
                    except Exception:
                        stale = 0
                        age_known = False
                    de.put(d, "data_age", stale if age_known else None, getattr(cfg, "max_stale_days", 7), passed=stale <= getattr(cfg, "max_stale_days", 7),
                           state=None if age_known else "unavailable", reason="Calendar days since last daily bar; unknown index retains existing fail-open policy")
                    if stale > getattr(cfg, "max_stale_days", 7):
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"stale_data_{stale}d",
                        })
                        continue
                    last_open = float(tic_hist["Open"].iloc[-1]) if "Open" in tic_hist else None
                    last_high = float(tic_hist["High"].iloc[-1]) if "High" in tic_hist else None
                    last_low = float(tic_hist["Low"].iloc[-1]) if "Low" in tic_hist else None
                    last_close = float(tic_hist["Close"].iloc[-1])
                    # v5: skip live mcap fetch — yfinance .info is slow + often
                    # fails from cloud IPs. The rupee-turnover floor already
                    # block illiquid names; live mcap was a redundant second gate.
                    mcap_cr = None
                    spread_pct = None
                    if self.broker is not None:
                        try:
                            bid, ask = self.broker.bid_ask(pick["ticker"])
                            if bid and ask and bid > 0:
                                spread_pct = (ask - bid) / ((ask + bid) / 2)
                        except Exception:
                            pass
                    ok_liq, reason_liq = passes_liquidity(
                        tic_hist["Close"], tic_hist["Volume"],
                        last_high=last_high, last_low=last_low,
                        last_open=last_open, last_close=last_close,
                        market_cap_cr=mcap_cr, spread_pct=spread_pct,
                    )
                    if not ok_liq:
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"liquidity_{reason_liq}",
                        })
                        continue
                    # v5: correlation gate — was 0.70, tightened to 0.85 because
                    # N200 stocks routinely correlate 0.55-0.75 with each other
                    # (banks + financials cluster) and the strict 0.70 was blocking
                    # every diversification candidate. 0.85 still catches the
                    # genuinely-same-bet pairs.
                    cand_ret = daily_returns(tic_hist["Close"])
                    blocker = correlation_gate_blocks(
                        cand_ret, open_returns, threshold=0.85,
                    )
                    if blocker is not None:
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"correlated_{blocker[0]}_{blocker[1]:.2f}",
                        })
                        continue
                    # SEQ-07: observe support, absence or missing data without a
                    # veto. Score/rank, sizing, quote/risk gates and exits retain
                    # their own rules, including Ocean's separate reclaim rail.
                    advice = candle_assessment(signal_history.get(pick["ticker"], tic_hist), cfg)
                    de.put(d, "candle", advice, "Advisory only; no entry or exit veto",
                           state=advice['state'], role="advisory",
                           reason=advice['contribution'])
                else:
                    de.put(d, "liquidity_history", state="unavailable", reason="History missing on entry path")
                quote_ev = qe.observation(live_fill_px, pick["ticker"], datetime.utcnow())
                pick["quote_evidence"] = quote_ev
                d["quote"] = copy.deepcopy(quote_ev)
                quote_ok = qe.executable(live_fill_px, pick["ticker"], datetime.utcnow())
                de.put(d, "quote", quote_ev, "Positive routed LTP or intraday close; daily/retained marks excluded",
                       state="unavailable" if quote_ev.get("source") in ("unknown", "unavailable") else None, passed=quote_ok)
                if isinstance(live_fill_px, qe.QuoteBatch) and not quote_ok:
                    skipped.append({"ticker": pick["ticker"], "reason": "quote_unavailable_or_non_executable"})
                    continue
                cleared.append(pick)
        # OWNER ORDER 2026-09-04: rotation executes. Runs BEFORE the opening
        # pass so the cash it frees is there when can_open counts it, and
        # AFTER the gates (S-4) so it only ever funds a pick that will buy.
        if not ir.entry_allowed(cfg.mode, datetime.utcnow()):
            skipped.extend({"ticker": pk["ticker"], "reason": "intraday_entry_deadline"}
                           for pk in cleared)
            cleared = []
        try:
            rotated_out = self._rotation_exits(
                cleared, now, entries_blocked=entries_blocked, history=history)
        except Exception as e:
            log.exception("rotation exits failed — picks proceed on cash as-is: %s", e)
            rotated_out = []
        if rotated_out:
            cleared = [pk for pk in cleared if pk["ticker"] not in rotated_out]

        for pick in cleared:
            with de.capture(pick["decision"]):
                if not ir.entry_allowed(cfg.mode, datetime.utcnow()):
                    skipped.append({"ticker": pick["ticker"], "reason": "intraday_entry_deadline"})
                    continue
                live_px = live_fill_px.get(pick["ticker"])
                quote_ev = qe.observation(live_fill_px, pick["ticker"], datetime.utcnow())
                pick["quote_evidence"] = quote_ev
                executable = qe.executable(live_fill_px, pick["ticker"], datetime.utcnow())
                de.put(pick["decision"], "quote", quote_ev,
                       "Positive routed LTP or completed current-session minute close within interval + 60s of its end",
                       passed=executable, state="unavailable" if quote_ev.get("source") in ("unknown", "unavailable") else None,
                       reason="Price source/time retained; unknown injected adapters remain explicit")
                if isinstance(live_fill_px, qe.QuoteBatch) and not executable:
                    skipped.append({"ticker": pick["ticker"], "reason": "quote_unavailable_or_non_executable"})
                    continue
                if live_px and live_px > 0:
                    # 2026-08-26: the router can now serve a ~1-minute-delayed
                    # public candle when no login token exists — label it as
                    # such, never as a live tick (the 2026-07-31 lesson).
                    src = quote_ev.get("source", "unknown")
                    raw_fill = float(live_px)
                    pick["fill_source"] = ("live_quote" if src == "upstox"
                                           else src)
                else:
                    raw_fill, pick["fill_source"] = pick["last_close"], "prev_close"
                    pick["quote_evidence"] = qe.make(raw_fill, "prev_close", now, interval="1d",
                        provider_date=pick["decision"]["bar"].get("last_bar"), reason="Legacy injected adapter fallback")
                fill = slippage_price(raw_fill, "BUY", cfg)
                current_eq = self.portfolio.equity(marks)
                # Owner order 2026-07-30: size by ½-Kelly off this stock's own
                # estimated edge and volatility instead of a flat rupee amount.
                # Falls back to the fixed size when history is missing, and every
                # risk gate inside can_open still applies to the result.
                from .sizing import position_notional_for
                cand_close = history.get(pick["ticker"], {}).get("Close") \
                    if isinstance(history.get(pick["ticker"]), dict) else None
                if cand_close is None:
                    try:
                        cand_close = history[pick["ticker"]]["Close"].dropna()
                    except Exception:
                        cand_close = None
                kelly_notional_rs, size_diag = position_notional_for(
                    cfg, current_eq, score=pick.get("score"), close=cand_close)
                if pick.get("ocean"):
                    # Owner-approved 2026-08-26: Ocean entries are HALF size
                    # (Rs 1,68,750, owner order 2026-08-30) — the rails are the
                    # edge claim, the size is
                    # the humility. Every can_open gate still applies.
                    ocean_rs = float(getattr(cfg, "ocean_position_value",
                                             168_750.0) or 168_750.0)
                    size_diag = {"mode": "ocean_fixed", "notional": ocean_rs}
                    notional_arg = ocean_rs
                else:
                    notional_arg = (kelly_notional_rs
                                    if size_diag.get("mode") != "fixed" else None)
                    cap_rs = self._measured_kelly_cap(mk, cfg, current_eq)
                    if cap_rs is not None:
                        want = (notional_arg if notional_arg is not None
                                else float(cfg.position_notional()))
                        size_diag = dict(size_diag)
                        size_diag["measured_kelly"] = {
                            "status": mk.status, "usable": mk.usable,
                            "fraction": mk.fraction, "cap": round(cap_rs, 0),
                            "wanted": round(float(want), 0),
                            "capped": bool(want > cap_rs)}
                        if want > cap_rs:
                            notional_arg = cap_rs
                # OWNER ORDER 2026-10-04: each category spends only its own share
                # (momentum 40%, the other four 15% each). Ocean is exempt.
                initial_stop = self._stop_for(pick, fill, cfg=cfg)
                ok, reason, qty = can_open(
                    self.risk, self.portfolio.cash, current_eq,
                    self.portfolio.positions, pick["ticker"], fill, cfg,
                    notional_override=notional_arg,
                    when=now, proposed_stop_price=initial_stop,
                    category=(None if pick.get("ocean")
                              else (getattr(cfg, "mode", "") or MOMENTUM_MODE)),
                )
                pick["size_diag"] = size_diag
                # v7: size throttle = MIN of (strength, IFR) instead of product.
                # Previously we multiplied them, which compounded to 0.25-0.35x
                # and zeroed qty on expensive stocks. The throttles are designed
                # as alternative defensive measures, not stacking damages — take
                # whichever is more restrictive at any one time.
                if ok:
                    s = pick.get("score", 0)
                    # Under Kelly the score ALREADY sets the size (mu is derived
                    # from it), so applying the strength ladder too would count the
                    # score twice and shrink good picks for no reason. The IFR
                    # throttle stays either way — it is a damage-cluster defence,
                    # not a score judgement.
                    # AUDIT FIX A1 (2026-08-09): the strength ladder
                    # (0.5/0.7/1.0x by score) is GONE. Under Kelly it double-
                    # counted the score; under fixed it silently cut the owner's
                    # written Rs 1.25L to Rs 87.5k for every 62-74.9 pick — the
                    # size is the owner's number, not a suggestion. The IFR
                    # throttle stays: it is a damage-cluster defence, not a
                    # score judgement.
                    ifr_mult = ifr_snapshot.sizing_multiplier if ifr_snapshot else 1.0
                    # AUDIT E (2026-08-09): the drawdown governor's documented
                    # "watchful → size 75%" tier was set in update() and consumed
                    # by NOTHING — the risk page described a control that never
                    # ran. It throttles for real now (most restrictive wins).
                    dd_mult = float(getattr(self.drawdown_gov,
                                            "sizing_multiplier", 1.0) or 1.0)
                    throttle = min(ifr_mult, dd_mult)
                    pick["ifr_applied_multiplier"] = ifr_mult
                    pick["decision"]["overlays"] = {"ifr": de.clean(vars(ifr_snapshot)) if ifr_snapshot is not None else {"status": "unavailable", "applied_default": 1.0},
                                                       "drawdown": de.clean(self.drawdown_gov.snapshot())}
                    de.record("size_throttle", {"ifr_multiplier": ifr_mult, "drawdown_multiplier": dd_mult, "before_qty": qty},
                              {"rule": "minimum", "multiplier": throttle}, passed=throttle > 0, role="sizing")
                    qty = self._throttled_qty(
                        qty, throttle, fill,
                        float(getattr(cfg, "position_slab_value", 0) or 0))
                    from .risk import min_trade_value
                    min_val = min_trade_value(
                        cfg, notional_arg if notional_arg is not None
                        else float(cfg.position_notional()))
                    de.record("quantity_after_throttle", qty, 1, passed=qty >= 1, role="sizing")
                    de.record("minimum_value_after_throttle", qty * fill, min_val, passed=qty * fill >= min_val, role="sizing")
                    if qty > 0 and min_val > 0 and qty * fill < min_val:
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"below_min_value_{int(min_val)}",
                        })
                        continue
                    if qty <= 0:
                        skipped.append({
                            "ticker": pick["ticker"],
                            "reason": f"throttle_zero_qty (ifr={ifr_mult})",
                        })
                        continue
                if not ok:
                    skipped.append({"ticker": pick["ticker"], "reason": reason})
                    continue
                entry_now = datetime.utcnow()
                de.record("entry_deadline_final", de.stamp(entry_now), "15:25 IST", passed=ir.entry_allowed(cfg.mode, entry_now),
                          state="skipped" if cfg.mode != "intraday" else None)
                if not ir.entry_allowed(cfg.mode, entry_now):
                    skipped.append({"ticker": pick["ticker"], "reason": "intraday_entry_deadline"})
                    continue
                if cfg.mode == "intraday":
                    _, final_data = ib.validate(pick.get("history"), entry_now, min_bars=ib.required_bars(cfg))
                    de.record("intraday_data_final", final_data, "still current at entry",
                              state="passed" if final_data["status"] == "ready" else "unavailable", reason=final_data["reason"])
                    if final_data["status"] != "ready":
                        skipped.append({"ticker": pick["ticker"], "reason": "intraday_data_" + final_data["reason"]})
                        continue
                try:
                    self._open(pick, qty, fill, entry_now, initial_stop=initial_stop)
                except ValueError as exc:
                    if str(exc).startswith(("intraday_", "costs_")):
                        skipped.append({"ticker": pick["ticker"], "reason": str(exc)})
                        continue
                    raise
                opened.append(pick["ticker"])
        self._journal_budget_full(skipped, now)
        self._journal_loss_halt(skipped, now)

        self.portfolio.last_scan = now.isoformat()
        if self._trading_allowed(now):
            self.portfolio.last_scan_live = now.isoformat()

        def _candle_label(tkr: str) -> str:
            # Record supporting pattern or explicit unavailable/disabled state so
            # the dashboard can SHOW it with no refetch — history is in RAM.
            h = signal_history.get(tkr)
            if h is None:
                return ""
            try:
                return candle_assessment(h, cfg)['reason']
            except Exception:
                return ""

        def _all_structures(tkr: str) -> dict:
            # Owner ask 2026-07-26: every candle structure is its OWN
            # parameter, not one lumped "candle confirm" lane. 18 structures
            # (10 bullish / 6 bearish / 2 neutral) recorded per stock.
            h = signal_history.get(tkr)
            if h is None:
                return {}
            try:
                from .candles import scan_all_patterns
                return scan_all_patterns(
                    h, int(getattr(cfg, "candle_breakout_lookback", 20)),
                    float(getattr(cfg, "candle_volume_mult", 1.5)))
            except Exception:
                return {}

        self.portfolio.last_scan_picks = [
            {
                "ticker": r["ticker"], "score": r["score"],
                "decision_id": (self.portfolio.positions[r["ticker"]].trade_evidence.get("entry", {}).get("id") if r["ticker"] in opened else r["decision"]["id"]),
                "reasoning": r["reasoning"], "last_close": r["last_close"],
                "timing_pass": r["timing_pass"],
                "bar": de.bar_context(signal_history.get(r["ticker"])),
                "components": r.get("components") or {},
                "market_context": r["decision"].get("market_context"),
                "candles": signal_history[r["ticker"]][["Open", "High", "Low", "Close"]].tail(20).values.tolist(),
                "candle": _candle_label(r["ticker"]),
                "structures": _all_structures(r["ticker"]),
                "multi": r.get("multi"),
                "opened": r["ticker"] in opened,
            }
            for r in ranked[:50]
        ]
        self.portfolio.last_scan_skipped = list(skipped)
        self.portfolio.last_scan_opened = list(opened)

        # Retain every actual selection path, including absent/unscored names.
        skip_reasons = {r["ticker"]: r["reason"] for r in skipped}
        for d in decisions.values():
            ticker = d["ticker"]
            failures = [k for k, v in d["gates"].items() if v["state"] == "failed"]
            unavailable = [k for k, v in d["gates"].items() if v["state"] == "unavailable"]
            reason = skip_reasons.get(ticker) or (failures[0] if failures else unavailable[0] if unavailable else "not selected")
            bought_here = ticker in opened and (self.portfolio.positions[ticker].trade_evidence.get("entry") or {}).get("id") == d["id"]
            outcome = "bought" if bought_here else "blocked" if ticker in skip_reasons or failures else "unavailable" if unavailable else "not_selected"
            observed = self.portfolio.positions[ticker].trade_evidence["entry"] if bought_here else d
            de.journal_decision(self.portfolio, observed, outcome, "Entry executed" if bought_here else reason)

        # 🎹 Parameter Piano — the FULL scan hit-map, every ticker × every real
        # computed check (factor scores, timing, absolute momentum, candle,
        # gate outcome). Rendered as the grid on /scan. Overwritten per scan,
        # fixed size (~universe × factors) — no RAM growth.
        skip_by_t = {s.get("ticker"): str(s.get("reason", ""))[:40]
                     for s in skipped if s.get("ticker")}
        self.portfolio.scan_matrix = {
            "ts": now.isoformat(),
            "candle_policy": "advisory",
            "mode": getattr(cfg, "mode", "?"),
            "score_floor": float(cfg.min_score_to_enter),
            "universe_size": len(universe),
            "rows": {
                r["ticker"]: {
                    "decision_id": (self.portfolio.positions[r["ticker"]].trade_evidence.get("entry", {}).get("id") if r["ticker"] in opened else r["decision"]["id"]),
                    "c": {k: round(float(v), 1)
                          for k, v in (r.get("components") or {}).items()},
                    "score": round(float(r["score"]), 1),
                    "timing": bool(r["timing_pass"]),
                    "abs_mom": bool(_abs_mom_ok(r["ticker"])),
                    "candle": _candle_label(r["ticker"]),
                    "structures": _all_structures(r["ticker"]),
                    "multi": r.get("multi"),
                    "outcome": ("opened" if r["ticker"] in opened
                                else skip_by_t.get(r["ticker"], "")),
                }
                for r in ranked
            },
        }
        # AUDIT S-11 / S-13 (owner: "go for next", 2026-10-02): the scan
        # matrix above is overwritten by every pass, and positional runs LAST
        # — so the Buy Desk and the trigger/news scope read the positional
        # pass, not momentum. The momentum pass keeps its own small record.
        if getattr(cfg, "mode", "") == MOMENTUM_MODE:
            try:
                self._store_momentum_shortlist(ranked, history, skip_by_t, now,
                                               _abs_mom_ok)
            except Exception:
                log.exception("momentum shortlist store failed")

        # Structural flags (owner-approved 2026-07-26): context markers from
        # the same history panel — display/journal only, never a gate.
        try:
            from .flags import compute_flags
            self.portfolio.scan_matrix["flags"] = compute_flags(
                {t: history[t] for t in universe if t in history},
                list(self.portfolio.positions.keys()), cfg.sector_map)
        except Exception:
            pass

        # F8: shadow-book the YES-scored picks we did NOT buy (opportunity
        # cost of the gates), then mark the whole book to market.
        try:
            from .virtual import record_virtual, mark_virtual
            _OPP = ("candle_wait", "reserve", "cash", "max_positions",
                    "sector_exposure_cap", "below_min_value", "throttle",
                    "correlated")
            rank_by_t = {r["ticker"]: r for r in ranked}
            tgt = float(getattr(cfg, "take_profit_pct", 0.30))
            stp = float(getattr(cfg, "stop_loss_pct", -0.12))
            for s in skipped:
                reason = str(s.get("reason", ""))
                tkr = s.get("ticker")
                if tkr and any(k in reason for k in _OPP) and tkr in rank_by_t:
                    record_virtual(
                        self.portfolio.virtual_book, tkr,
                        float(rank_by_t[tkr]["last_close"]),
                        float(rank_by_t[tkr]["score"]),
                        cfg.sector_map.get(tkr, "Unknown"), reason,
                        tgt, stp, now.isoformat())
            # cap the shadow book so it can't grow unbounded (512 MB)
            if len(self.portfolio.virtual_book) > 300:
                keep = sorted(self.portfolio.virtual_book.items(),
                              key=lambda kv: kv[1].get("first_seen", ""))[-300:]
                self.portfolio.virtual_book = dict(keep)
            mark_virtual(self.portfolio.virtual_book, prices, now.isoformat())
        except Exception as e:
            log.debug("Shadow-book update skipped: %s", e)

        # v5: archive a compact scan summary for the history page
        self.portfolio.scan_history.append({
            "ts": now.isoformat(),
            "regime": regime.regime if regime is not None else None,
            "ranked_count": len(ranked),
            "picks_count": len(picks),
            "opened_count": len(opened),
            "skipped_count": len(skipped),
            "top_score": float(ranked[0]["score"]) if ranked else 0.0,
        })
        self.square_off_intraday()  # a long scan may have crossed 15:25
        self._record_equity(marks, datetime.utcnow())
        self.portfolio.save()

        return ScanResult(ts=now, ranked=ranked, picks=picks, opened=opened, skipped=skipped)

    def square_off_intraday(self, prices: dict | None = None) -> list[str]:
        """Retry due intraday deadlines, only on valid in-session quotes.

        The position carries the deadline through restarts. This method is
        also used by scans/refreshes, so a missed cron job is not final.
        The shared lock serializes retries with the category rotation.
        """
        from .modes import holding_mode_lock
        with holding_mode_lock(timeout=0):
            return self._recover_intraday_locked(prices)

    def _recover_intraday_locked(self, prices=None):
        p = self.portfolio
        now = datetime.utcnow()
        changed = ir.ensure_book(p, now)
        targets = {t: pos for t, pos in p.positions.items() if ir.is_due(pos, now)}
        if not targets:
            if changed:
                p.save()
            return []
        if not self._trading_allowed(now) or not ir.in_session(now):
            for pos in targets.values():
                pos.intraday_close["status"] = "waiting_market"
            p.save()
            return []

        self._absorb_corporate_actions("intraday_close")
        for pos in targets.values():
            record = pos.intraday_close
            record.update(status="pending", last_attempt=ir.utc(now).isoformat(),
                          attempts=int(record.get("attempts", 0) or 0) + 1,
                          last_error=None)
        # Save unfinished work BEFORE the potentially failing quote request.
        p.save()
        quote_error = None
        if prices is None:
            try:
                prices = routed_fetch_quotes(list(targets), upstox_client=self.broker)
            except Exception as exc:
                prices, quote_error = {}, type(exc).__name__
                log.warning("Intraday deadline quote lookup failed: %s", quote_error)
        closed = []
        for ticker, pos in targets.items():
            if p.positions.get(ticker) is not pos:
                continue
            now = datetime.utcnow()  # a slow quote lookup can cross the close
            record = pos.intraday_close
            if not self._trading_allowed(now) or not ir.in_session(now):
                record["status"] = "waiting_market"
                continue
            price = pm.positive_price((prices or {}).get(ticker))
            decision = de.exit_decision(pos, prices, now)
            de.put(decision, "square_off", de.stamp(now), record.get("deadline"), passed=True, role="exit_trigger")
            record["last_quote"] = qe.observation(prices, ticker, now)
            if price is None or not qe.executable(prices, ticker, now):
                record.update(status="waiting_quote", last_error=quote_error or ("quote_non_executable_or_unavailable" if price is not None else None))
                self._journal_intraday_pending(pos, now)
                de.journal_exit(p, decision, "held", "square_off_waiting_quote")
                continue
            try:
                with de.capture(decision):
                    self._close(ticker, price, "SQUARE_OFF", now)
                closed.append(ticker)
                p.save()  # checkpoint each completed holding independently
            except Exception as exc:
                if p.positions.get(ticker) is pos:
                    record.update(status="retry_pending", last_error=type(exc).__name__)
                log.exception("Intraday close failed for %s; recovery remains pending", ticker)
        p.save()
        return closed

    def _journal_intraday_pending(self, pos, now):
        record = pos.intraday_close
        # One visible journal row per holding/deadline/day; attempts live in
        # the persisted record, so minute retries do not flood the journal.
        key = now.date().isoformat()
        if record.get("noted_day") == key:
            return
        record["noted_day"] = key
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(), "action": "SQUARE_OFF_HELD_NO_QUOTE",
            "ticker": pos.ticker, "deadline": record["deadline"],
            "why": ("Intraday closing deadline is due but no valid quote is available. "
                    "Original segment, stop and target remain; retry at the next "
                    "in-session recovery pass. No estimated fill is used."),
        })

    def refresh(self) -> dict:
        """Pull latest prices, mark portfolio, fire exits."""
        deadline_exits = self.square_off_intraday()
        cfg = self.cfg
        if not self.portfolio.positions:
            # Empty book still rolls the risk day — otherwise a kill-switch
            # liquidation (which empties the book) would freeze the tripped
            # switch here forever (recheck fix, 2026-07-27).
            prices = {}
            self._roll_risk_day(self.portfolio.equity(prices), datetime.utcnow())
            summary = self._summary_dict(prices)
            summary["exits_this_refresh"] = deadline_exits
            return summary

        # Owner order 2026-10-21 (BLSE): absorb today's split/bonus on held
        # names BEFORE any quote is compared with an entry — whichever path
        # (scheduler, owner button, rotation) called this pass.
        self._absorb_corporate_actions("refresh")
        tickers = list(self.portfolio.positions.keys())
        prices = routed_fetch_quotes(tickers, upstox_client=self.broker)
        prices = qe.select(prices, lambda t, value: t in self.portfolio.positions and pm.positive_price(value) is not None)
        if not prices:
            # FIX (2026-07-12): stale-data guard. No live quotes = we must NOT
            # fire exits on entry-price marks (a missed Upstox login would
            # falsely trip/skip stops). Journal it loudly and hold, once/day.
            today_iso = datetime.utcnow().date().isoformat()
            already = any(
                e.get("action") == "DATA_STALE" and str(e.get("ts", "")).startswith(today_iso)
                for e in self.portfolio.decision_journal[-50:]
            )
            for pos in self.portfolio.positions.values():
                de.journal_exit(self.portfolio, de.exit_decision(pos, prices, datetime.utcnow(),
                    session=self._trading_allowed(datetime.utcnow())), "held", "quote_unavailable")
            marks = self._freshest_marks({}, {})
            if not already:
                self.portfolio.decision_journal.append({
                    "ts": datetime.utcnow().isoformat(), "action": "DATA_STALE",
                    "why": "No live quotes (Upstox down + Yahoo blocked). Exits "
                           "held to avoid false triggers on stale marks. Reconnect Upstox.",
                })
            self.portfolio.save()
            log.warning("refresh: no live quotes — exits held (stale-data guard)")
            summary = self._summary_dict(marks)
            summary["exits_this_refresh"] = deadline_exits
            return summary

        now = datetime.utcnow()
        # 2y, not 1y: the momentum ruler needs 252 bars and one calendar
        # year is only ~248-252 trading days — on the short side every
        # momentum position would have scored nothing (owner order
        # 2026-10-02, exits judged on the entry ruler).
        history = fetch_daily(tickers, period="2y")
        bench = fetch_daily([cfg.benchmark], period="6mo").get(cfg.benchmark)
        intraday_names = [t for t, p in self.portfolio.positions.items() if p.mode == "intraday"]
        intraday_history, refresh_data = ({}, {})
        if intraday_names:
            intraday_history, refresh_data = idata.fetch(
                [cfg.benchmark] + intraday_names, cfg, self.broker, datetime.utcnow())
        refresh_context = ci.prepare(tickers, cfg, datetime.utcnow(), interval='1d')
        intraday_context = (ci.prepare(intraday_names, cfg, datetime.utcnow(), client=self.broker, interval='5m')
                            if intraday_names else None)
        # Recover deadlines crossed during history retrieval with a new quote
        # lookup; never turn an old pre-fetch clock into an after-hours fill.
        deadline_exits.extend(self.square_off_intraday())
        now = datetime.utcnow()

        # OWNER ORDER 2026-09-10: no trades outside 09:15-15:30 IST, and the
        # 30-minute in-session pass now carries stops AND targets (owner: "A -
        # OK", both on the same clock). So a closed-market refresh MARKS the
        # book — cash, equity, P&L, journal all update, screens stay honest —
        # and fires nothing. Exits are not lost, they moved INSIDE the session
        # where they can actually be filled.
        #
        # This is a real change to when a stop can fire. It used to fire at
        # 15:35, five minutes after the close, on a price nobody could trade.
        marking_only = not self._trading_allowed(now)
        if marking_only:
            self._journal_once_a_day("MARKET_CLOSED_MARK_ONLY", now, {
                "market_state": self._market_state(now),
                "positions": len(tickers),
                "why": (f"Market {self._market_state(now).replace('_', ' ')} — book "
                        f"marked, no exits fired. Stops and targets run on the "
                        f"in-session pass every "
                        f"{int(getattr(cfg, 'intraday_refresh_minutes', 30))} "
                        f"minutes."),
            })

        # OWNER ORDER 2026-08-11 danger layer (C then auto B): the strict-
        # calibration-VERIFIED danger tripwires guard HELD names. Sell side
        # only; runs before the exit loop so a tightened stop is live today.
        try:
            if not marking_only:
                self._danger_pass(qe.select(prices, lambda t, px: qe.executable(prices, t, datetime.utcnow())), history, now)
        except Exception:
            log.exception("danger layer pass failed")
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "DANGER_LAYER_FAILED",
                "why": "danger pass raised; positions untouched this run",
            })

        # Daily kill switch check. Roll the baseline FIRST — without this the
        # baseline stays pinned at starting_capital forever and the "-2% daily"
        # halt becomes "-2% since inception", force-closing the whole book on
        # an ordinary drawdown.
        # AUDIT S-9: a held name with no live quote is marked at its latest
        # stored close (or entry, if it was bought after that close) for the
        # BOOK's equity — kill switch, drawdown governor, equity curve. Exits
        # and cuts still act only on real quotes (`prices`), never on marks.
        marks = self._freshest_marks(prices, history)
        current_eq = self.portfolio.equity(marks)
        marks_ready = self._risk_marks_ready(marks, now)
        if (marks_ready or self.portfolio.equity_history
                or self.portfolio.risk_day == now.date().isoformat()):
            self._roll_risk_day(current_eq, now)
        if marks_ready and self.risk.check_kill_switch(current_eq):
            # Persist the trip so a mid-day restart can't forget the halt.
            self.portfolio.risk_day_killed = True

        # Track which tickers already have a HOLD entry today (avoid spam on
        # multiple refreshes per day) — one why-retained line per ticker per day.
        today_iso = now.date().isoformat()
        held_today = {
            e["ticker"] for e in self.portfolio.decision_journal[-200:]
            if e.get("action") == "HOLD" and e.get("ts", "").startswith(today_iso)
        }

        # ITEM 19 (owner order 2026-10-21): re-target held k x ATR positions
        # whose valuation record now qualifies (once), and re-mark every
        # valuation target when a month has closed — BEFORE the exit loop, so
        # a target set or moved here is judged on this same pass. The
        # re-target runs in-session only: the study set it and judged the
        # exit on one close, so a target set at night never sells on the
        # next morning's gap.
        try:
            self._valuation_pass(prices, history, now, retarget=not marking_only)
        except Exception:
            log.exception("valuation exit pass failed")
            self._journal_once_a_day("VALUATION_PASS_FAILED", now, {
                "why": "valuation re-target / re-mark raised; targets untouched this pass"})

        exits: list[str] = list(deadline_exits)
        no_quote_held: list[str] = []
        for ticker in list(self.portfolio.positions.keys()):
            pos = self.portfolio.positions.get(ticker)
            if pos is None:
                continue  # an earlier deadline recovery may close several names
            price = prices.get(ticker)
            if not price or price <= 0 or not qe.executable(prices, ticker, datetime.utcnow()):
                # AUDIT FIX A2 (2026-08-09): the stale-data guard above only
                # fires when ALL quotes fail. A single missing quote used to
                # fall back to the ENTRY price — so a winner whose peak sat
                # >= ~17.7% above entry "showed" a -15% trail breach and was
                # closed at entry, erasing the recorded gain. No quote = no
                # exit decision for that name, journaled once per day.
                no_quote_held.append(ticker)
                de.journal_exit(self.portfolio, de.exit_decision(pos, prices, now, session=not marking_only), "held", "quote_unavailable_or_non_executable")
                today_key = now.date().isoformat()
                seen = any(e.get("action") == "EXIT_HELD_NO_QUOTE"
                           and e.get("ticker") == ticker
                           and str(e.get("ts", "")).startswith(today_key)
                           for e in self.portfolio.decision_journal[-100:])
                if not seen:
                    self.portfolio.decision_journal.append({
                        "ts": now.isoformat(), "action": "EXIT_HELD_NO_QUOTE",
                        "ticker": ticker,
                        "why": ("No live quote for this name — exit rules "
                                "held rather than evaluated on the entry-"
                                "price mark. Reconnect Upstox / check the "
                                "instrument mapping."),
                    })
                continue
            # Recompute the score for the score-decay / trail-tighten check on
            # the SAME ruler the position was bought on (owner order
            # 2026-10-02). A momentum position used to be re-scored on the
            # AM07 composite here, while it was bought on the momentum +
            # quality blend — a different number, sold on a different floor.
            current_score = pos.entry_score
            score_available = False
            score_frame, score_bench = history.get(ticker), bench
            intraday_score_diag = None
            if getattr(pos, "mode", "") == "intraday":
                score_frame = intraday_history.get(ticker)
                score_bench = intraday_history.get(cfg.benchmark)
                rescored, _, intraday_score_diag = isc.compute(
                    ticker, score_frame, score_bench, intraday_history, cfg, datetime.utcnow())
                if rescored is not None:
                    current_score, score_available = rescored, True
            elif ticker in history:
                rescored, _ = score_for_mode(
                    getattr(pos, "mode", "") or MOMENTUM_MODE,
                    ticker, history[ticker], bench, history, cfg,
                    missing=None)
                # Too little history to score = no evidence of decay; the
                # position keeps its entry score rather than reading 0.
                if rescored is not None:
                    current_score = rescored
                    score_available = True
            if ir.is_due(pos, datetime.utcnow()):
                # Rescoring can cross 15:25 or the market close. Re-enter
                # deadline recovery with a new quote/time check, never execute
                # this earlier quote using the pre-scoring clock.
                exits.extend(self.square_off_intraday())
                continue
            xcfg = self._exit_cfg(pos, cfg)
            decision = de.exit_decision(pos, prices, datetime.utcnow(), session=not marking_only)
            decision["score_available"] = score_available
            decision["market_context"] = ci.observation(
                intraday_context if pos.mode == 'intraday' else refresh_context,
                ticker, score_frame, score_bench, xcfg, datetime.utcnow())
            decision["bar"] = intraday_score_diag or de.bar_context(score_frame)
            decision["benchmark"] = {"ticker": cfg.benchmark, **de.bar_context(score_bench)}
            if intraday_score_diag:
                decision["benchmark"] = {"ticker": cfg.benchmark, **refresh_data.get(cfg.benchmark, {})}
                decision["intraday_data"] = refresh_data.get(ticker, intraday_score_diag)
                decision["intraday_score"] = intraday_score_diag
                entry_bar = ((getattr(pos, "trade_evidence", {}) or {}).get("entry") or {}).get("bar") or {}
                decision["entry_score_comparable"] = entry_bar.get("interval") == "5m" and entry_bar.get("status") == "ready"
                decision["entry_score_comparison"] = {
                    "entry_interval": entry_bar.get("interval", "unavailable"),
                    "current_interval": "5m", "comparable": decision["entry_score_comparable"],
                    "reason": "same proved timeframe" if decision["entry_score_comparable"] else "Legacy daily/unproved entry score cannot establish a drop in five-minute score"}
            if not qe.executable(prices, ticker, datetime.utcnow()):
                de.journal_exit(self.portfolio, decision, "held", "quote_expired_during_rescoring")
                continue  # an expired candle cannot change the peak/trail either
            with de.capture(decision):
                should_exit, reason = check_exit(pos, price, current_score, xcfg, now)
            de.put(decision, "valuation_target", (getattr(pos, "val_target", None) or {}).get("exit_due"),
                   {"enabled": bool(getattr(cfg, "valuation_exit_enabled", True)), "target": pos.target_price},
                   state="skipped" if reason == "STOP_LOSS" or xcfg.disable_exits or not getattr(cfg, "valuation_exit_enabled", True) or not getattr(pos, "val_target", None) else None,
                   passed=bool((getattr(pos, "val_target", None) or {}).get("exit_due")), role="exit_trigger")
            # ITEM 19: a month-end re-mark put the valuation target at or
            # below that month-end's close — exit at this pass's price. The
            # stop keeps its priority, as in the tested check_exit order. It
            # is a target exit, so buy-and-hold (disable_exits) holds it too.
            if (reason != "STOP_LOSS"
                    and (getattr(pos, "val_target", None) or {}).get("exit_due")
                    and bool(getattr(cfg, "valuation_exit_enabled", True))
                    and not getattr(xcfg, "disable_exits", False)):
                should_exit, reason = True, "VAL_TARGET_DOWN"
            if should_exit and marking_only:
                # Owner order 2026-09-10: outside 09:15-15:30 the rule is SEEN
                # and RECORDED, never executed — a fill after the close is a
                # price nobody could get. It fires on the next in-session pass.
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(), "action": "EXIT_DUE_MARKET_CLOSED",
                    "ticker": ticker, "rule": reason,
                    "price": round(float(price), 2),
                    "why": (f"{reason} is due on {ticker} at ₹{price:,.2f}, but "
                            f"the market is {self._market_state(now).replace('_', ' ')}. "
                            f"It will fire on the next in-session pass."),
                })
            elif should_exit and qe.executable(prices, ticker, datetime.utcnow()):
                with de.capture(decision):
                    self._close(ticker, price, reason, datetime.utcnow())
                exits.append(ticker)
            elif ticker not in held_today:
                # WHY-RETAINED journal entry — why we kept it today
                upct = (price / pos.entry_price - 1) * 100 if pos.entry_price else 0
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(),
                    "action": "HOLD",
                    "ticker": ticker,
                    "price": round(price, 2),
                    "unrealised_pct": round(upct, 2),
                    "current_score": round(current_score, 1),
                    "score_at_entry": round(pos.entry_score, 1),
                    # FIX 2026-10-04: the text names THIS position's own
                    # levels and category rules (xcfg, the config the exit
                    # check above really used) — it printed the live mode's,
                    # so a positional holding read "max 200d" under momentum.
                    "why": (
                        f"{reason + chr(32) + 'pending valid quote;' if should_exit else 'No exit rule hit;'} ret {upct:+.1f}% with "
                        f"stop({_level(pos.stop_price, xcfg.stop_loss_pct)})"
                        f"/target({_level(pos.target_price, xcfg.take_profit_pct)}), "
                        + (f"score {current_score:.0f} vs decay-floor {xcfg.score_decay_exit:.0f}, "
                           if score_available else "current score unavailable; score-based exits held, ")
                        + f"held {(now.date() - pos.entry_date.date()).days}d of max "
                        f"{xcfg.max_hold_days}d ({getattr(pos, 'mode', '') or MOMENTUM_MODE})"
                    ),
                })

            if ticker in self.portfolio.positions:
                de.journal_exit(self.portfolio, decision, "held",
                    "quote_unavailable_or_non_executable" if not qe.executable(prices, ticker, datetime.utcnow()) else reason or "No exit trigger")

        now = datetime.utcnow()
        marking_only = not self._trading_allowed(now)
        # F15: pyramid — add tranches to winners (opt-in, cfg.pyramid_enabled).
        # A pyramid add is a BUY; the market-hours rule covers it.
        if getattr(cfg, "pyramid_enabled", False) and not marking_only:
            try:
                from .pyramid import pyramid_plan, apply_pyramid
                for ticker in list(self.portfolio.positions.keys()):
                    pos = self.portfolio.positions[ticker]
                    if ir.is_due(pos, datetime.utcnow()):
                        continue  # pending square-off cannot grow its position
                    if not qe.executable(prices, ticker, now):
                        continue
                    ltp = prices[ticker]
                    plan = pyramid_plan(pos, ltp, self.portfolio.cash, cfg)
                    if plan is None:
                        continue
                    add_qty, notional = plan
                    fill = slippage_price(ltp, "BUY", cfg)
                    next_basis = fees.add_basis(pos, add_qty, fill, now)
                    buy_cost = next_basis["orders"][-1]["fee"]["total"]
                    if add_qty * fill + buy_cost > self.portfolio.cash + 1e-8:
                        continue
                    self.portfolio.cash -= add_qty * fill + buy_cost
                    pos.cost_basis = next_basis
                    prev_adds = pos.pyramid_adds
                    before = de.protection(pos)
                    apply_pyramid(pos, add_qty, fill)
                    de.amendment(pos, before, "PYRAMID_ADD", now, portfolio=self.portfolio, details={"qty": add_qty, "fill": fill, "buy_costs": copy.deepcopy(next_basis["orders"][-1]["fee"])})
                    self.portfolio.decision_journal.append({
                        "ts": now.isoformat(), "action": "PYRAMID_ADD",
                        "ticker": ticker, "add_qty": add_qty,
                        "price": round(fill, 2), "tranche": prev_adds + 1,
                        "new_qty": pos.qty, "new_avg_entry": round(pos.entry_price, 2),
                        "why": f"Winner up {(ltp/pos.entry_price-1)*100:.1f}% — pyramid tranche {prev_adds+1}.",
                    })
            except Exception as e:
                log.warning("Pyramid add failed: %s", e)

        # If kill switch tripped, force-close everything else — unless exits are
        # disabled (buy-and-hold). AUDIT FIX A2: only names with a REAL quote
        # are closed; an unpriced name stays open (visible above) instead of
        # being force-filled at its entry price.
        if (self.risk.kill_switch and not getattr(cfg, "disable_exits", False)
                and not marking_only):
            for ticker in list(self.portfolio.positions.keys()):
                if ir.is_due(self.portfolio.positions[ticker], now):
                    continue  # deadline recovery owns the fresh quote/retry
                price = prices.get(ticker)
                if not price or price <= 0:
                    continue
                if not qe.executable(prices, ticker, datetime.utcnow()):
                    continue
                decision = de.exit_decision(self.portfolio.positions[ticker], prices, now)
                de.put(decision, "kill_switch", {"daily_pnl_pct": self.risk.daily_pnl_pct(current_eq),
                       "latched": self.risk.kill_switch, "baseline": self.risk.day_start_equity},
                       cfg.daily_loss_halt_pct, passed=True, role="exit_trigger")
                with de.capture(decision):
                    self._close(ticker, price, "KILL_SWITCH", now)
                exits.append(ticker)

        # P1/F3: drawdown-ladder crash brake — sells the worst positions when
        # the book falls -10% / -15% / -20% from its peak. Runs EVEN in hold
        # mode. Rules (owner order 2026-10-02) live in _update_drawdown.
        executable = qe.select(prices, lambda t, px: t in self.portfolio.positions
                      and not ir.is_due(self.portfolio.positions[t], now)
                      and qe.executable(prices, t, datetime.utcnow()))
        exits.extend(self._update_drawdown(executable, now,
                                           cut_allowed=not marking_only,
                                           marks=marks))

        self._record_equity(marks, now)
        self.portfolio.save()
        summary = self._summary_dict(marks)
        summary["exits_this_refresh"] = exits
        return summary

    # ---------- internals ----------

    def _open(self, pick: dict, qty: int, fill_price: float, now: datetime,
              cfg: Optional[Config] = None, *, initial_stop: Optional[float] = None) -> None:
        """Book a new position. `cfg` is the trade category's config; the
        engine's own (the live shared one) when not given. Audit F-17
        (2026-10-02): an owner limit fill passes a momentum COPY here instead
        of flipping the shared cfg.mode for the duration of the fill."""
        cfg = cfg if cfg is not None else self.cfg
        if (not ir.entry_allowed(cfg.mode, now)
                or not ir.entry_allowed(cfg.mode, datetime.utcnow())):
            raise ValueError("intraday_entry_deadline")
        # Audit S-12 (2026-10-02): the target is computed BEFORE the BUY line
        # so the line can carry how it was set (k, ATR, band) — it used to be
        # computed after, and the journal never said.
        target_price = self._target_for(pick, fill_price, cfg=cfg, now=now)
        # OWNER ORDER 2026-10-05 ("Go for A"): the stop is sized the same way
        # — the wider of the category stop and 2 x the name's own ATR, capped
        # (momentum only; see targets.py for the measurement). Computed here
        # so the BUY line carries how it was set.
        stop_price = (self._stop_for(pick, fill_price, cfg=cfg)
                      if initial_stop is None else float(initial_stop))
        if initial_stop is not None and not (math.isfinite(stop_price) and 0 < stop_price < fill_price):
            raise ValueError("invalid_proposed_stop")
        # Slow target/scoring work can outlive the bar or the entry window.
        # Recheck immediately before any journal/cash/position write. Owner
        # instructions have their own path and do not claim automatic signals.
        decision_path = (pick.get("decision") or {}).get("path")
        if cfg.mode == "intraday" and decision_path in ("scan", "ocean"):
            final_clock = datetime.utcnow()
            _, data_check = ib.validate(pick.get("history"), final_clock,
                                        min_bars=ib.required_bars(cfg))
            de.put(pick["decision"], "intraday_data_final", data_check, "still current at booking",
                   state="passed" if data_check["status"] == "ready" else "unavailable", reason=data_check["reason"])
            if data_check["status"] != "ready":
                raise ValueError("intraday_data_" + data_check["reason"])
        if not ir.entry_allowed(cfg.mode, datetime.utcnow()):
            raise ValueError("intraday_entry_deadline")
        quote = pick.get("quote_evidence") or {}
        if quote.get("source") == "upstox_1min_delayed":
            batch = qe.QuoteBatch({pick["ticker"]: quote.get("price")},
                                  evidence={pick["ticker"]: quote})
            quote_ok = qe.executable(batch, pick["ticker"], datetime.utcnow())
            if pick.get("decision"):
                de.put(pick["decision"], "quote_final", qe.observation(batch, pick["ticker"], datetime.utcnow()),
                       "Executable completed candle at booking", passed=quote_ok)
            if not quote_ok:
                raise ValueError("intraday_quote_expired_before_booking")
        notional = qty * fill_price
        cost_basis = fees.new_basis(qty, fill_price, cfg.mode, now, pick["ticker"], sector=cfg.sector_map.get(pick["ticker"], ""))
        buy_cost = cost_basis["orders"][0]["fee"]["total"]
        if notional + buy_cost > self.portfolio.cash + 1e-8:
            raise ValueError("costs_cash_short")
        decision = copy.deepcopy(pick.get("decision") or de.new(pick["ticker"], cfg.mode, pick.get("entry_path", "direct"), now, pick.get("history")))
        decision.setdefault("market_context", ci.unavailable(pick["ticker"], now))
        de.put(decision, "entry_deadline_final", ir.utc(now).isoformat(), "Before intraday square-off deadline", passed=True,
               state="skipped" if cfg.mode != "intraday" else None, reason="Final engine guard; other segments exempt")
        decision["quote"] = copy.deepcopy(pick.get("quote_evidence") or qe.observation({}, pick["ticker"], now))
        decision["fill"] = {"price": fill_price, "qty": qty, "notional": notional,
            "stop": stop_price, "target": target_price, "slippage_bps": cfg.slippage_bps,
            "target_method": de.clean(pick.get("target_diag") or {}), "stop_method": de.clean(pick.get("stop_diag") or {})}
        decision["fill"]["buy_costs"] = copy.deepcopy(cost_basis["orders"][0]["fee"])
        decision["sizing"] = de.clean(pick.get("size_diag") or {})
        decision["ifr_multiplier"] = pick.get("ifr_applied_multiplier")
        decision["ifr_last_fire"] = self.portfolio.last_ifr_fire_date
        entry_evidence = de.finish(decision, "bought", pick.get("reasoning", ""))
        trade_evidence = {"schema": 1, "trade_id": decision["id"], "entry": entry_evidence,
                          "amendments": [], "amendments_omitted": 0}
        # SEQ-11: version the actual filled entry. Observation never changes eligibility.
        try:
            from .validation import entry_record
            trade_evidence["validation"] = entry_record(cfg, pick, now, qty=qty)
        except Exception as exc:
            trade_evidence["validation_error"] = type(exc).__name__
        self.portfolio.cash -= notional + buy_cost
        # WHY-BOUGHT journal entry — full decision context, never deleted
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(),
            "action": "BUY",
            "trade_id": trade_evidence["trade_id"],
            "decision_id": decision["id"],
            "evidence": copy.deepcopy(entry_evidence),
            "ticker": pick["ticker"],
            "qty": qty,
            "price": round(fill_price, 2),
            "notional": round(notional, 2),
            "score": round(pick.get("score", 0), 2),
            "components": {k: round(v, 1) for k, v in (pick.get("components") or {}).items()},
            "timing_pass": pick.get("timing_pass"),
            "mode": getattr(cfg, "mode", "?"),
            "regime": self.portfolio.last_regime,
            "drawdown_level": getattr(self.drawdown_gov, "active_level", "?"),
            "ifr_active": (pick["ifr_applied_multiplier"] < 1 if "ifr_applied_multiplier" in pick else None),
            "ifr_multiplier": pick.get("ifr_applied_multiplier"),
            "ifr_last_fire": self.portfolio.last_ifr_fire_date,
            "why": pick.get("reasoning", ""),
            "cash_after": round(self.portfolio.cash, 2),
            # AUDIT FIX A10: where the fill price came from — live_quote when
            # the broker answered, prev_close when it didn't. Never hidden.
            "fill_source": pick.get("fill_source", "prev_close"),
            # Owner order 2026-07-30: how this size was decided (½-Kelly inputs
            # or "fixed"), so any trade's size can be re-derived later.
            "sizing": pick.get("size_diag") or {"mode": "fixed"},
            "target": {"price": target_price,
                       **(pick.get("target_diag") or {})},
            "stop": {"price": stop_price,
                     **(pick.get("stop_diag") or {})},
            # P2: config snapshot so every decision stays reproducible after
            # settings change later.
            "config_snapshot": {
                "stop_loss_pct": cfg.stop_loss_pct,
                "take_profit_pct": cfg.take_profit_pct,
                "cash_reserve_pct": cfg.cash_reserve_pct,
                "sizing_mode": getattr(cfg, "sizing_mode", "fixed"),
                "kelly_fraction": getattr(cfg, "kelly_fraction", 0.0),
                "kelly_ic": getattr(cfg, "kelly_ic", 0.0),
                "kelly_max_pct": getattr(cfg, "kelly_max_pct", 0.0),
                "position_size_value": getattr(cfg, "position_size_value", 0.0),
                "max_position_pct": cfg.max_position_pct,
                "max_positions": cfg.max_positions,
                "min_score_to_enter": cfg.min_score_to_enter,
                "disable_exits": getattr(cfg, "disable_exits", False),
            },
        })
        # Snapshot the trade category + exit levels at entry so the position
        # carries its own stop/target (the daily scan rotates cfg.mode across
        # intraday/short/swing/positional, so the live cfg won't match later).
        self.portfolio.positions[pick["ticker"]] = PaperPosition(
            ticker=pick["ticker"], qty=qty, entry_price=fill_price,
            entry_date=now, sector=cfg.sector_map.get(pick["ticker"], "Unknown"),
            peak_price=fill_price, entry_score=pick["score"],
            reasoning=pick["reasoning"],
            mode=getattr(cfg, "mode", ""),
            trade_evidence=copy.deepcopy(trade_evidence),
            cost_basis=cost_basis,
            stop_price=stop_price,
            # OWNER ORDER 2026-09-10 ("C- k x ATR"): the target is k average
            # days of range away, per horizon, not a flat percentage — a quiet
            # name gets a nearer target than a wild one. Falls back to the
            # mode's fixed percentage when the ATR cannot be computed; the
            # diagnostic in the BUY journal says which was used, so a screen
            # can never show an ATR target that was really the old number.
            target_price=target_price,
            # the tag is the Ocean slot counter (max 8) and the audit trail
            tags=(["ocean"] if pick.get("ocean") else []),
            # Item 19: where the target came from (valuation base or k x ATR)
            val_target=copy.deepcopy(pick.pop("val_target", None) or {}),
        )
        pm.remember(self.portfolio.positions[pick["ticker"]], fill_price,
                    "entry_fill", now, asof=now.date().isoformat())
        ir.ensure(self.portfolio.positions[pick["ticker"]], now)

    def _store_momentum_shortlist(self, ranked: list, history: dict,
                                  skip_by_t: dict, now: datetime,
                                  abs_mom_ok) -> None:
        """The momentum pass's own record for the Buy Desk and the trigger /
        news scope (audit S-11 / S-13, 2026-10-02). Kept small on purpose —
        only rows at or above the floor, plus the top 50 tickers in rank
        order — because it rides in the portfolio document.

        `liq` is the entry gate's own liquidity verdict
        (`risk_v2.passes_liquidity`, same inputs as the gate) computed for
        EVERY stored row. The old shortlist read "no liquidity_* outcome" as
        "cleared liquidity", but a pass stopped earlier by the breadth band,
        a halt or the market clock never reaches the liquidity gate, so an
        illiquid name read as cleared. None = no history to judge."""
        from .risk_v2 import passes_liquidity
        cfg = self.cfg
        floor = float(cfg.min_score_to_enter)
        rows: dict = {}
        for r in ranked:
            t = r["ticker"]
            if float(r["score"]) < floor:
                continue
            liq, why = None, "no_history"
            h = history.get(t)
            if h is not None:
                try:
                    liq, why = passes_liquidity(
                        h["Close"], h["Volume"],
                        last_high=float(h["High"].iloc[-1]),
                        last_low=float(h["Low"].iloc[-1]),
                        last_open=float(h["Open"].iloc[-1]),
                        last_close=float(h["Close"].iloc[-1]))
                except Exception:
                    liq, why = None, "liquidity_check_failed"
            rows[t] = {
                "score": round(float(r["score"]), 1),
                "abs_mom": bool(abs_mom_ok(t)),
                "timing": bool(r["timing_pass"]),
                "liq": liq, "liq_why": (why or "")[:60],
                "outcome": skip_by_t.get(t, ""),
                "c": {k: round(float(v), 1)
                      for k, v in (r.get("components") or {}).items()},
            }
        self.portfolio.momentum_shortlist = {
            "ts": now.isoformat(), "mode": MOMENTUM_MODE,
            "score_floor": floor,
            "top": [r["ticker"] for r in ranked[:50]],
            "rows": rows,
        }

    @staticmethod
    def _throttled_qty(qty: int, throttle: float, fill: float,
                       slab: float) -> int:
        """Apply the IFR / drawdown size throttle to an approved quantity.

        AUDIT F-5 (2026-10-02): a throttle shrinks a bet, it never takes it
        below the owner's minimum ticket. The slab (owner order 2026-09-10,
        "150000 slab as minimum") was being halved to Rs 75,000 AFTER the risk
        check had approved it. Never more than the approved quantity."""
        out = int(qty * throttle)
        if throttle < 1.0 and slab > 0 and fill > 0 and qty * fill >= slab:
            out = max(out, min(int(qty), int(math.ceil(slab / fill))))
        return out

    def _target_for(self, pick: dict, fill_price: float,
                    cfg: Optional[Config] = None,
                    now: Optional[datetime] = None) -> float:
        """Target for a new position: k x ATR (owner order 2026-09-10),
        replaced by the valuation base when the name's stored record is
        judged (item 19, owner order 2026-10-21) — see _valuation_target.

        `pick` carries the scan's own history frame under "history" when the
        caller has one; without it the fallback is the mode's fixed percentage
        — never an invented range.
        """
        from .targets import target_price_for
        cfg = cfg if cfg is not None else self.cfg
        df = pick.get("history")
        try:
            price, diag = target_price_for(
                getattr(cfg, "mode", ""), float(fill_price), df,
                float(cfg.take_profit_pct))
        except Exception:
            log.exception("ATR target failed — mode percentage used")
            diag = {"source": "fixed", "reason": "atr_failed"}
            price = round(float(fill_price) * (1 + cfg.take_profit_pct), 2)
        pick["target_diag"] = diag
        try:
            return self._valuation_target(pick, float(fill_price), price, cfg, now)
        except Exception:
            log.exception("valuation exit target failed — k x ATR kept")
            pick["val_target"] = {"source": "k_atr", "reason": "valuation_failed"}
            return price

    def _valuation_target(self, pick: dict, fill: float, k_atr: float,
                          cfg: Config, now: Optional[datetime]) -> float:
        """ITEM 19 (owner order 2026-10-21, "Wire A3" + "Exit as tested").

        Every new buy — scan, Ocean, owner BUY, Buy Desk, limit fill (they
        all come through _open) — takes the name's valuation base as its
        target when the stored record is judged (attractive / watch, range
        OK), at most RECORD_MAX_AGE_DAYS old and above fill x 1.05: the rule
        measured in the pre-registered study (TEST +5.68% vs k x ATR
        +5.46%). Else k x ATR exactly as before, with the reason. Intraday
        is left out: it is squared off the same day. A hand-typed target on
        the owner ticket replaces either one afterwards (orders.py)."""
        from . import valuation_exit as VE
        k_diag = dict(pick.get("target_diag") or {})
        now = now or datetime.utcnow()
        today = self._ist(now).date()
        mode = getattr(cfg, "mode", "") or MOMENTUM_MODE
        enabled = bool(getattr(cfg, "valuation_exit_enabled", True))
        rec = None
        if not enabled:
            target, vdiag = None, {"reason": "disabled"}
        elif mode == "intraday":
            target, vdiag = None, {"reason": "intraday"}
        elif not VE.ready():
            target, vdiag = None, {"reason": "no_reader"}
        else:
            rec = VE.records_for([pick["ticker"]]).get(pick["ticker"])
            target, vdiag = VE.target_from_record(rec, fill, today)
        if target is None:
            pick["val_target"] = {"source": "k_atr", "reason": vdiag.get("reason"),
                                  "k_atr_target": k_atr}
            pick["target_diag"] = {**k_diag, "k_atr_target": k_atr,
                                   "valuation": vdiag.get("reason")}
            return k_atr
        sector_index = rec.get("sector_index") or VE.MARKET_SECTOR
        kind, name = VE.leg_for(sector_index)
        pick["val_target"] = {
            "source": "valuation", "base": target, "asof": vdiag["asof"],
            "verdict": vdiag["verdict"], "family": vdiag["family"],
            "t_entry": target, "k_atr_target": k_atr,
            # levels at the BUY (the latest stored close); the re-mark reads
            # the anchor day's own close and falls back to these
            "sensex_entry": VE.level("sensex"),
            "sector_entry": VE.level(kind, name),
            "sector_index": sector_index, "beta": rec.get("beta"),
            "entry_fill_date": today.isoformat(), "anchor_date": today.isoformat(),
            "last_remark_month": None, "remarks": [], "exit_due": False,
        }
        pick["target_diag"] = {"source": "valuation", "base": target,
                               "asof": vdiag["asof"], "verdict": vdiag["verdict"],
                               "family": vdiag["family"], "k_atr_target": k_atr,
                               "k_atr_source": k_diag.get("source")}
        return target

    def _valuation_pass(self, prices: dict, history: dict, now: datetime,
                        retarget: bool = True) -> None:
        """ITEM 19 on HELD positions: the A3 re-target (in-session passes
        only — `retarget`), then the monthly re-mark (see
        trading/valuation_exit.py). Switched off = nothing here runs and
        every held target stays as it is."""
        from . import valuation_exit as VE
        if not bool(getattr(self.cfg, "valuation_exit_enabled", True)):
            return
        if not self.portfolio.positions or not VE.ready():
            return
        today = self._ist(now).date()
        if retarget:
            self._valuation_retarget(VE, today, now, prices)
        for ticker in list(self.portfolio.positions.keys()):
            pos = self.portfolio.positions[ticker]
            vt = getattr(pos, "val_target", None) or {}
            if vt.get("source") not in VE.SOURCE_SET:
                continue
            month = VE.month_closed(today, vt.get("last_remark_month"))
            if month is None:
                continue
            try:
                self._valuation_remark(VE, pos, vt, month, history, prices, now)
            except Exception:
                # one bad position never stops the others' re-marks
                log.exception("valuation re-mark failed for %s", ticker)
                self._journal_once_a_day("VALUATION_PASS_FAILED", now, {
                    "ticker": ticker,
                    "why": f"re-mark of {ticker} raised; its target is unchanged"})

    def _valuation_retarget(self, VE, today, now: datetime,
                            prices: Optional[dict] = None) -> None:
        """A3 ("also do it on open positions"): a held position still on
        k x ATR (or opened before item 19) whose record NOW qualifies —
        judged, fresh, base above its ENTRY price x 1.05, and still judged at
        this pass's price (VE.retarget_price_ok) — takes the base as its
        target, once. Hand-set levels and intraday positions are left
        alone. Legs are anchored at today."""
        cand = []
        for t, pos in self.portfolio.positions.items():
            vt = getattr(pos, "val_target", None) or {}
            if vt.get("source") not in (None, "", "k_atr") or vt.get("retargeted"):
                continue
            if getattr(pos, "custom_levels", False):
                continue
            if (getattr(pos, "mode", "") or "") == "intraday":
                continue
            cand.append(t)
        if not cand:
            return
        recs = VE.records_for(cand)
        for t in cand:
            try:
                self._valuation_retarget_one(VE, t, recs.get(t), today, now,
                                             (prices or {}).get(t))
            except Exception:
                # one bad position never stops the others' re-targets
                log.exception("valuation re-target failed for %s", t)
                self._journal_once_a_day("VALUATION_PASS_FAILED", now, {
                    "ticker": t,
                    "why": f"re-target of {t} raised; its target is unchanged"})

    def _valuation_retarget_one(self, VE, t: str, rec, today, now: datetime,
                                price=None) -> None:
        """A3 for one held position (see _valuation_retarget)."""
        pos = self.portfolio.positions[t]
        target, diag = VE.target_from_record(rec, pos.entry_price, today)
        if target is None:
            return
        # the study's re-target read a verdict on that same close: a price
        # now above base x 1.10 or the range high would read unattractive
        if not VE.retarget_price_ok(rec, price)[0]:
            return
        old = float(getattr(pos, "target_price", 0.0) or 0.0)
        sector_index = rec.get("sector_index") or VE.MARKET_SECTOR
        kind, name = VE.leg_for(sector_index)
        entry_day = VE.as_date(getattr(pos, "entry_date", None))
        # built in full before anything on the position changes
        vt = {
            "source": "retarget", "retargeted": True,
            "retarget_date": today.isoformat(), "old_target": round(old, 2),
            "base": target, "asof": diag["asof"], "verdict": diag["verdict"],
            "family": diag["family"], "t_entry": target, "k_atr_target": round(old, 2),
            "sensex_entry": VE.level("sensex"), "sector_entry": VE.level(kind, name),
            "sector_index": sector_index, "beta": rec.get("beta"),
            "entry_fill_date": entry_day.isoformat() if entry_day else "",
            "anchor_date": today.isoformat(),
            "last_remark_month": None, "remarks": [], "exit_due": False,
        }
        before = de.protection(pos)
        pos.target_price = target
        pos.val_target = vt
        de.amendment(pos, before, "VALUATION_RETARGET", now, portfolio=self.portfolio, details=diag)
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(), "action": "VALUATION_RETARGET",
            "ticker": t, "old_target": round(old, 2), "new_target": target,
            "asof": diag["asof"], "verdict": diag["verdict"],
            "family": diag["family"], "price": round(float(price), 2),
            "why": (f"Held on k x ATR ({old:,.2f}); its valuation record of "
                    f"{diag['asof']} is {diag['verdict']} with base "
                    f"{target:,.2f} above entry {pos.entry_price:,.2f} x "
                    f"{VE.VALUATION_EXIT_MARGIN} — the base is its target "
                    "now (owner order 2026-10-21, 'also do it on open "
                    "positions'), re-marked each closed month."
                    + (f" The price {float(price):,.2f} is already at or above "
                       "it, so it takes profit on this pass."
                       if float(price) >= target else "")),
        })

    def _valuation_remark(self, VE, pos, vt: dict, month: str, history: dict,
                          prices: dict, now: datetime) -> None:
        """A2: re-mark ONE valuation target for a closed month."""
        me = VE.month_end(month)
        anchor = VE.as_date(vt.get("anchor_date"))
        if me is None or anchor is None or anchor >= me:
            # bought / re-targeted after that month-end: nothing to re-mark
            vt["last_remark_month"] = month
            return
        me_iso, an_iso = me.isoformat(), anchor.isoformat()
        sx_me = VE.level("sensex", None, me_iso)
        if sx_me is None:
            # the month-end close is not stored yet — retried next pass
            self._journal_once_a_day("VALUATION_REMARK_WAITING", now, {
                "month": month,
                "why": (f"Month {month} closed but the Sensex close of {me_iso} "
                        "is not stored yet; valuation targets are re-marked on "
                        "the next pass that has it.")})
            return
        sx_an = VE.level("sensex", None, an_iso) or VE.num(vt.get("sensex_entry"))
        kind, name = VE.leg_for(vt.get("sector_index"))
        leg = vt.get("sector_index") or VE.MARKET_SECTOR
        k_me = VE.level(kind, name, me_iso)
        k_an = VE.level(kind, name, an_iso) or (
            VE.num(vt.get("sector_entry")) if k_me is not None else None)
        if kind == "sector" and (k_me is None or k_an is None):
            # the sector index does not reach these dates: the market leg
            k_me = VE.level("nifty", None, me_iso)
            k_an = VE.level("nifty", None, an_iso)
            leg = f"{VE.MARKET_SECTOR} (no stored {name} close)"
        t_m = VE.remarked_target(vt.get("t_entry"), sx_an, sx_me, k_an, k_me,
                                 vt.get("beta"))
        if t_m is None:
            vt["last_remark_month"] = month
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "VALUATION_REMARK",
                "ticker": pos.ticker, "month": month, "skipped": True,
                "why": (f"{month}: a leg level is missing (Sensex {sx_an}->{sx_me}, "
                        f"{leg} {k_an}->{k_me}) — target left at "
                        f"{pos.target_price:,.2f} this month, as the study skipped it.")})
            return
        close, close_src = self._month_end_close(pos.ticker, history, me, prices)
        if (close_src != "history"
                and (self._ist(now).date() - me).days <= VE.REMARK_CLOSE_WAIT_DAYS):
            # the study compared T_m with the stock's OWN month-end close; the
            # store gets it with the next morning's top-up — wait for it
            # rather than judge on today's price (retried next pass)
            self._journal_once_a_day("VALUATION_REMARK_WAITING", now, {
                "month": month, "ticker": pos.ticker,
                "why": (f"Month {month} closed but {pos.ticker}'s own close of "
                        f"{me_iso} is not stored yet; its valuation target is "
                        "re-marked on the next pass that has it (after "
                        f"{VE.REMARK_CLOSE_WAIT_DAYS} days the pass's own price "
                        "is used and named).")})
            return
        down = VE.target_down(t_m, close)
        old = float(pos.target_price or 0.0)
        sm, sc = sx_me / sx_an - 1.0, k_me / k_an - 1.0
        beta = VE.num(vt.get("beta"))
        # the history row is built before the position changes
        rows = list(vt.get("remarks") or [])
        rows.append(VE.remark_entry(month, me, sm, sc, beta if beta is not None else 1.0,
                                    t_m, close, leg))
        before = de.protection(pos)
        pos.target_price = round(float(t_m), 2)
        de.amendment(pos, before, "VALUATION_REMARK", now, portfolio=self.portfolio, details={"month": month})
        vt["remarks"] = rows[-VE.REMARKS_CAP:]
        vt["last_remark_month"] = month
        if down:
            vt["exit_due"] = True
        pos.val_target = vt
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(), "action": "VALUATION_REMARK",
            "ticker": pos.ticker, "month": month, "month_end": me_iso,
            "old_target": round(old, 2), "new_target": pos.target_price,
            "sensex_move_pct": round(sm * 100, 2), "sector_move_pct": round(sc * 100, 2),
            "sector_leg": leg, "beta": beta if beta is not None else 1.0,
            "beta_source": "record" if beta is not None else "fallback_1",
            "close": None if close is None else round(close, 2),
            "close_source": close_src, "exit_due": bool(down),
            "why": (f"{month} closed: target {old:,.2f} -> {pos.target_price:,.2f} "
                    f"(Sensex {sm * 100:+.2f}%, {leg} {sc * 100:+.2f}%, beta "
                    f"{beta if beta is not None else 1.0:.2f}). "
                    + (f"At or below the {me_iso} close {close:,.2f} — exits on "
                       "the next in-session pass (VAL_TARGET_DOWN)."
                       if down else "Above the month-end close — held.")),
        })

    @staticmethod
    def _month_end_close(ticker: str, history: dict, me, prices: dict):
        """(close, source): the stock's own stored close on or before the
        month-end when its history reaches that day, else the live price
        of this pass ("live_mark"), else (None, "none")."""
        frame = (history or {}).get(ticker)
        try:
            c = frame["Close"].dropna()
            c.index = pd.to_datetime(c.index)
            if len(c) and c.index[-1].date() >= me:
                part = c[c.index <= pd.Timestamp(me)]
                if len(part):
                    return float(part.iloc[-1]), "history"
        except Exception:
            pass
        px = (prices or {}).get(ticker)
        if px and float(px) > 0:
            return float(px), "live_mark"
        return None, "none"

    def _stop_for(self, pick: dict, fill_price: float,
                  cfg: Optional[Config] = None) -> float:
        """Stop for a new position (owner order 2026-10-05, "Go for A"):
        the wider of the category's stop and ATR_STOP_K x ATR14, capped —
        momentum only, measured in research/stop_cooldown_study. Every other
        case, and any failure, is the category's fixed stop; the diagnostic
        on the pick says which."""
        from .targets import stop_price_for
        cfg = cfg if cfg is not None else self.cfg
        df = pick.get("history")
        try:
            price, diag = stop_price_for(
                getattr(cfg, "mode", ""), float(fill_price), df,
                float(cfg.stop_loss_pct),
                enabled=bool(getattr(cfg, "atr_stop_enabled", True)))
        except Exception:
            log.exception("ATR stop failed — category stop used")
            pick["stop_diag"] = {"source": "fixed", "reason": "atr_failed"}
            return round(float(fill_price) * (1 + cfg.stop_loss_pct), 2)
        pick["stop_diag"] = diag
        return price

    def _danger_pass(self, prices: dict, history: dict, now: datetime) -> None:
        """Mode C (alerts, first 7 days) then mode B (auto per-stock defence).
        1 VERIFIED danger trigger on a held name -> tighten stop to -2.5%
        off the live price (never loosened); 2+ -> exit half. Journaled and
        pushed; once per ticker per day."""
        cfg = self.cfg
        if not getattr(cfg, "danger_layer_enabled", False):
            return
        from . import danger
        if not danger.VERIFIED:
            return                      # calibration file missing = inert
        today_iso = now.date().isoformat()
        if not self.portfolio.danger_alerts_start:
            self.portfolio.danger_alerts_start = today_iso
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "DANGER_LAYER_ARMED",
                "why": (f"Danger layer live (owner order 2026-08-11): "
                        f"{len(danger.VERIFIED)} VERIFIED tripwires "
                        f"({len(danger.PANEL_FED)} panel-fed, added on the "
                        "2026-08-13 order, cleared the main +/-10% labels; the "
                        "rest cleared strict +/-15%) "
                        f"watch held names. Alerts-only for "
                        f"{danger.ALERT_DAYS} days, then auto per-stock "
                        "defence (tighten/-2.5% on 1 fire, exit half on 2+)."),
            })
        auto = danger.auto_mode_active(self.portfolio.danger_alerts_start,
                                       today_iso)
        # Panels for the panel-fed tripwires (owner order 2026-08-13: Index
        # Risk Overlay + Sector Contagion Count). ONE light load for the whole
        # held book — peer panel + index only, never the 3.5M-row delivery
        # file. None on any failure, which makes those two abstain instead of
        # guessing; journaled once a day so a silent loss of cover is visible.
        held = list(self.portfolio.positions.keys())
        ext_map = danger.externals_for(held, history, now) if danger.PANEL_FED else None
        if danger.PANEL_FED and ext_map is None and held:
            already = any(
                e.get("action") == "DANGER_PANELS_UNAVAILABLE"
                and str(e.get("ts", "")).startswith(today_iso)
                for e in self.portfolio.decision_journal[-300:])
            if not already:
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(),
                    "action": "DANGER_PANELS_UNAVAILABLE",
                    "why": (f"{len(danger.PANEL_FED)} panel-fed tripwires "
                            f"({', '.join(danger.PANEL_FED)}) could not read "
                            "their panels this run and abstained. The "
                            f"{len(danger.VERIFIED) - len(danger.PANEL_FED)} "
                            "OHLCV tripwires still ran."),
                })
        seen_today = {
            e.get("ticker") for e in self.portfolio.decision_journal[-300:]
            if str(e.get("action", "")).startswith("DANGER_")
            and str(e.get("ts", "")).startswith(today_iso)
        }
        for ticker in list(self.portfolio.positions.keys()):
            if ticker in seen_today:
                continue
            price = prices.get(ticker)
            df = history.get(ticker)
            if not price or price <= 0 or df is None or len(df) < 60:
                continue                # no quote / thin history = no action
            danger_decision = de.exit_decision(self.portfolio.positions[ticker], prices, now)
            danger_decision["bar"] = de.bar_context(df)
            danger_decision['external_context'] = de.clean(getattr((ext_map or {}).get(ticker), 'context', {}))
            with de.capture(danger_decision):
                fired = danger.evaluate_stock(df, ext=(ext_map or {}).get(ticker))
            reading = danger.plan(ticker, fired, auto)
            action_clock = datetime.utcnow()
            if not qe.executable(prices, ticker, action_clock) or not self._trading_allowed(action_clock):
                de.journal_exit(self.portfolio, danger_decision, "held", "quote_or_session_expired_during_danger_check")
                continue
            de.put(danger_decision, "danger", {"fired": fired, "automatic": auto, "action": reading.action},
                   {"tighten": "1 trigger", "exit_half": ">=2 triggers", "alert_only_days": danger.ALERT_DAYS},
                   passed=bool(fired), role="exit_trigger")
            if reading.action == "NONE":
                de.journal_exit(self.portfolio, danger_decision, "held", "No danger action")
                continue
            pos = self.portfolio.positions[ticker]
            # OWNER ORDER 2026-09-16: the danger layer may tighten a stop, but
            # never tighter than the stop the owner chose.
            #
            # WHY. danger.TIGHTEN_PCT is -2.5% off the LIVE price and is an
            # ASSUMED number — no measurement anywhere in this repo backs it,
            # unlike the 12 tripwires themselves (lift 1.6-4.1x, strict
            # labels). It also predates the 30-minute in-session pass
            # (2026-09-10), which took stop checking from ~2 times a day to
            # ~13. A 2.5% leash checked 13 times a day in a five-week decline
            # sells almost anything, and because the tighten sets
            # custom_levels the position never gets its -5% back.
            #
            # The LEASH LENGTH is floored at the owner's own stop width, so
            # this still trails a winner up (the stop rises with the price) but
            # can no longer be narrower than the risk they accepted. Reads
            # cfg, so if they ever set -3% the floor follows them.
            # FIX 2026-10-04: the width is the POSITION's own category stop
            # (engine._exit_cfg, the same per-mode config every other exit
            # reads since audit F-6). It read the live shared cfg — so with the
            # app in momentum, a positional holding's -10% stop was tightened
            # to momentum's -5% and sold at -6%, a loss its own stop would
            # have held (found by the 2026-10-04 exit-per-category check).
            pos_cfg = self._exit_cfg(pos, cfg)
            # 2026-10-05 ("Go for A"): a momentum buy may carry a stop WIDER
            # than the category's -5% (2 x its own ATR). The risk accepted at
            # entry is that width, so the leash is floored at it too — the
            # same rule as above, read off the position's own stop. A stop
            # already tightened above entry contributes nothing here.
            entry_width = 0.0
            try:
                _sp = float(getattr(pos, "stop_price", 0.0) or 0.0)
                _ep = float(pos.entry_price or 0.0)
                if 0 < _sp < _ep:
                    entry_width = (_ep - _sp) / _ep
            except (TypeError, ValueError):
                entry_width = 0.0
            leash = max(abs(float(danger.TIGHTEN_PCT)),
                        abs(float(getattr(pos_cfg, "stop_loss_pct", -0.05))),
                        entry_width)
            entry = {
                "ts": now.isoformat(), "ticker": ticker,
                "fired": reading.fired, "price": round(price, 2),
                "leash_pct": round(leash * 100, 2),
                "why": danger.describe(reading, auto, leash_pct=leash),
            }
            if reading.action == "ALERT":
                entry["action"] = "DANGER_ALERT"
            elif reading.action == "TIGHTEN":
                new_stop = round(price * (1 - leash), 2)
                if new_stop > (pos.stop_price or 0):
                    before = de.protection(pos)
                    pos.stop_price = new_stop
                    pos.custom_levels = True   # survives boot retag
                    de.amendment(pos, before, "DANGER_TIGHTEN", now, portfolio=self.portfolio, details={"fired": reading.fired, "leash": leash, "decision": de.finish(danger_decision, "stop_amended", "DANGER_TIGHTEN", exit=True)})
                    entry["action"] = "DANGER_TIGHTEN"
                    entry["new_stop"] = new_stop
                else:
                    entry["action"] = "DANGER_ALERT"
                    entry["why"] += " (existing stop already tighter)"
            elif reading.action == "EXIT_HALF":
                decision = danger_decision
                de.put(decision, "danger", {"fired": reading.fired, "action": reading.action, "automatic": auto},
                       {"leash": leash, "exit_half": ">=2 verified triggers with automatic mode active"}, passed=True, role="exit_trigger")
                with de.capture(decision):
                    self._exit_half(ticker, price,
                                    danger.describe(reading, auto, leash_pct=leash), now)
                entry["action"] = "DANGER_EXIT_HALF"
            self.portfolio.decision_journal.append(entry)
        self.portfolio.save()

    def _rotation_exits(self, picks: list, now: datetime,
                        entries_blocked: bool = False,
                        history: Optional[dict] = None) -> list:
        """OWNER ORDER 2026-09-04 ("skipper exit suggestion is there but not
        executed — make it happen"): the F6 rotation suggester EXECUTES.

        The suggester's own rule, unchanged: a position >= rotation_min_progress
        of the way to its target has little upside left, so if a fresh pick
        cannot be funded from cash, that position is sold to free the capital
        and the opening loop that follows funds the pick.

        Guards, each with its reason:
          * only when cash is actually SHORT for the fresh picks — otherwise
            the +20% target handles the near-target name, and selling early
            just gives up its last stretch for nothing;
          * only as many rotations as the shortfall needs, highest progress
            first — three near-target names must never be sold to fund one;
          * owner_pick positions are exempt, the same rule the score-decay
            exit follows: the owner's own picks are theirs to sell;
          * a LIVE quote is fetched for every candidate, and a name with none
            is left alone and journaled — never an invented fill (the
            2026-08-04 rule). The suggester reads progress off the live quote,
            so an unquoted name cannot even be suggested.
        Returns the tickers rotated out.
        """
        cfg = self.cfg
        if not ir.entry_allowed(cfg.mode, datetime.utcnow()):
            return []
        if not bool(getattr(cfg, "rotation_auto_enabled", True)):
            return []
        held = self.portfolio.positions
        fresh = [pk for pk in (picks or [])
                 if pk.get("ticker") and pk["ticker"] not in held]
        if not held:
            return []

        # FIX 1 of 2 (owner order 2026-09-16). Rotation is a SALE, and the
        # owner's 2026-09-10 order was "yes all block" outside 09:15-15:30 IST.
        # refresh() honoured that via marking_only; this branch never did — it
        # sits AFTER the market-hours gate in scan(), which only empties the
        # pick list and then falls through to here. The catch-up scan fires ~2
        # minutes after every boot, so a Render restart at 21:00 could sell the
        # owner's position at a price nobody could have got.
        if not self._trading_allowed(now):
            self._journal_once_a_day("ROTATION_MARKET_CLOSED", now, {
                "market_state": self._market_state(now),
                "why": (f"Rotation stood down — market is "
                        f"{self._market_state(now).replace('_', ' ')}. A rotation is "
                        f"a sale, and sales outside 09:15-15:30 IST are blocked "
                        f"(owner order 2026-09-10)."),
            })
            return []

        # FIX 2 of 2. Rotation exists to FUND A BUY. When the breadth gate has
        # just refused every entry, there is no buy to fund — yet the watchlist
        # fallback (removed by audit F-7, 2026-10-02) would still find scored
        # names and sell a near-target winner to chase one the engine will not
        # purchase today. That is the drain the owner reported: positions
        # leave, nothing arrives. Kept for its distinct journal line.
        #
        # Deliberately narrow: a real funded pick still rotates normally. Ocean
        # is exempt from the breadth gate, so an ocean pick reaching here IS a
        # buy that will happen, and rotation may fund it.
        if entries_blocked and not fresh:
            self._journal_once_a_day("ROTATION_STOOD_DOWN", now, {
                "why": ("Rotation stood down — the breadth gate blocked every "
                        "entry this scan, so there is nothing to fund. Selling "
                        "a near-target position to chase a name the engine has "
                        "refused to buy today would shrink the book for "
                        "nothing."),
            })
            return []

        # OWNER ORDER 2026-09-10: "Rotation is combinaton of a & b, but for b
        # there is simple trigger point when cash is below 5%, rest all the
        # time rotaiton will be done as per a- adding & rotating from watch
        # list".
        #   (a) a near-target name rotates into a name the engine is ADDING;
        #   (b) cash under 5% of the book is a hard trigger to free a ticket.
        #
        # AUDIT F-7 (owner: "go for next", 2026-10-02). Two faults:
        #   1. When the scan produced no pick, (a) fell back to the last scan's
        #      watchlist rows — names scored above the floor but REFUSED by
        #      this scan's own gates (timing, absolute momentum, regime). The
        #      opening loop below only ever buys `picks`, so a near-target
        #      winner was sold to fund a name nobody would buy. Every name the
        #      scan would really add is already IN `picks` (selection has no
        #      top-N cap), so "adding from the watch list" means exactly this
        #      scan's picks — rotation now funds only those.
        #   2. The cash need was sized with no price history, so every ticket
        #      read as the Rs 1.5 lakh slab while the real slab-Kelly ticket
        #      for a strong score can be Rs 4-13 lakh. The need now uses each
        #      pick's own history — the same inputs the opening loop sizes on.
        from .sizing import position_notional_for
        eq = self.portfolio.cash + sum(
            float(p.qty) * float(p.entry_price) for p in held.values())
        reserve = float(getattr(cfg, "cash_reserve_pct", 0.0) or 0.0)
        spendable = self.portfolio.cash - eq * reserve

        def _close_of(pk: dict):
            frame = pk.get("risk_history")
            if frame is None:
                frame = pk.get("history")
            if frame is None and history:
                frame = history.get(pk.get("ticker"))
            try:
                return frame["Close"].dropna() if frame is not None else None
            except Exception:
                return None

        def _ticket(pk: dict) -> float:
            if pk.get("ocean"):
                return float(getattr(cfg, "ocean_position_value", 0) or 0)
            return float(position_notional_for(
                cfg, eq, score=pk.get("score"), close=_close_of(pk))[0] or 0)

        # (b) the owner's cash trigger.
        cash_floor = float(getattr(cfg, "rotation_cash_trigger_pct", 0.05) or 0.0)
        cash_low = eq > 0 and (self.portfolio.cash / eq) < cash_floor

        if not fresh:
            if cash_low:
                self._journal_once_a_day("ROTATION_NOTHING_TO_FUND", now, {
                    "cash_pct": round(self.portfolio.cash / eq * 100, 2),
                    "why": (f"Cash is {self.portfolio.cash / eq * 100:.1f}% of "
                            f"the book, under the {cash_floor * 100:.0f}% "
                            f"rotation trigger, but this scan has no pick to "
                            f"buy — nothing is sold to fund a name the engine "
                            f"is not buying (audit F-7, 2026-10-02)."),
                })
            return []
        tickets = {pk["ticker"]: _ticket(pk) for pk in fresh}
        need = sum(tickets.values())
        shortfall = need - spendable

        # OWNER ORDER 2026-10-04 (category cash budgets): each pass is one
        # category, and its share is that category's cash. When the SHARE is
        # what runs short, only selling a holding of the SAME category frees
        # it — selling another category's holding frees cash this pick still
        # cannot spend, shrinking the book for nothing (the S-4 rule). A share
        # is counted at ENTRY cost, so a sale frees the holding's cost from
        # the share (and its market value as cash). Ocean picks sit outside
        # the shares.
        from . import category_budget as cb
        cat = getattr(cfg, "mode", "") or MOMENTUM_MODE
        share_limit = cb.limit(cfg, cat, eq)
        budget_need = sum(tickets[pk["ticker"]] for pk in fresh
                          if not pk.get("ocean"))
        room_now = (share_limit - cb.used(held.values(), cat)
                    if share_limit is not None else None)
        same_category_only = (room_now is not None and budget_need > 0
                              and room_now < budget_need)
        # the smallest room can_open will open a trade into
        usable_room = max(cb.min_open(cfg),
                          float(getattr(cfg, "min_position_value", 0) or 0))

        if shortfall <= 0 and not cash_low and not same_category_only:
            return []
        if cash_low and shortfall <= 0 and not same_category_only:
            # Cash is under the floor but the waiting pick is affordable.
            # Free one ticket's worth so the book is not left with nothing to
            # act on tomorrow.
            shortfall = need if need > 0 else tickets[fresh[0]["ticker"]]
            self._journal_once_a_day("ROTATION_CASH_TRIGGER", now, {
                "cash": round(self.portfolio.cash, 2),
                "cash_pct": round(self.portfolio.cash / eq * 100, 2),
                "floor_pct": round(cash_floor * 100, 2),
                "why": (f"Cash is {self.portfolio.cash / eq * 100:.1f}% of the "
                        f"book, under the {cash_floor * 100:.0f}% floor — "
                        f"owner's rotation trigger (2026-09-10)."),
            })

        candidates = [t for t, p in held.items()
                      if "owner_pick" not in (getattr(p, "tags", None) or [])
                      and (not same_category_only
                           or cb.category_of(p) == cat)]
        if not candidates:
            if same_category_only:
                self._journal_once_a_day("ROTATION_BUDGET_FULL", now, {
                    "category": cat,
                    "picks": [pk["ticker"] for pk in fresh][:20],
                    "why": (f"{cb.LABELS.get(cat, cat)} has spent its cash "
                            f"share and holds no position rotation may sell "
                            f"(owner picks are exempt); selling another "
                            f"category's holding could not buy these picks "
                            f"(owner order 2026-10-04)."),
                })
            return []
        try:
            live = routed_fetch_quotes(candidates, upstox_client=self.broker)
            live = qe.select(live, lambda t, px: qe.executable(live, t, datetime.utcnow()))
        except Exception as e:
            log.warning("rotation: live quotes unavailable: %s", e)
            live = {}
        unquoted = sorted(t for t in candidates
                          if not live.get(t) or float(live.get(t) or 0) <= 0)
        if unquoted:
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "ROTATION_HELD_NO_QUOTE",
                "tickers": unquoted,
                "why": (f"Rotation could not assess {', '.join(unquoted)}: no "
                        f"live quote, so no invented fill. Cash short by "
                        f"₹{shortfall:,.0f} for {len(fresh)} fresh pick(s)."),
            })

        from .rotation import rotation_suggestions
        min_prog = float(getattr(cfg, "rotation_min_progress", 0.90) or 0.90)
        suggestions = rotation_suggestions(
            {t: held[t] for t in candidates}, live, fresh, cfg,
            min_progress=min_prog)

        if same_category_only and suggestions:
            # Selling only helps if it can make room for at least one trade.
            # Over-full by more than every near-target holding's cost = no
            # sale at all (never shrink the book for a pick that still won't
            # buy — the S-4 rule).
            reachable = room_now + sum(
                float(held[sg["ticker"]].qty) * float(held[sg["ticker"]].entry_price)
                for sg in suggestions if sg["ticker"] in held)
            if reachable < usable_room:
                self._journal_once_a_day("ROTATION_BUDGET_FULL", now, {
                    "category": cat,
                    "picks": [pk["ticker"] for pk in fresh][:20],
                    "share_room": round(room_now, 0),
                    "why": (f"{cb.LABELS.get(cat, cat)} is past its cash "
                            f"share by more than its near-target holdings "
                            f"would free, so no rotation could buy these "
                            f"picks — nothing sold (owner order 2026-10-04)."),
                })
                return []

        rotated: list = []
        freed = 0.0
        freed_share = 0.0
        for s in suggestions:
            if not ir.entry_allowed(cfg.mode, datetime.utcnow()):
                break
            cash_ok = freed >= shortfall
            share_ok = (not same_category_only
                        or room_now + freed_share >= budget_need)
            if cash_ok and share_ok:
                break
            t = s["ticker"]
            px = float(live.get(t) or 0)
            if px <= 0 or t not in held:
                continue
            value = float(held[t].qty) * px
            if not qe.executable(live, t, datetime.utcnow()):
                continue
            freed_share += float(held[t].qty) * float(held[t].entry_price)
            decision = de.exit_decision(held[t], live, now)
            de.put(decision, "rotation", {"progress_pct": s["progress_pct"], "target": s["target"],
                   "shortfall": shortfall, "fund_ticker": s.get("fund_ticker"), "category_room": room_now},
                   {"min_progress": min_prog, "cash_trigger": cash_floor}, passed=True, role="exit_trigger")
            with de.capture(decision):
                self._close(t, px, "ROTATION_EXIT", now)
            freed += value
            rotated.append(t)
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "ROTATION_EXIT", "ticker": t,
                "price": round(px, 2), "progress_pct": s["progress_pct"],
                "target": s["target"], "freed": round(value, 2),
                "fund_ticker": s.get("fund_ticker"),
                "fund_score": s.get("fund_score"),
                "short_of": ("category_share" if same_category_only
                             else "cash"),
                "why": (f"Rotated out {t} at ₹{px:,.2f} — {s['progress_pct']}% "
                        f"of the way to its ₹{s['target']:,.2f} target — to "
                        f"free ₹{value:,.0f} for {s.get('fund_ticker') or 'a fresh pick'}"
                        f" (score {s.get('fund_score')}). "
                        + (f"Its category cash share had ₹{max(room_now, 0):,.0f} "
                           f"of the ₹{budget_need:,.0f} it needs"
                           if same_category_only else
                           f"Cash was short by ₹{shortfall:,.0f}")
                        + f"; ₹{freed:,.0f} freed so far. "
                        f"Owner order 2026-09-04 — the suggester executes."),
                "cash_after": round(self.portfolio.cash, 2),
            })
        return rotated

    @staticmethod
    def _guard_delayed_exit(ticker: str, raw_price: float) -> None:
        """Last booking boundary for evidence-bearing delayed price exits."""
        decision = de.current() or {}
        quote = decision.get("quote") or {}
        if quote.get("source") == "upstox_1min_delayed":
            batch = qe.QuoteBatch({ticker: raw_price}, evidence={ticker: quote})
            if not qe.executable(batch, ticker, datetime.utcnow()):
                raise ValueError("intraday_quote_expired_before_exit")

    def _exit_half(self, ticker: str, raw_price: float, reason: str,
                   now: datetime) -> None:
        """Sell half the position at the live price (full close if qty==1).
        Same slippage/cost model as _close; the sold half becomes a real
        ClosedTrade — nothing vanishes from the record."""
        self._guard_delayed_exit(ticker, raw_price)
        pos = self.portfolio.positions[ticker]
        if pos.mode == "intraday" and not ir.in_session(datetime.utcnow()):
            raise ValueError("intraday_market_closed")
        if pos.qty <= 1:
            self._close(ticker, raw_price, reason, now)
            return
        half = pos.qty // 2
        exit_price = slippage_price(raw_price, "SELL", self.cfg)
        gross = (exit_price - pos.entry_price) * half
        cost_ev, cost_basis, dp_change = fees.prepare_exit(self.portfolio, pos, half, exit_price, now, self.cfg)
        costs = cost_ev["total"]
        self.portfolio.cash += cost_ev["cash_credit"]
        fees.commit_exit_state(self.portfolio, pos, cost_basis, dp_change)
        trade_ev = de.exit_snapshot(pos, raw_price, exit_price, half, reason, now, self.cfg)
        try:
            from .validation import identity
            trade_ev["exit"]["validation_run"] = identity(self._exit_cfg(pos, self.cfg))
        except Exception as exc:
            trade_ev["exit"]["validation_error"] = type(exc).__name__
        trade_ev["exit"]["accounting"] = {"gross_pnl": gross, "costs": costs, "net_pnl": gross-costs, "method": cost_ev["model"], "charge_evidence": copy.deepcopy(cost_ev)}
        self.portfolio.trades.append(ClosedTrade(
            ticker=ticker, qty=half, trade_evidence=trade_ev, cost_evidence=copy.deepcopy(cost_ev),
            entry_date=pos.entry_date, exit_date=now,
            entry_price=pos.entry_price, exit_price=exit_price,
            gross_pnl=gross, costs=costs, net_pnl=gross - costs,
            reason=reason, sector=pos.sector,
            entry_score=pos.entry_score, reasoning=pos.reasoning,
            entry_notes=getattr(pos, "entry_notes", "") or "",
            tags=list(getattr(pos, "tags", []) or []),
            mode=getattr(pos, "mode", "") or "",
            ca_applied=list(getattr(pos, "ca_applied", []) or []),
        ))
        self.portfolio.decision_journal.append({"ts": now.isoformat(), "action": "SELL_PARTIAL",
            "ticker": ticker, "qty": half, "trade_id": trade_ev["trade_id"], "decision_id": trade_ev["exit"]["id"],
            "evidence": copy.deepcopy(trade_ev["exit"]), "exit_reason": reason})
        pos.qty -= half

    def _close(self, ticker: str, raw_price: float, reason: str, now: datetime) -> None:
        self._guard_delayed_exit(ticker, raw_price)
        if (getattr(self.portfolio.positions[ticker], "mode", "") == "intraday"
                and not ir.in_session(datetime.utcnow())):
            raise ValueError("intraday_market_closed")
        pos = self.portfolio.positions[ticker]
        close_evidence = copy.deepcopy(getattr(pos, "intraday_close", {}) or {})
        if close_evidence:
            close_evidence.update(status="closed", closed_at=ir.utc(now).isoformat(),
                                  exit_reason=reason)
        exit_price = slippage_price(raw_price, "SELL", self.cfg)
        gross = (exit_price - pos.entry_price) * pos.qty
        cost_ev, cost_basis, dp_change = fees.prepare_exit(self.portfolio, pos, pos.qty, exit_price, now, self.cfg)
        costs = cost_ev["total"]
        self.portfolio.positions.pop(ticker)
        self.portfolio.cash += cost_ev["cash_credit"]
        fees.commit_exit_state(self.portfolio, pos, cost_basis, dp_change)
        net_pnl = gross - costs
        trade_ev = de.exit_snapshot(pos, raw_price, exit_price, pos.qty, reason, now, self.cfg)
        try:
            from .validation import identity
            trade_ev["exit"]["validation_run"] = identity(self._exit_cfg(pos, self.cfg))
        except Exception as exc:
            trade_ev["exit"]["validation_error"] = type(exc).__name__
        trade_ev["exit"]["accounting"] = {"gross_pnl": gross, "costs": costs, "net_pnl": net_pnl, "method": cost_ev["model"], "charge_evidence": copy.deepcopy(cost_ev)}
        self.portfolio.trades.append(ClosedTrade(
            ticker=ticker, qty=pos.qty, trade_evidence=trade_ev, cost_evidence=copy.deepcopy(cost_ev),
            entry_date=pos.entry_date, exit_date=now,
            entry_price=pos.entry_price, exit_price=exit_price,
            gross_pnl=gross, costs=costs, net_pnl=net_pnl,
            reason=reason, sector=pos.sector,
            entry_score=pos.entry_score, reasoning=pos.reasoning,
            entry_notes=getattr(pos, "entry_notes", "") or "",
            tags=list(getattr(pos, "tags", []) or []),
            mode=getattr(pos, "mode", "") or "",
            ca_applied=list(getattr(pos, "ca_applied", []) or []),
            intraday_close=close_evidence,
        ))
        # WHY-SOLD journal entry — full exit context, never deleted
        hold_days = (now.date() - pos.entry_date.date()).days
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(),
            "action": "SELL",
            "trade_id": trade_ev["trade_id"],
            "decision_id": trade_ev["exit"]["id"],
            "evidence": copy.deepcopy(trade_ev["exit"]),
            "ticker": ticker,
            "qty": pos.qty,
            "entry_price": round(pos.entry_price, 2),
            "exit_price": round(exit_price, 2),
            "net_pnl": round(net_pnl, 2),
            "net_pct": round((exit_price / pos.entry_price - 1) * 100, 2) if pos.entry_price else 0,
            "hold_days": hold_days,
            "exit_reason": reason,
            "intraday_close": close_evidence,
            "peak_price": round(pos.peak_price, 2),
            "gave_back_from_peak_pct": round((exit_price / pos.peak_price - 1) * 100, 2) if pos.peak_price else 0,
            "regime": self.portfolio.last_regime,
            "why_bought_was": pos.reasoning,
            "entry_notes": getattr(pos, "entry_notes", "") or "",
            "cash_after": round(self.portfolio.cash, 2),
        })
        # v5: feed the consecutive-loss tracker. Owner order 2026-10-21:
        # with the closed position's category, so the halt can be judged
        # per category.
        try:
            from . import category_budget as _cb
            self.loss_tracker.record_close(now.date(), net_pnl, reason=reason,
                                           category=_cb.category_of(pos))
            # AUDIT FIX C11: persist so a restart can't forget the halt
            self.portfolio.loss_day = (self.loss_tracker.today.isoformat()
                                       if self.loss_tracker.today else None)
            self.portfolio.loss_count = int(self.loss_tracker.losses_today)
            self.portfolio.loss_by_category = dict(self.loss_tracker.by_category)
        except AttributeError:
            pass  # backward compat if engine was built before risk_v2

    def _breadth_gate_blocks(self, history: dict, now: datetime,
                             n_picks: int = 0, bypass: bool = False) -> bool:
        """A3 breadth gate (owner-ordered wire 2026-07-27; RE-CUT 2026-09-09).

        Blocks new momentum entries while breadth sits in the measured DEAD
        BAND (cfg.breadth_block_low..high, 40-65%). It is not a "weak market"
        gate any more: measured on the engine's own picks, a washed-out tape
        (< 40% above their 200DMA) was one of the BEST states to buy, and the
        old "block at <= 50%" rule blocked the better days on the fitted half
        and was worth +0.02pp on the holdout, i.e. nothing. See the ENTRY
        BREADTH BAND note in config.py for the numbers and the holdout.

        Exits are never touched. Fail-open on thin samples or errors, so a data
        hiccup can never freeze buying by accident.

        EVERY MODE, not just momentum (owner order 2026-09-16, after reporting
        "how all positions got exit / no new position are getting added").

        WHY IT HAD TO CHANGE. The gate used to return False for any mode but
        nifty200_momentum, and the 09:20 job runs five passes. So in the dead
        band the ONE pass that holds for 200 days was blocked while swing
        (floor 60 — LOWER than momentum's 62), short and intraday kept buying.
        Intraday positions are force-closed at 15:25 the same day BY DESIGN and
        swing sells at 20 days, so the book filled with names that could not
        stay and emptied again. The owner saw positions leaving and nothing
        arriving; that asymmetry is what they were looking at.

        HONEST LIMIT, because it matters: the breadth study measured MOMENTUM
        picks only. Applying the same 40-65% band to swing/short/positional/
        intraday is the owner's reasoned order, not a measured result — if the
        tape is too weak to buy a 200-day hold it is too weak to buy a 20-day
        one. Nothing re-measures it; say so if asked.

        THE READING IS ONE NUMBER PER DAY, NOT ONE PER MODE. Only momentum
        pulls 2y of history; the other four pull 6mo, and compute_breadth drops
        every ticker with fewer than 200 bars — so their own bucket read is
        (None, 0) and, alone, this gate would have stayed a no-op for exactly
        the passes it now has to cover. Momentum runs FIRST in the rotation, so
        whichever pass can compute the reading caches it on
        portfolio.breadth_today and the rest read that. Market breadth is a
        property of the market, not of the pass looking at it.
        """
        cfg = self.cfg
        # Owner decision 2026-07-27 ("yes — we cant wait for recovery, that
        # is movement of entries"): when the VIX-crush re-entry fires, its
        # entries BYPASS the breadth gate. At the exact turn of a crash,
        # breadth is always still <=50% — stacking the two gates would have
        # blocked the v4-tested +24% COVID rebound entirely. Breadth still
        # guards every normal bull/neutral day.
        if bypass:
            de.record("breadth", state="skipped", reason="Approved VIX-crush bypass")
            return False
        if not getattr(cfg, "breadth_gate_enabled", False):
            de.record("breadth", state="skipped", reason="Owner switch off")
            return False
        try:
            # F3 FIX (owner order 2026-08-20: "fix F3"): PREFER the stored
            # reading (computed by scheduler.refresh_breadth_store from one
            # streamed Mongo query) over the scan's own reading. The stored
            # reading is trusted only while its closes are fresh
            # (cfg.breadth_store_max_age_days).
            # 2026-10-16 ("new position are not added ... relook n fix"):
            # both readings are now taken over the 191-name STUDY PANEL the
            # 40-65% band was measured on (breadth.gate_breadth) — the
            # whole store sat 5-7pp away from the panel and the gate held
            # all five categories back on a number its evidence never
            # measured.
            from .breadth import is_fresh, population_label
            breadth = sample = None
            source = ""
            stored = getattr(self.portfolio, "breadth_store", None) or {}
            # 2026-10-16: a stored reading without a `population` was taken
            # over the whole store — a number the band was never measured on
            # — so it is not used; the scan's own study-panel reading is.
            if (stored.get("population")
                    and is_fresh(stored, now.date(),
                                 getattr(cfg, "breadth_store_max_age_days",
                                         10))):
                breadth = float(stored["pct"])
                sample = int(stored["sample"])
                source = (f"{population_label(stored)}, closes to "
                          f"{stored.get('asof')}")
            else:
                breadth, sample = self._cache_breadth_today(history, now)
                if breadth is not None and sample > 0:
                    source = population_label(
                        getattr(self.portfolio, "breadth_today", None))
                else:
                    # This pass's own history is too short (every mode but
                    # momentum pulls 6mo). Reuse today's reading rather than
                    # failing open and letting the short-horizon passes buy
                    # into a tape momentum was just blocked from.
                    cached = getattr(self.portfolio, "breadth_today", None) or {}
                    # 2026-10-16: a reading with no `population` was taken
                    # over the whole scan list before the fix — the
                    # population the band was never measured on, set aside
                    # here exactly as the stored one is above.
                    if (cached.get("population")
                            and cached.get("asof") == now.date().isoformat()):
                        breadth = float(cached.get("pct"))
                        sample = int(cached.get("sample") or 0)
                        source = (f"today's {cached.get('mode') or 'scan'} "
                                  f"reading, {population_label(cached)} — "
                                  f"this pass holds only 6mo of history, too "
                                  f"short for a 200DMA")
            lo = float(getattr(cfg, "breadth_block_low", 0.40))
            hi = float(getattr(cfg, "breadth_block_high", 0.65))
            known = breadth is not None and sample >= getattr(cfg, "breadth_min_sample", 30)
            de.record("breadth", {"fraction": breadth, "sample": sample, "source": source},
                      {"block_from": lo, "block_below": hi, "min_sample": getattr(cfg, "breadth_min_sample", 30)},
                      state=None if known else "unavailable", passed=not (known and lo <= breadth < hi),
                      reason="Insufficient input retains existing fail-open policy" if not known else "")
            if (breadth is not None
                    and sample >= getattr(cfg, "breadth_min_sample", 30)
                    and lo <= breadth < hi):
                self.portfolio.decision_journal.append({
                    "ts": now.isoformat(), "action": "BREADTH_BLOCKED",
                    "mode": getattr(cfg, "mode", ""),
                    "why": (f"Breadth gate [{getattr(cfg, 'mode', '?')}]: "
                            f"{breadth*100:.1f}% above their "
                            f"200DMA sits in the measured dead band "
                            f"{lo*100:.0f}-{hi*100:.0f}% — {source}. "
                            f"{n_picks} pick(s) held back; exits unaffected. "
                            f"(Below {lo*100:.0f}% the tape is washed out and "
                            f"entries are ALLOWED — re-cut 2026-09-09.)"),
                })
                return True
        except Exception as e:
            de.record("breadth", state="unavailable", reason=f"{type(e).__name__}; existing fail-open policy")
            log.warning("breadth gate failed (fail-open): %s", e)
        return False

    def _cache_breadth_today(self, history: dict, now: datetime):
        """Compute the scan bucket's breadth and cache it on
        portfolio.breadth_today for the passes that cannot see a 200DMA (they
        pull only 6mo). Written only on a real reading — a miss must never
        overwrite a good one. Returns (pct, sample) or (None, 0).

        AUDIT S-8 (2026-10-02): this used to happen only INSIDE the gate, and
        the gate is consulted only when the momentum pass has picks. On a day
        momentum picked nothing, no reading was cached, so the swing, short,
        positional and intraday passes read no breadth at all and fell open —
        buying into a tape the band would have blocked."""
        from .regime import compute_breadth
        from .breadth import PANEL_MIN_SAMPLE, study_panel
        try:
            from .universes import fund_unit_tickers
            funds = fund_unit_tickers()
        except Exception:
            funds = frozenset()
        # 2026-10-16: the gate's band was measured on the study panel's
        # breadth (breadth.gate_breadth explains), so the scan's own reading
        # is taken over the panel names it holds; only when too few of them
        # have a 200-DMA does it fall back to the whole scan — and a held
        # fund unit, riding in the scan for its exits, never votes.
        panel = study_panel()
        population = "scan_panel"
        breadth, sample = compute_breadth(
            {t: h for t, h in history.items() if t in panel})
        if breadth is None or sample < PANEL_MIN_SAMPLE:
            population = "scan"
            breadth, sample = compute_breadth(
                {t: h for t, h in history.items() if t not in funds})
        if breadth is not None and sample > 0:
            self.portfolio.breadth_today = {
                "pct": float(breadth), "sample": int(sample),
                "asof": now.date().isoformat(),
                "mode": getattr(self.cfg, "mode", ""),
                "population": population,
                "ts": now.isoformat(),
            }
            return breadth, sample
        return None, 0

    def _ocean_journal_once(self, now: datetime, action: str, why: str) -> None:
        today_iso = now.date().isoformat()
        if not any(e.get("action") == action
                   and str(e.get("ts", "")).startswith(today_iso)
                   for e in self.portfolio.decision_journal[-60:]):
            self.portfolio.decision_journal.append(
                {"ts": now.isoformat(), "action": action, "why": why})

    # --- market-hours gate (owner order 2026-09-10) -----------------------
    #: IST is UTC+5:30. See _ist() — this is the whole of the 2026-09-16 fault.
    _IST_OFFSET = timedelta(hours=5, minutes=30)

    def _ist(self, now: Optional[datetime]) -> Optional[datetime]:
        """Convert the engine's `now` to IST before asking the calendar.

        THE 2026-09-16 FAULT, and it inverted the owner's own order. Every
        `now` inside this engine is `datetime.utcnow()` — NAIVE UTC. But
        `calendars._ist_now` documents a naive datetime as "assumed already
        IST" and passes it straight through, so the whole 09:15-15:30 session
        was read 5h30m late. Measured:

            real 09:20 IST (the daily scan) -> engine passed 03:50 -> CLOSED
            real 09:15-14:45 IST            -> CLOSED
            real 14:45-15:30 IST            -> OPEN
            real 15:35 IST (the EOD pass)   -> OPEN
            real 21:00 IST                  -> OPEN

        So since 2026-09-10 the 09:20 scan believed the market was shut and
        bought NOTHING, every exit due in the morning was deferred with
        EXIT_DUE_MARKET_CLOSED and they all fired together in the last 45
        minutes, and the post-close passes traded freely — the exact opposite
        of "trade are prohibited after market hours". That is what the owner
        reported as "how all positons got exist / no new position are getting
        added".

        The fix lives HERE, not in calendars: `is_market_open()` with no
        argument is correct (real IST clock) and its naive-means-IST contract
        is pinned by tests, so moving the conversion there would break every
        honest caller. Every naive `now` reaching this engine is UTC.
        """
        if now is None or now.tzinfo is not None:
            return now
        return now + self._IST_OFFSET

    def _market_state(self, now: Optional[datetime] = None) -> str:
        """market_state() on the engine's clock — see _ist(). A journal line
        that names the wrong session is the lying-screen class."""
        return market_state(self._ist(now))

    def _trading_allowed(self, now: Optional[datetime] = None) -> bool:
        """Can a position be opened or closed RIGHT NOW?

        One predicate, one place. `cfg.market_hours_only` exists so tests and
        backtests (which replay closed days by definition) are not gated, and
        so the owner can switch the rule off from Settings if they ever want
        the old behaviour back — but it defaults ON per their order.
        """
        if not bool(getattr(self.cfg, "market_hours_only", True)):
            return True
        return is_market_open(self._ist(now))

    def _measured_kelly(self, now: datetime):
        """The measured-Kelly reading for this scan, or None when switched off.

        AUDIT F-9 (owner: "F9- write it", 2026-10-02). Reads the closed trades
        held in the book (the newest TRADES_DOC_CAP; older ones are archived
        in Mongo, which trading/ never imports). A crash in the estimator
        reads as None — the check can only cut or stop buying, so a broken
        check must not stop buying on its own. A block is journaled once a
        day with the numbers that caused it.
        """
        cfg = self.cfg
        if not bool(getattr(cfg, "measured_kelly_enabled", False)):
            return None
        # OWNER ORDER 2026-10-05 ("make it momentum only"): the check runs
        # only in a listed category's pass and reads only that category's
        # closed trades. Any other pass = no reading, no block, no cap.
        modes = tuple(getattr(cfg, "measured_kelly_modes", ()) or ())
        category = None
        if modes:
            if str(getattr(cfg, "mode", "") or "") not in modes:
                return None
            category = str(cfg.mode)
        try:
            from .measured_kelly import live_clip_pct, measure
            r = measure(
                self.portfolio.trades,
                fraction=float(getattr(cfg, "kelly_fraction", 0.29) or 0.29),
                min_trades=int(getattr(cfg, "measured_kelly_min_trades", 0) or 0),
                full_confidence=int(getattr(
                    cfg, "measured_kelly_full_confidence", 300) or 300),
                clip_pct=live_clip_pct(), category=category)
        except Exception as e:
            log.exception("measured Kelly failed — check skipped: %s", e)
            return None
        if r.block_new_entries:
            self._journal_once_a_day("MEASURED_KELLY_BLOCKED", now, {
                "category": r.category, "other_category": r.other_category,
                "usable": r.usable, "excluded": r.excluded,
                "win_rate": r.raw_win_rate, "payoff": r.payoff_ratio,
                "kelly": r.raw_kelly, "why": r.note})
        return r

    @staticmethod
    def _measured_kelly_cap(mk, cfg, equity: float):
        """Rupee ceiling per new entry, or None when the check does not cap.

        The cap is fraction x equity, never below the slab: the owner's
        Rs 1.5 lakh is a stated MINIMUM ("150000 slab as minimum"), so the
        measured cap trims the score ladder above it and never opens a trade
        smaller than the slab. Under fixed sizing the floor is the dust guard
        (min_position_value) instead.
        """
        if mk is None or mk.status != "ACTIVE" or not mk.fraction:
            return None
        cap = float(mk.fraction) * float(equity)
        if str(getattr(cfg, "sizing_mode", "")) == "slab":
            floor = float(getattr(cfg, "position_slab_value", 0) or 0)
        else:
            floor = float(getattr(cfg, "min_position_value", 0) or 0)
        return max(cap, floor)

    def _journal_budget_full(self, skipped: list, now: datetime) -> None:
        """One CATEGORY_BUDGET_FULL line per category per day when this pass
        refused picks because its share was spent (owner order 2026-10-04).
        A refusal the owner cannot see is the lying-screen class."""
        names = [s["ticker"] for s in skipped
                 if s.get("reason") == "category_budget_full"]
        if not names:
            return
        cfg = self.cfg
        cat = getattr(cfg, "mode", "") or MOMENTUM_MODE
        today_iso = now.date().isoformat()
        if any(e.get("action") == "CATEGORY_BUDGET_FULL"
               and e.get("category") == cat
               and str(e.get("ts", "")).startswith(today_iso)
               for e in self.portfolio.decision_journal[-60:]):
            return
        from . import category_budget as cb
        positions = self.portfolio.positions
        base = self.portfolio.cash + sum(
            float(p.qty) * float(p.entry_price) for p in positions.values())
        lim = cb.limit(cfg, cat, base) or 0.0
        spent = cb.used(positions.values(), cat)
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(), "action": "CATEGORY_BUDGET_FULL",
            "category": cat,
            "share": cb.share(cfg, cat),
            "limit": round(lim, 0), "used": round(spent, 0),
            "refused": names[:20], "refused_count": len(names),
            "why": (f"{cb.LABELS.get(cat, cat)} has spent its "
                    f"{(cb.share(cfg, cat) or 0) * 100:.0f}% share "
                    f"(Rs {spent:,.0f} of Rs {lim:,.0f}); {len(names)} pick(s) "
                    f"waited. The other categories keep their own shares — "
                    f"owner order 2026-10-04."),
        })

    # ------------------------------------------------- loss halt per category
    # Owner order 2026-10-21 ("Halt only the category that lost").
    @staticmethod
    def _loss_halt_scope(cfg) -> str:
        s = str(getattr(cfg, "loss_halt_scope", "category") or "category")
        return s if s in ("category", "book") else "category"

    @staticmethod
    def _loss_halt_category(pick: dict, cfg) -> str:
        if pick.get("ocean"):
            return "ocean"
        return getattr(cfg, "mode", "") or MOMENTUM_MODE

    def _open_in_category(self, category: str) -> int:
        from . import category_budget as cb
        return sum(1 for p in self.portfolio.positions.values()
                   if cb.category_of(p) == category)

    def _open_by_category(self) -> dict:
        from . import category_budget as cb
        out: dict = {}
        for p in self.portfolio.positions.values():
            c = cb.category_of(p)
            out[c] = out.get(c, 0) + 1
        return out

    def _journal_loss_halt(self, skipped: list, now: datetime) -> None:
        """One CONSECUTIVE_LOSS_HALT line per category per day when this
        pass refused picks on the loss halt, carrying the category and the
        per-category counts (owner order 2026-10-21)."""
        refused = [s for s in skipped
                   if s.get("reason") == "consecutive_loss_halt"]
        if not refused:
            return
        cfg = self.cfg
        scope = self._loss_halt_scope(cfg)
        by_cat: dict = {}
        for s in refused:
            by_cat.setdefault(s.get("category") or (getattr(cfg, "mode", "")
                                                    or MOMENTUM_MODE),
                              []).append(s["ticker"])
        today_iso = now.date().isoformat()
        # Today's lines already written, by category. Walk back through
        # TODAY's entries only (the journal is in time order): a fixed
        # last-60 window let a second line through on a busy day.
        written: set = set()
        for e in reversed(self.portfolio.decision_journal):
            ts = str(e.get("ts", ""))[:10]
            if ts and ts < today_iso:
                break
            if e.get("action") == "CONSECUTIVE_LOSS_HALT" and ts == today_iso:
                written.add(e.get("category"))
        from . import category_budget as cb
        for cat, names in by_cat.items():
            if cat in written:
                continue
            t = self.loss_tracker
            n_open = self._open_in_category(cat)
            lim = (t.category_limit(cat, n_open) if scope == "category"
                   else t.limit())
            lost = t.losses_in(cat) if scope == "category" else t.losses_today
            label = cb.LABELS.get(cat, cat.replace("_", " "))
            uncat = t.uncategorised()
            # the pre-order record: today's losers carry no category, so the
            # whole-book rule held this category (risk_v2 halted())
            legacy = scope == "category" and lost < lim and uncat > 0
            if legacy:
                why = (f"{uncat} of today's {t.losses_today} losing strategy "
                       f"exit(s) were recorded before per-category counting "
                       f"began, so the whole-book limit of {t.limit()} stands "
                       f"for the rest of today; {len(names)} "
                       f"{label.lower()} pick(s) waited.")
            elif scope == "category":
                why = (f"{label} lost {lost} strategy exit(s) today, at or "
                       f"past its limit of {lim} (max(2, 10% of its {n_open} "
                       f"open + {lost} lost)); {len(names)} {label.lower()} "
                       f"pick(s) waited. The other categories keep buying "
                       f"— owner order 2026-10-21 ('Halt only the category "
                       f"that lost').")
            else:
                why = (f"The book lost {lost} strategy exit(s) today, at or "
                       f"past the book-wide limit of {lim}; {len(names)} "
                       f"pick(s) waited (Loss halt scope = book).")
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "CONSECUTIVE_LOSS_HALT",
                "category": cat, "scope": scope,
                "losses": lost, "max_allowed": lim, "open_in_category": n_open,
                "by_category": dict(t.by_category),
                "uncategorised": uncat,
                "refused": names[:20], "refused_count": len(names),
                "why": why,
            })

    def _journal_once_a_day(self, action: str, now: datetime,
                            fields: dict) -> None:
        """Append `action` at most once per calendar day.

        The window is the last 60 entries, the same bound _ocean_journal_once
        uses. NOTE for future tests: a repeated same-day run against a
        persistent state dir will therefore SKIP the second append — count
        only your own test's appends, never a tail slice of the journal (the
        2026-08-24 fault class).
        """
        today_iso = now.date().isoformat()
        if any(e.get("action") == action
               and str(e.get("ts", "")).startswith(today_iso)
               for e in self.portfolio.decision_journal[-60:]):
            return
        entry = {"ts": now.isoformat(), "action": action}
        entry.update(fields)
        self.portfolio.decision_journal.append(entry)

    def _ocean_picks(self, regime, history: dict, universe, now: datetime) -> List[dict]:
        """Ocean dip candidates behind the owner-approved crash guard
        (2026-08-26: "Approve as specced", max 8
        slots, four rails). Runs in PARALLEL with Everest in every regime
        — the market works both ways (owner's words); Ocean's own
        selection (30% under the 200DMA, weekly RSI < 25, climax volume,
        fundamentals survival) makes candidates rare outside sell-offs.

        The 2026-07-27 park is superseded by the approval. What replaced
        the missing guard, all evidence-traced (engines/ocean.py):
        R1 VIX knife (v4's measured VIX-crush is the only tested dip
        entry), R2 the damage cluster on the canonical store judged against
        the panel's own 90th percentile (2026-10-04; was the fixed 0.213,
        ON 84% of days on our list), R3 per-stock reclaim (no fresh 20d low, close above prior
        high), R4 the 12 VERIFIED danger tripwires as a veto. Every block
        journals its rail; unknowable = blocked, never assumed safe.
        """
        cfg = self.cfg
        if not getattr(cfg, "ocean_enabled", False):
            return []
        catalog = {}
        accepted = set()
        try:
            from .engines.ocean import (crash_guard_market, crash_guard_stock,
                                        scan as ocean_scan)
            # Cap: at most ocean_max_positions concurrent Ocean holdings.
            max_slots = int(getattr(cfg, "ocean_max_positions", 8) or 8)
            open_ocean = sum(1 for p in self.portfolio.positions.values()
                             if "ocean" in (getattr(p, "tags", None) or []))
            free = max_slots - open_ocean
            if free <= 0:
                for t in universe:
                    catalog[t] = de.new(t, cfg.mode, "ocean", now, history.get(t))
                    de.put(catalog[t], "ocean_slots", open_ocean, max_slots, passed=False)
                return []
            hist_map = {t: history[t] for t in universe if t in history}
            with de.capture({"ocean_catalog": catalog, "at": now}):
                candidates = ocean_scan(hist_map, cfg)
            for c in candidates:
                catalog.setdefault(c.ticker, de.new(c.ticker, cfg.mode, "ocean", now, hist_map.get(c.ticker)))
                de.put(catalog[c.ticker], "ocean_slots", open_ocean, max_slots, passed=True)
            if not candidates:
                return []
            # Rails 1+2 — market level, once per scan.
            vix = None
            try:
                vixd = fetch_daily(["^INDIAVIX"], period="1y").get("^INDIAVIX")
                if vixd is not None and not vixd.empty:
                    vix = vixd["Close"]
            except Exception:
                pass
            market_trace = de.new("market", cfg.mode, "ocean", now)
            with de.capture(market_trace):
                ok_mkt, why_mkt = crash_guard_market(vix, self.portfolio.damage_store)
            for c in candidates:
                catalog[c.ticker]["gates"].update(copy.deepcopy(market_trace["gates"]))
                de.put(catalog[c.ticker], "ocean_market", why_mkt, "ok", passed=ok_mkt)
            if not ok_mkt:
                self._ocean_journal_once(
                    now, "OCEAN_BLOCKED",
                    f"{len(candidates)} Ocean candidate(s) but the market "
                    f"rail said no: {why_mkt}. A dip engine must prove the "
                    "fall is exhausted — it never assumes.")
                return []
            picks: List[dict] = []
            blocked: list[str] = []
            from . import danger
            for c in candidates[:free * 2]:      # bounded work per scan
                df = hist_map.get(c.ticker)
                try:
                    fired = danger.evaluate_stock(df)
                except Exception:
                    fired = ["danger_unverifiable"]
                with de.capture(catalog[c.ticker]):
                    ok_stk, why_stk = crash_guard_stock(df, fired)
                de.put(catalog[c.ticker], "ocean_stock", why_stk, "ok", passed=ok_stk)
                if not ok_stk:
                    blocked.append(f"{c.ticker}:{why_stk}")
                    continue
                accepted.add(c.ticker)
                picks.append({
                    "decision": catalog[c.ticker],
                    "ticker": c.ticker,
                    "score": 100 + c.pct_below_200dma,  # deepest first
                    "components": {},
                    "timing_pass": True,
                    "timing_diag": {"ocean": True},
                    "reasoning": (
                        f"OCEAN: {c.pct_below_200dma:.1f}% off 200DMA, "
                        f"weekly RSI {c.weekly_rsi:.1f}, "
                        f"climax vol {c.climax_volume_ratio:.1f}x; rails ok "
                        f"({why_mkt})"
                    ),
                    "last_close": c.price,
                    "ocean": True,
                })
                if len(picks) >= free:
                    break
            if blocked:
                self._ocean_journal_once(
                    now, "OCEAN_STOCK_BLOCKED",
                    "Ocean per-stock rails blocked: " + " · ".join(blocked))
            return picks
        except Exception:
            log.exception("ocean picks failed")
            return []   # Ocean is bonus; never block the Everest path
        finally:
            for ticker, trace in catalog.items():
                if ticker not in accepted:
                    failed = [k for k, g in trace["gates"].items() if g["state"] == "failed"]
                    missing = [k for k, g in trace["gates"].items() if g["state"] == "unavailable"]
                    de.journal_decision(self.portfolio, trace, "blocked" if failed else "unavailable" if missing else "not_selected",
                        failed[0] if failed else missing[0] if missing else "Ocean selection or per-scan work limit")

    def apply_corporate_actions(self, today=None, actions_for=None, now=None) -> list:
        """OWNER ORDER 2026-10-21 ("Yes — adjust held positions on the
        ex-date"), the BLSE lesson: a 10 → 5 split on a held name halved
        the quote, nothing adjusted the position, the −5% stop fired and a
        −49% loss was booked on a −1% move. Runs at the start of the 09:20
        job, the 14:30 rotation, the boot catch-up and the in-session exit
        pass (web/scheduler, which also re-fetches the name's history), AND
        at the top of refresh() and scan() themselves — so no exit check,
        kill switch or rotation sale can read an adjusted quote against an
        unadjusted entry, whichever path woke the process.

        For every held name with a split / consolidation / bonus whose
        ex-date is after the buy, on or before today and within the last
        LOOKBACK_SESSIONS sessions (the app sleeps), not yet in
        pos.ca_applied: qty × ratio (whole shares; the fractional remainder
        is credited to cash at the adjusted entry, cost-neutral), entry ÷
        ratio, stop / target / peak ÷ ratio, custom_levels kept. On the
        ex-date itself this waits for 09:15 IST (before the open the quote is
        yesterday's unadjusted last trade). Journals
        CORPORATE_ACTION_APPLIED once per action. NO sale, ever. Rights
        issues are reported (CORPORATE_ACTION_UNAPPLIED, once a day per
        name) and left alone — their price effect needs the issue price. A
        crash in one name never stops the others or the job; the book is
        saved when anything changed. One application at a time (a lock), so
        two threads can never both double one position. Returns the applied
        journal bodies; the tickers also land in CA_REFETCH_DUE for the
        scheduler's history re-fetch."""
        from . import corporate_actions as _ca
        now = now or datetime.utcnow()
        now_ist = now + timedelta(hours=5, minutes=30)
        today = today or _ca._ist_date(now)
        if isinstance(today, datetime):
            today = today.date()
        applied = []
        with _CA_LOCK:
            held = list(self.portfolio.positions.items())
            if not held:
                return []
            if actions_for is None:
                try:
                    batch = _ca.actions_for_many([t for t, _ in held])
                except Exception as e:              # noqa: BLE001
                    log.warning("corporate actions unreadable: %s", e)
                    return []
                lookup = lambda sym: batch.get(sym, [])  # noqa: E731
            else:
                lookup = actions_for
            sessions = None
            for ticker, pos in held:
                try:
                    acts = lookup(_ca.bare(ticker))
                except Exception as e:              # noqa: BLE001
                    log.warning("corporate actions unreadable for %s: %s", ticker, e)
                    continue
                if not acts:
                    continue
                try:
                    for ca in _ca.pending_for_position(pos, acts, today, now_ist=now_ist):
                        if _ca.ca_key(ca) in (pos.ca_applied or []):
                            continue                # belt and braces: never twice
                        if not _ca.leaves_whole_share(pos, ca):
                            # a qty-0 position would break every later pass;
                            # named for a hand settlement, once a day
                            self._journal_ca_unapplied(
                                ticker, ca, now,
                                f"{ca['subject']} would leave less than one whole share "
                                f"({pos.qty} × {ca['ratio']:g}) — not applied; settle the "
                                f"holding by hand (cash in lieu).")
                            continue
                        before = de.protection(pos)
                        body = _ca.apply_to_position(pos, ca)
                        de.amendment(pos, before, "CORPORATE_ACTION", now, portfolio=self.portfolio, details=body)
                        self.portfolio.cash += float(body["cash_credit"])
                        line = {"ts": now.isoformat(), "action": "CORPORATE_ACTION_APPLIED",
                                **body,
                                "why": (f"{ticker}: {ca['subject']} ex {ca['ex_date']} "
                                        f"(ratio {ca['ratio']:g}) — qty "
                                        f"{body['before']['qty']} → {body['after']['qty']}, "
                                        f"entry {body['before']['entry_price']:.2f} → "
                                        f"{body['after']['entry_price']:.2f}, stop/target/"
                                        f"peak ÷ {ca['ratio']:g}. Nothing sold; the exit pass "
                                        f"now compares like with like (owner order 2026-10-21)."),
                                "cash_after": round(self.portfolio.cash, 2)}
                        self.portfolio.decision_journal.append(line)
                        applied.append(line)
                        CA_REFETCH_DUE.add(ticker)
                    # a rights issue is named, never applied (issue price unknown)
                    entry_day = _ca._ist_date(pos.entry_date).isoformat()
                    for ca in acts:
                        if ca["kind"] != "rights":
                            continue
                        if not (entry_day < ca["ex_date"] <= today.isoformat()):
                            continue
                        if sessions is None:
                            sessions = set(_ca.recent_sessions(today))
                        if ca["ex_date"] not in sessions:
                            continue
                        self._journal_ca_unapplied(
                            ticker, ca, now,
                            "Rights issue on a held name — not applied: the price "
                            "effect depends on the issue price (DATA_NEEDED). Check "
                            "the position by hand.")
                except Exception as e:              # noqa: BLE001
                    log.exception("corporate action apply failed for %s: %s", ticker, e)
            if applied:
                try:
                    self.portfolio.save()
                except Exception:                   # noqa: BLE001
                    log.exception("save after corporate actions failed")
        return applied

    def _journal_ca_unapplied(self, ticker: str, ca: dict, now, why: str) -> None:
        """CORPORATE_ACTION_UNAPPLIED, at most once a day per name."""
        today_iso = now.date().isoformat()
        if any(e.get("action") == "CORPORATE_ACTION_UNAPPLIED"
               and e.get("ticker") == ticker
               and str(e.get("ts", "")).startswith(today_iso)
               for e in self.portfolio.decision_journal[-200:]):
            return
        self.portfolio.decision_journal.append({
            "ts": now.isoformat(), "action": "CORPORATE_ACTION_UNAPPLIED",
            "ticker": ticker, "subject": ca["subject"], "ex_date": ca["ex_date"],
            "why": why,
        })

    def _absorb_corporate_actions(self, where: str) -> None:
        """The ex-date adjuster as the first step of refresh() / scan().
        Never raises — a fault here must not cost the exit pass."""
        try:
            self.apply_corporate_actions()
        except Exception:                           # noqa: BLE001
            log.exception("corporate-action adjuster failed before %s", where)

    def _roll_risk_day(self, current_equity: float, now: datetime) -> None:
        """Re-baseline the daily loss halt once per trading day.

        RiskState.__post_init__ pins day_start_equity to starting_capital and
        RiskState.roll_day() was only ever called from backtest.py — so in the
        live app the "-2% daily loss halt" measured against the original
        forever. A -2% *cumulative* drawdown therefore tripped the kill switch
        and force-closed every position.

        The baseline for a new day is yesterday's last mark (the previous
        equity_history point), not today's — today's move is exactly what the
        halt is supposed to measure. Both the date and the baseline live on the
        portfolio so a mid-day restart restores them instead of starting over.
        """
        p = self.portfolio
        # `now` is UTC (refresh uses datetime.utcnow()). IST is UTC+5:30, so the
        # two dates only diverge between 00:00 and 05:30 IST — outside market
        # hours and outside every scheduled job (09:20 / 14:30 / 15:25 / 15:35
        # IST all land on the same UTC date). Safe as written.
        today = now.date().isoformat()

        if p.risk_day == today:
            # Same day, possibly after a restart: restore the stored baseline
            # AND the tripped flag — otherwise a mid-day restart on a halted
            # day would buy again at catch-up, re-trip at 15:35, and churn.
            if p.risk_day_equity > 0:
                self.risk.day_start_equity = p.risk_day_equity
            if getattr(p, "risk_day_killed", False):
                self.risk.kill_switch = True
            return

        prior_eq = None
        if p.equity_history:
            try:
                prior_eq = float(p.equity_history[-1][1])
            except (TypeError, ValueError, IndexError):
                prior_eq = None
        baseline = prior_eq if prior_eq and prior_eq > 0 else current_equity

        self.risk.roll_day(baseline)
        p.risk_day = today
        p.risk_day_equity = baseline
        p.risk_day_killed = False
        p.decision_journal.append({
            "ts": now.isoformat(), "action": "RISK_DAY_ROLL",
            "why": (f"Daily loss baseline set to Rs {baseline:,.0f} for {today}. "
                    f"Kill switch re-armed at "
                    f"{self.cfg.daily_loss_halt_pct * 100:.1f}% of that."),
        })

    def _exit_cfg(self, pos, cfg: Config) -> Config:
        """The exit rules of the trade category this position was BOUGHT
        under (owner order 2026-10-02, audit item 5).

        check_exit reads the trailing stop, the decay floor and the max-hold
        from the config it is handed. The exit pass used to hand it the LIVE
        config — the owner's mode, momentum — so a swing trade (20-day hold)
        or a short trade (63-day hold) was held up to momentum's 200 days
        under momentum's trail. Each position now gets a copy of the config
        with its own mode's preset applied (owner per-mode Settings edits
        included). A blank legacy mode is momentum, matching retag. The
        stop and target already come from the position itself."""
        mode = getattr(pos, "mode", "") or "nifty200_momentum"
        return self.mode_cfg(mode, cfg)

    def mode_cfg(self, mode: str, cfg: Optional[Config] = None) -> Config:
        """A config for one trade category, without touching the shared one.

        The given (default: live) config when it is already in that mode;
        otherwise a fresh shallow copy with the mode's preset applied (owner
        per-mode Settings edits included). apply_mode_preset only assigns
        scalar fields, so the shared config is never mutated, and nothing
        cached can outlive a Settings edit."""
        cfg = cfg if cfg is not None else self.cfg
        if mode == getattr(cfg, "mode", ""):
            return cfg
        import copy
        c = copy.copy(cfg)
        c.mode = mode
        c.apply_mode_preset()
        return c

    def _update_drawdown(self, prices: Dict[str, float], now: datetime,
                         *, cut_allowed: bool,
                         marks: Optional[Dict[str, float]] = None) -> List[str]:
        """Update the drawdown governor and, when allowed, run the ladder cut.

        Persisted peak (2026-07-31): the governor is rebuilt on every boot
        with peak 0, so the peak lives on the portfolio (JSON + Mongo). The
        SAVED value is the source of truth — it is the only place a capital
        change or a reset can move it, and the governor writes it straight
        back after every update, so the two only differ when one of those
        has just happened.

        OWNER ORDER 2026-10-02 ("fix 1 to 3") — three faults in the old code:
        1. The cut fired on EVERY refresh while the level held, so "cut half"
           halved the book, then halved the rest on the next 30-minute pass,
           and so on: a 40-name book was empty in 7 passes (~3.5 hours).
           Now each level cuts ONCE; `portfolio.dd_cut_level` records which
           level already cut (persisted, so a restart cannot cut again). A
           worse level cuts again; a recovery re-arms the ladder.
        2. An empty book in a halting drawdown could never recover — cash
           does not grow back to the old peak — so new entries stayed halted
           for good. When the book is empty and the level halts entries, the
           peak resets to today's equity (journaled DRAWDOWN_PEAK_RESET).
        3. A Starting-Capital change moved cash but not the peak, so it read
           as a drawdown (or a hidden cushion). paper.sync_capital now moves
           the peak by the same amount.
        Returns the tickers the cut closed."""
        from .risk_v2 import DRAWDOWN_LEVELS
        order = ["normal"] + [name for _, name, _, _ in DRAWDOWN_LEVELS]
        gov = self.drawdown_gov
        saved = float(getattr(self.portfolio, "dd_peak_equity", 0.0) or 0.0)
        if saved > 0:
            gov.peak_equity = saved
        # S-9: equity on the freshest marks; the cut below still ranks and
        # fills only on real quotes (`prices`).
        valuation_marks = marks if marks is not None else prices
        marks_ready = self._risk_marks_ready(valuation_marks, now)
        if marks_ready:
            gov.update(self.portfolio.equity(valuation_marks))

        level = gov.active_level if gov.active_level in order else "normal"
        done = getattr(self.portfolio, "dd_cut_level", "normal") or "normal"
        if done not in order:
            done = "normal"
        if marks_ready and order.index(level) < order.index(done):
            # Recovered to a milder level: a later re-escalation cuts again.
            done = level
            self.portfolio.dd_cut_level = level

        closed: List[str] = []
        p = self.portfolio
        pending = p.dd_cut_pending
        prior_pending = copy.deepcopy(pending)
        # A stop/owner exit can satisfy the reduction between refreshes.
        # Entry identity prevents a later holding of the same ticker from
        # inheriting the old obligation. No synthetic fill is recorded.
        if pending:
            for ticker, entry in list(pending["eligible"].items()):
                pos = p.positions.get(ticker)
                if pos is None or pos.entry_date.isoformat() != entry:
                    pending["eligible"].pop(ticker)
                    pending["remaining_count"] = max(0, pending["remaining_count"] - 1)

        cut = gov.forced_cut
        pending_level = pending["level"] if pending else done
        if (marks_ready and cut_allowed and cut > 0 and p.positions
                and order.index(level) > order.index(pending_level)):
            # Freeze the quota before any sale. A deeper level replaces the
            # older plan using today's remaining book, without weakening an
            # unfinished reduction. The original worst-priced-first rule
            # still applies only to names with usable live quotes.
            pending = {
                "level": level, "cut_fraction": cut,
                "started_at": now.isoformat(),
                "remaining_count": max(1, int(len(p.positions) * cut),
                                       pending.get("remaining_count", 0)),
                "eligible": {t: pos.entry_date.isoformat()
                             for t, pos in p.positions.items()},
            }
            p.dd_cut_pending = pending

        if pending and cut_allowed and pending["remaining_count"] > 0:
            priced = [t for t in pending["eligible"]
                      if prices.get(t) is not None
                      and math.isfinite(prices[t]) and prices[t] > 0]
            by_pnl = sorted(
                priced,
                key=lambda t: prices[t] / p.positions[t].entry_price,
            )
            for ticker in by_pnl[:pending["remaining_count"]]:
                if not qe.executable(prices, ticker, datetime.utcnow()):
                    continue
                decision = de.exit_decision(p.positions[ticker], prices, now)
                de.put(decision, "drawdown", {"snapshot": gov.snapshot(), "pending": copy.deepcopy(pending)},
                       DRAWDOWN_LEVELS, passed=True, role="exit_trigger")
                with de.capture(decision):
                    self._close(ticker, prices[ticker], "DRAWDOWN_LADDER", now)
                closed.append(ticker)
                pending["eligible"].pop(ticker)
                pending["remaining_count"] -= 1

        if pending:
            complete = pending["remaining_count"] == 0
            if closed or pending != prior_pending or complete:
                p.decision_journal.append({
                    "ts": now.isoformat(),
                    "action": "DRAWDOWN_LADDER_CUT" if closed else "DRAWDOWN_LADDER_PENDING",
                    "level": pending["level"], "cut_fraction": pending["cut_fraction"],
                    "closed": closed, "remaining_count": pending["remaining_count"],
                    "eligible": sorted(pending["eligible"]) if not complete else [],
                    "complete": complete,
                    "drawdown_pct": round(gov.snapshot()["drawdown_pct"], 2),
                    "why": ("The original cut is complete; this level will not cut again."
                            if complete else
                            "The original cut is unfinished; new entries remain halted "
                            "and eligible holdings are retried on later quote passes."),
                })
            if complete:
                p.dd_cut_level = pending["level"]
                p.dd_cut_pending = {}
            else:
                # A mark recovery must not allow new buys to replace an
                # unfinished protective reduction (scan calls this too).
                gov.halt_new_entries = True
                gov.sizing_multiplier = 0.0
                gov.reason += f"; drawdown cut pending: {pending['remaining_count']} exit(s)"

        if not self.portfolio.positions and gov.halt_new_entries:
            old_peak = gov.peak_equity
            eq = self.portfolio.equity(prices)
            gov.peak_equity = eq
            gov.update(eq)
            self.portfolio.dd_cut_level = "normal"
            self.portfolio.decision_journal.append({
                "ts": now.isoformat(), "action": "DRAWDOWN_PEAK_RESET",
                "old_peak": round(old_peak, 2), "new_peak": round(eq, 2),
                "why": ("The book is empty, so its equity is all cash and can "
                        "never climb back to the old peak — the entry halt "
                        "would have been permanent. Peak reset to today's "
                        "equity; the ladder measures from here."),
            })

        self.portfolio.dd_peak_equity = float(gov.peak_equity)
        return closed

    def _freshest_marks(self, live: Optional[Dict[str, float]],
                        history: Optional[dict],
                        fallback: Optional[Dict[str, float]] = None
                        ) -> Dict[str, float]:
        """AUD-002: persisted observations, with no entry-price regression.

        Quote receipt is labelled explicitly; the router does not yet provide
        an exchange timestamp. Carried marks never become executable quotes.
        """
        now = datetime.utcnow()
        live = qe.select(live, lambda t, px:
            qe.observation(live, t, now).get("source") != "upstox_1min_delayed"
            or qe.executable(live, t, now))
        return pm.collect(self.portfolio, live, history, fallback, now)

    def _risk_marks_ready(self, prices: Dict[str, float], now: datetime) -> bool:
        missing = pm.missing_marks(self.portfolio, prices)
        if missing:
            self._journal_once_a_day("PORTFOLIO_MARKS_INCOMPLETE", now, {
                "tickers": missing,
                "why": ("No observed price for these holdings. Entry-price estimates "
                        "do not set a loss halt, drawdown level or equity-history point. "
                        "New scan entries wait; quoted protective exits still run."),
            })
        return not missing

    def _record_equity(self, prices: Dict[str, float], now: datetime) -> None:
        if not self._risk_marks_ready(prices, now):
            return
        eq = self.portfolio.equity(prices)
        self.portfolio.equity_history.append((now.isoformat(), eq))
        if len(self.portfolio.equity_history) > 50_000:
            self.portfolio.equity_history = self.portfolio.equity_history[-50_000:]

    def _summary_dict(self, prices: Dict[str, float]) -> dict:
        eq = self.portfolio.equity(prices)
        deployed = self.portfolio.deployed_value(prices)
        return {
            "equity": eq,
            "cash": self.portfolio.cash,
            "deployed": deployed,
            "open_positions": len(self.portfolio.positions),
            "closed_trades": len(self.portfolio.trades),
            "return_pct": (eq / self.cfg.starting_capital - 1) * 100,
            "kill_switch": self.risk.kill_switch,
            "valuation_complete": not pm.missing_marks(self.portfolio, prices),
            "valuation_missing": pm.missing_marks(self.portfolio, prices),
            "mark_snapshot": self.portfolio.mark_snapshot,
        }
