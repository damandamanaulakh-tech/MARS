"""Indian-market event calendars — earnings, RBI MPC, Budget, expiries.

All entries are MANUALLY-CURATED (no live scraping) for reliability. Update
this file annually when RBI publishes the next year's MPC schedule and
when Union Budget date is announced.

Used by the engine as overlays:
  - Halt new entries 5 days before earnings for that specific stock
  - Tighten stops during RBI/Budget weeks (system-wide)
  - Don't misread ex-dividend gaps as crashes
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Optional


@dataclass
class CalendarEvent:
    event_type: str   # 'rbi_mpc' | 'budget' | 'earnings' | 'expiry' | 'election' | 'ex_dividend'
    event_date: date
    description: str
    impact: str       # 'system_wide' | 'sector' | 'single_stock'
    affected: list[str] = None  # tickers affected; empty = system-wide

    def days_until(self, today: Optional[date] = None) -> int:
        today = today or date.today()
        return (self.event_date - today).days


# --- RBI Monetary Policy Committee (MPC) dates ---
# Source: https://www.rbi.org.in/Scripts/MonetaryPolicy.aspx
# Updated annually. Next ~12 months listed below.
# CORRECTED 2026-09-30. The previous list (Feb 5 / Apr 3 / Jun 6 / Aug 8 —
# a Saturday — / Oct 1 / Dec 5, plus a full invented 2027 row) matched NO
# published RBI schedule: the fabricated-calendar class, and it fired the
# entry halt on 2026-09-29..10-01 for a meeting that sits on Oct 5-7.
# Dates below are the DECISION day (last day of each meeting) from RBI's
# own FY2026-27 calendar, press release 2026-03-23 (prid 62422): Apr 6-8,
# Jun 3-5, Aug 3-5, Oct 5-7, Dec 2-4, Feb 3-5 2027. Feb 6 2026 is FY2025-26's
# last meeting (Feb 4-6). Nothing beyond Feb 2027 is published: the rest of
# 2027 is DATA_NEEDED, not guessed — add it when RBI publishes FY2027-28.
RBI_MPC_DATES_2026 = [
    date(2026, 2, 6),
    date(2026, 4, 8),
    date(2026, 6, 5),
    date(2026, 8, 5),
    date(2026, 10, 7),
    date(2026, 12, 4),
]
RBI_MPC_DATES_2027 = [
    date(2027, 2, 5),
]

# Event types that are SHOWN on the calendar but never halt entries.
#   expiry  — routine monthly F&O expiry (see is_system_event_within).
#   rbi_mpc — OWNER ORDER 2026-09-30: "do not consider the RBI as show
#             stopper". The RBI decision stays on the What's-Coming panel and
#             in upcoming_events(); it no longer blocks the 09:20 scan.
#             Budget and election results still halt.
HALT_EXEMPT_EVENT_TYPES: tuple = ("expiry", "rbi_mpc")

# --- Union Budget ---
# Always Feb 1 (since 2017); manually-confirmed exception years marked.
UNION_BUDGET_DATES = [
    date(2026, 2, 1),
    date(2027, 2, 1),
]

# --- Indian General Election RESULTS dates (the day Nifty actually moves) ---
# Source: Election Commission of India. Voting spans weeks, results are 1 day.
# Historical: 2014-05-16, 2019-05-23, 2024-06-04 (Nifty -5.93% intraday).
INDIA_GENERAL_ELECTION_RESULTS = [
    date(2014, 5, 16),
    date(2019, 5, 23),
    date(2024, 6, 4),
    # 2029: add the real results date when the Election Commission announces
    # the schedule (~early 2029). No guessed dates in production.
]

# --- Key State Election results (high market impact only) ---
# Includes Maharashtra, Haryana, UP, Gujarat, Bihar, Delhi where local
# policy drives sector flows materially.
INDIA_STATE_ELECTION_RESULTS = [
    date(2024, 6, 4),    # Odisha + Andhra Pradesh (alongside General)
    date(2024, 10, 8),   # Haryana + J&K
    date(2024, 11, 23),  # Maharashtra + Jharkhand
    date(2025, 2, 8),    # Delhi
    date(2025, 11, 14),  # Bihar (estimated)
]

# --- NSE trading holidays (P2: crons must not run on holidays) ---
# PARTIAL list: only nationally fixed dates are hardcoded with certainty.
# Variable-date holidays (Holi, Eid, Diwali, etc.) MUST be refreshed yearly
# from the NSE circular. Missing entries fail SAFE: the scan runs but the
# stale-data guard (cfg.max_stale_days) blocks buys on old candles.
NSE_FIXED_HOLIDAYS = [
    # --- 2026: full NSE equity-segment holiday list (owner-approved adoption,
    # 2026-07-27). Cross-checked against two published copies of the NSE
    # circular (cleartax.in/s/nse-holidays-2026, groww.in/p/nse-holidays);
    # each source carried one date the other missed (Jan 15 election holiday /
    # Nov 24 Gurpurb) — this is the union. Weekend holidays are omitted:
    # is_trading_day() already excludes Sat/Sun.
    date(2026, 1, 15),   # Municipal Corporation Election — Maharashtra
    date(2026, 1, 26),   # Republic Day
    date(2026, 3, 3),    # Holi
    date(2026, 3, 26),   # Shri Ram Navami
    date(2026, 3, 31),   # Shri Mahavir Jayanti
    date(2026, 4, 3),    # Good Friday
    date(2026, 4, 14),   # Dr. Baba Saheb Ambedkar Jayanti
    date(2026, 5, 1),    # Maharashtra Day
    date(2026, 5, 28),   # Bakri Id
    date(2026, 6, 26),   # Muharram
    date(2026, 9, 14),   # Ganesh Chaturthi
    date(2026, 10, 2),   # Mahatma Gandhi Jayanti
    date(2026, 10, 20),  # Dussehra
    date(2026, 11, 10),  # Diwali — Balipratipada
    date(2026, 11, 24),  # Prakash Gurpurb Sri Guru Nanak Dev
    date(2026, 12, 25),  # Christmas
    # --- 2027: only the fixed national dates are known today. The lunar /
    # festival dates move every year — refresh from the NSE circular when it
    # is published (usually December 2026). Missing entries fail SAFE: the
    # scan runs, finds no fresh candle, and the stale-data guard blocks buys.
    date(2027, 1, 26), date(2027, 8, 15), date(2027, 10, 2), date(2027, 12, 25),
]


def is_trading_day(today: Optional[date] = None) -> bool:
    """True on NSE trading days: Mon-Fri and not a known holiday."""
    today = today or date.today()
    return today.weekday() < 5 and today not in NSE_FIXED_HOLIDAYS


# --- market hours (owner order 2026-09-10: "trade are prohibited from now
# after market hours ... yes all block, but i can run the advisery to review
# buy, watch and block list, for trade hours") -------------------------------
#
# THE HOLE THIS CLOSES. Every automatic entry path gated on is_trading_day(),
# which reads the DAY and never the CLOCK. catchup_scan_if_missed fires ~2
# minutes after EVERY boot, so a Render restart at 21:00 on a Tuesday ran a
# full multi-mode scan that could open positions — hours after the close, on
# prices nobody could have traded at.
#
# The session window is NSE's own: 09:15-15:30 IST. The two scheduled jobs
# that run outside it by design (15:25 square-off is inside; 15:35 mark-and-
# exit is not) are handled at their own call sites, not here — this helper
# only answers the question it is named for.
MARKET_OPEN_IST = (9, 15)
MARKET_CLOSE_IST = (15, 30)


def _ist_now(now: Optional[datetime] = None) -> datetime:
    """Current time in IST. `now` may be naive (assumed already IST) or aware."""
    if now is not None:
        return now if now.tzinfo is None else now.astimezone(_IST)
    try:
        return datetime.now(_IST)
    except Exception:                                   # pragma: no cover
        return datetime.now()


try:                                                    # stdlib since 3.9
    from zoneinfo import ZoneInfo
    _IST = ZoneInfo("Asia/Kolkata")
except Exception:                                       # pragma: no cover
    from datetime import timezone as _tz
    _IST = _tz(timedelta(hours=5, minutes=30))


def is_market_open(now: Optional[datetime] = None) -> bool:
    """True only inside NSE's continuous session: a trading day, 09:15-15:30 IST.

    Used to gate every AUTOMATIC path that can open or close a position.
    Read-only work — scanning, scoring, the advisory, news, triggers — is
    never gated on this: the owner asked to keep reviewing buy/watch/block
    lists outside hours, and reading nothing costs nothing.
    """
    # SB_IGNORE_MARKET_HOURS=1 — for tests and backtests ONLY, which replay
    # closed days by definition and run at whatever wall-clock hour CI wakes
    # up. Set in the test conftests, never in render.yaml. Same escape-hatch
    # pattern as SB_DISABLE_CATCHUP and SB_LOGIN_DELAY_SEC. A guard test
    # asserts production config never sets it and that the default is gated.
    import os
    if os.environ.get("SB_IGNORE_MARKET_HOURS") == "1":
        return True
    t = _ist_now(now)
    if not is_trading_day(t.date()):
        return False
    hhmm = (t.hour, t.minute)
    return MARKET_OPEN_IST <= hhmm <= MARKET_CLOSE_IST


def market_state(now: Optional[datetime] = None) -> str:
    """'open' | 'closed_holiday' | 'pre_open' | 'after_close' — for screens
    and journal lines, so a blocked trade always says WHY it was blocked."""
    t = _ist_now(now)
    if not is_trading_day(t.date()):
        return "closed_holiday"
    hhmm = (t.hour, t.minute)
    if hhmm < MARKET_OPEN_IST:
        return "pre_open"
    if hhmm > MARKET_CLOSE_IST:
        return "after_close"
    return "open"


# --- F&O monthly expiry ---
def fno_monthly_expiry(year: int, month: int) -> date:
    """Last TUESDAY of the given month (display only — expiry never halts).

    AUDIT FIX B10 (2026-08-09): this computed last THURSDAY, but NSE moved
    its F&O expiries to Tuesday under SEBI's 2025 expiry-day standardization
    (effective ~Sep 2025), so every What's-Coming expiry date was a few days
    late. Note: dates computed for months before Sep 2025 will be wrong by
    this rule — this helper is only used forward-looking."""
    if month == 12:
        first_next = date(year + 1, 1, 1)
    else:
        first_next = date(year, month + 1, 1)
    last_day = first_next - timedelta(days=1)
    # Tuesday = weekday 1
    while last_day.weekday() != 1:
        last_day -= timedelta(days=1)
    # External review on PR#40: when the last Tuesday is an NSE holiday
    # (e.g. 2026-11-24 Gurpurb, 2027-01-26 Republic Day), expiry moves to
    # the PRECEDING trading day.
    while not is_trading_day(last_day):
        last_day -= timedelta(days=1)
    return last_day


# --- Earnings calendar (NSE quarterly results) ---
# Source: NSE quarterly results calendar (manually curated).
# Format: ticker (NSE) -> [date(...)]
#
# AUDIT FIX A5 (2026-08-09): trimmed to the Q1-FY27 (Jul-Aug 2026) dates only,
# all now in the past. The Oct-2026..May-2027 dates previously here were
# GUESSES — companies announce result dates only ~2-4 weeks ahead, so those
# entries both blocked entries on invented dates and implied protection on
# the real (unknown) ones. DATA_NEEDED: future quarters go in only from the
# NSE results calendar once companies announce; with no future dates the
# earnings blackout simply never fires.
#
# Rule: skip new entries during the 3-day window BEFORE earnings (volatility
# spike + binary risk). Existing positions are not force-exited.
INDIA_EARNINGS_DATES_2026 = {
    # Q1 FY27 (Jul 2026): banks and IT report first
    "TCS.NS":       [date(2026, 7, 11)],
    "INFY.NS":      [date(2026, 7, 17)],
    "WIPRO.NS":     [date(2026, 7, 18)],
    "HCLTECH.NS":   [date(2026, 7, 14)],
    "TECHM.NS":     [date(2026, 7, 25)],
    "LTIM.NS":      [date(2026, 7, 19)],
    "HDFCBANK.NS":  [date(2026, 7, 19)],
    "ICICIBANK.NS": [date(2026, 7, 25)],
    "SBIN.NS":      [date(2026, 8, 2)],
    "AXISBANK.NS":  [date(2026, 7, 23)],
    "KOTAKBANK.NS": [date(2026, 7, 26)],
    "INDUSINDBK.NS":[date(2026, 7, 23)],
    "BAJFINANCE.NS":[date(2026, 7, 26)],
    "RELIANCE.NS":  [date(2026, 7, 19)],
    "MARUTI.NS":    [date(2026, 7, 31)],
    "M&M.NS":       [date(2026, 8, 8)],
    "TATAMOTORS.NS":[date(2026, 7, 31)],
    "BHARTIARTL.NS":[date(2026, 8, 7)],
    "ITC.NS":       [date(2026, 8, 1)],
    "LT.NS":        [date(2026, 7, 25)],
    "SUNPHARMA.NS": [date(2026, 8, 2)],
    "DRREDDY.NS":   [date(2026, 7, 26)],
    "CIPLA.NS":     [date(2026, 8, 1)],
}



def upcoming_events(today: Optional[date] = None, lookahead_days: int = 30) -> list[CalendarEvent]:
    """Returns all known events within the next `lookahead_days` days,
    ordered by date ascending."""
    today = today or date.today()
    cutoff = today + timedelta(days=lookahead_days)
    out: list[CalendarEvent] = []

    for d in RBI_MPC_DATES_2026 + RBI_MPC_DATES_2027:
        if today <= d <= cutoff:
            out.append(CalendarEvent(
                event_type="rbi_mpc", event_date=d,
                description="RBI Monetary Policy Committee meeting",
                impact="system_wide", affected=[],
            ))

    for d in UNION_BUDGET_DATES:
        if today <= d <= cutoff:
            out.append(CalendarEvent(
                event_type="budget", event_date=d,
                description="Union Budget presentation",
                impact="system_wide", affected=[],
            ))

    # Indian general elections — single biggest binary event for NSE
    for d in INDIA_GENERAL_ELECTION_RESULTS:
        if today <= d <= cutoff:
            out.append(CalendarEvent(
                event_type="election_general", event_date=d,
                description="India General Election results",
                impact="system_wide", affected=[],
            ))

    # State elections (high market impact)
    for d in INDIA_STATE_ELECTION_RESULTS:
        if today <= d <= cutoff:
            out.append(CalendarEvent(
                event_type="election_state", event_date=d,
                description="State Election results",
                impact="system_wide", affected=[],
            ))

    # F&O expiries (next 2 months)
    for offset in range(0, 2):
        y, m = (today.year, today.month + offset)
        if m > 12:
            y, m = y + 1, m - 12
        exp = fno_monthly_expiry(y, m)
        if today <= exp <= cutoff:
            out.append(CalendarEvent(
                event_type="expiry", event_date=exp,
                description="F&O monthly expiry",
                impact="system_wide", affected=[],
            ))

    # Earnings dates — single-stock binary risk (volatility spike + gap risk)
    for ticker, dates in INDIA_EARNINGS_DATES_2026.items():
        for d in dates:
            if today <= d <= cutoff:
                out.append(CalendarEvent(
                    event_type="earnings", event_date=d,
                    description=f"Quarterly results: {ticker}",
                    impact="single_stock", affected=[ticker],
                ))

    out.sort(key=lambda e: e.event_date)
    return out


def is_system_event_within(days: int = 5, today: Optional[date] = None) -> Optional[CalendarEvent]:
    """Returns the nearest macro binary event (RBI / Budget / election) within
    N days, or None.

    F&O monthly expiry is system-wide but ROUTINE — halting entries for 3 days
    before every expiry wrongly benched the engine ~4 trading days a month, so
    expiry is excluded here. RBI MPC decisions are excluded by OWNER ORDER
    (2026-09-30, "do not consider the RBI as show stopper"). Budget and
    election results still halt. The exempt set is HALT_EXEMPT_EVENT_TYPES.
    """
    upcoming = upcoming_events(today, lookahead_days=days)
    for ev in upcoming:
        if ev.impact == "system_wide" and ev.event_type not in HALT_EXEMPT_EVENT_TYPES:
            return ev
    return None


def is_ticker_event_within(ticker: str, days: int = 5, today: Optional[date] = None) -> Optional[CalendarEvent]:
    """Returns the nearest event affecting this ticker within N days, or None."""
    upcoming = upcoming_events(today, lookahead_days=days)
    for ev in upcoming:
        if ev.affected and ticker in ev.affected:
            return ev
    return None


# F2 v1.1 (user: "more festivals, wire the rest"): major market-relevant
# Indian festival dates. Lunar dates carry ±1 day uncertainty — immaterial
# inside the ±5-day window. FLAG + sector hint only; no invented alpha.
FESTIVAL_DATES = {
    # 2026
    "Makar Sankranti / Pongal": [date(2026, 1, 14), date(2027, 1, 14)],
    "Holi":                     [date(2026, 3, 4), date(2027, 3, 22)],
    "Eid-ul-Fitr":              [date(2026, 3, 20)],
    "Akshaya Tritiya":          [date(2026, 4, 20)],   # biggest gold-buying day
    "Eid-al-Adha":              [date(2026, 5, 27)],
    "Onam":                     [date(2026, 8, 26)],
    "Raksha Bandhan":           [date(2026, 8, 28)],
    "Janmashtami":              [date(2026, 9, 4)],
    "Ganesh Chaturthi":         [date(2026, 9, 14)],
    "Navratri start":           [date(2026, 10, 11)],
    "Dussehra":                 [date(2026, 10, 20)],
    "Dhanteras":                [date(2026, 11, 6)],   # gold/auto/durables peak
    "Diwali":                   [date(2026, 11, 8), date(2027, 10, 29)],
    "Bhai Dooj":                [date(2026, 11, 10)],
    "Guru Nanak Jayanti":       [date(2026, 11, 24)],
    "Christmas / year-end":     [date(2026, 12, 25)],
}

# Which sectors historically see festival demand (HINTS for the journal —
# not a score input until validated).
FESTIVAL_SECTOR_HINTS = {
    "Makar Sankranti / Pongal": "FMCG, Retail",
    "Holi": "FMCG, Consumer",
    "Eid-ul-Fitr": "FMCG, Retail, Apparel",
    "Akshaya Tritiya": "Gold/Jewellery (Titan etc.), Financials-gold-loan",
    "Eid-al-Adha": "FMCG, Retail",
    "Onam": "Retail, Gold, Consumer Durables (Kerala demand)",
    "Raksha Bandhan": "Retail, Sweets/FMCG, Gifting",
    "Janmashtami": "FMCG, Dairy",
    "Ganesh Chaturthi": "Consumer, Retail (west-India demand)",
    "Navratri start": "Autos (delivery bookings), Consumer Durables, Retail",
    "Dussehra": "Autos (peak delivery day), Consumer Durables",
    "Dhanteras": "Gold/Jewellery, Autos, Consumer Durables — biggest buying day",
    "Diwali": "Autos, Retail, FMCG, Consumer Durables, Jewellery",
    "Bhai Dooj": "Gifting, Retail",
    "Guru Nanak Jayanti": "Regional retail",
    "Christmas / year-end": "Hospitality, Aviation, Retail, QSR",
}

# Wedding-season windows (gold + apparel + hospitality demand)
WEDDING_SEASONS = [
    (date(2026, 1, 15), date(2026, 3, 10)),
    (date(2026, 4, 14), date(2026, 6, 30)),
    (date(2026, 11, 15), date(2026, 12, 15)),
]


def festival_within(days: int = 5, today: date | None = None):
    """Name of the nearest festival within ±`days`, else None."""
    today = today or date.today()
    best = None
    for name, dates in FESTIVAL_DATES.items():
        for d in dates:
            gap = abs((d - today).days)
            if gap <= days and (best is None or gap < best[0]):
                best = (gap, name)
    return best[1] if best else None


def festival_context(days: int = 5, today: date | None = None) -> str | None:
    """'Diwali (Autos, Retail, ...)' or None — for journal/dashboard."""
    name = festival_within(days=days, today=today)
    if not name:
        today = today or date.today()
        for a, b in WEDDING_SEASONS:
            if a <= today <= b:
                return "Wedding season (Gold/Jewellery, Apparel, Hospitality)"
        return None
    hint = FESTIVAL_SECTOR_HINTS.get(name, "")
    return f"{name} ({hint})" if hint else name
